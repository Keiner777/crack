<?php
require 'firebase.php';

$id = $_POST['id'] ?? null;

if ($id) {
    $database->getReference("1/$id")->remove();
    echo json_encode(["status" => "success", "message" => "Dato eliminado"]);
} else {
    echo json_encode(["status" => "error", "message" => "ID faltante"]);
}
?>
