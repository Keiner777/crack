<?php
require 'firebase.php';

$id = $_GET['id'] ?? null;
$campo = $_GET['campo'] ?? null;

if ($id && $campo) {
    $data = $database->getReference("1/$id/$campo")->getValue();
    echo json_encode(["status" => "success", "data" => $data]);
} else {
    echo json_encode(["status" => "error", "message" => "Faltan parámetros"]);
}
?>
