<?php
require 'firebase.php';

$id = $_POST['id'] ?? null;
$id2 = $_POST['id2'] ?? null; // Segunda referencia opcional
$updates1 = [];
$updates2 = [];

for ($i = 1; $i <= 10; $i++) {
    if (isset($_POST["campo$i"]) && isset($_POST["valor$i"])) {
        $updates1[$_POST["campo$i"]] = $_POST["valor$i"];
    }
    if (isset($_POST["campo${i}_2"]) && isset($_POST["valor${i}_2"])) {
        $updates2[$_POST["campo${i}_2"]] = $_POST["valor${i}_2"];
    }
}

$response = ["status" => "success"];

if ($id && count($updates1) > 0) {
    $database->getReference("1/$id")->update($updates1);
    $response["updates_1"] = $updates1;
}

if ($id2 && count($updates2) > 0) {
    $database->getReference("$id2")->update($updates2);
    $response["updates_2"] = $updates2;
}

echo json_encode($response);
?>
