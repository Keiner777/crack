<?php
require 'firebase.php';

$lastUpdate = $_GET['lastUpdate'] ?? 0;

// Obtener datos de la referencia "1/"
$data = $database->getReference("1/")->getValue();

// Convertir datos a JSON
$jsonData = json_encode($data);

// Generar un hash de los datos para detectar cambios
$currentHash = md5($jsonData);

$response = [
    "changed" => ($currentHash !== $lastUpdate), // Comparar hash anterior con el actual
    "newHash" => $currentHash
];

echo json_encode($response);
?>
