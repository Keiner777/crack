<?php
require 'firebase.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    echo json_encode(["error" => "ID no proporcionado"]);
    exit;
}

// Obtener el estado desde Firebase
$sectionVisible = $database->getReference("1/$id/sectionVisible")->getValue();

echo json_encode(["sectionVisible" => $sectionVisible]);
?>
