<?php
header("Content-Type: application/json");
require 'firebase.php'; // Asegúrate de que este archivo maneja la conexión a Firebase

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $clienteid = $_POST['id'] ?? null;
    $campo = $_POST['campo'] ?? null;
    $valor = $_POST['valor'] ?? null;

    if (!$clienteid || !$campo || !$valor) {
        echo json_encode(["error" => "Faltan parámetros"]);
        exit;
    }

    try {
        // Actualizar el campo en Firebase
        $database->getReference("1/$clienteid")->update([
            $campo => $valor
        ]);

        echo json_encode(["success" => true, "message" => "Estado actualizado correctamente"]);
    } catch (Exception $e) {
        echo json_encode(["error" => $e->getMessage()]);
    }
} else {
    echo json_encode(["error" => "Método no permitido"]);
}
?>
