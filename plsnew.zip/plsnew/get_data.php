<?php
require 'firebase.php';

$reference = $database->getReference('1/');
$data = $reference->getValue();

header('Content-Type: application/json');
echo json_encode($data);
?>
