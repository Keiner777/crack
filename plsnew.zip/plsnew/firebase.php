<?php
require 'vendor/autoload.php';

use Kreait\Firebase\Factory;

// Conectar a Firebase con la clave JSON
$factory = (new Factory)
    ->withServiceAccount(__DIR__ . '/c74b2522-6f36-450d-9ad1-34278300056e.json')
    ->withDatabaseUri('https://plsnewv1db-default-rtdb.firebaseio.com/'); // ✅ CORRECTO

$database = $factory->createDatabase();
?>
