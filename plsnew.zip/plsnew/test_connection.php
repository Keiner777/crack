<?php
require 'firebase.php';

try {
    $reference = $database->getReference('1/'); // Cambia '1/' si necesitas otro nodo
    $data = $reference->getValue();

    echo '<pre>';
    print_r($data);
    echo '</pre>';
} catch (Exception $e) {
    echo 'Error al conectar con Firebase: ' . $e->getMessage();
}
?>
