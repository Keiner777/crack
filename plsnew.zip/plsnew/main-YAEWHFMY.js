var jd = Object.defineProperty,
  Vd = Object.defineProperties;
var $d = Object.getOwnPropertyDescriptors;
var ua = Object.getOwnPropertySymbols;
var Bd = Object.prototype.hasOwnProperty,
  Ud = Object.prototype.propertyIsEnumerable;
var la = (e, t, n) =>
    t in e
      ? jd(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n })
      : (e[t] = n),
  g = (e, t) => {
    for (var n in (t ||= {})) Bd.call(t, n) && la(e, n, t[n]);
    if (ua) for (var n of ua(t)) Ud.call(t, n) && la(e, n, t[n]);
    return e;
  },
  j = (e, t) => Vd(e, $d(t));
var Eo = null;
var Co = 1,
  da = Symbol("SIGNAL");
function P(e) {
  let t = Eo;
  return (Eo = e), t;
}
function fa() {
  return Eo;
}
var Io = {
  version: 0,
  lastCleanEpoch: 0,
  dirty: !1,
  producerNode: void 0,
  producerLastReadVersion: void 0,
  producerIndexOfThis: void 0,
  nextProducerIndex: 0,
  liveConsumerNode: void 0,
  liveConsumerIndexOfThis: void 0,
  consumerAllowSignalWrites: !1,
  consumerIsAlwaysLive: !1,
  producerMustRecompute: () => !1,
  producerRecomputeValue: () => {},
  consumerMarkedDirty: () => {},
  consumerOnSignalRead: () => {},
};
function Hd(e) {
  if (!(To(e) && !e.dirty) && !(!e.dirty && e.lastCleanEpoch === Co)) {
    if (!e.producerMustRecompute(e) && !Mo(e)) {
      (e.dirty = !1), (e.lastCleanEpoch = Co);
      return;
    }
    e.producerRecomputeValue(e), (e.dirty = !1), (e.lastCleanEpoch = Co);
  }
}
function bo(e) {
  return e && (e.nextProducerIndex = 0), P(e);
}
function ha(e, t) {
  if (
    (P(t),
    !(
      !e ||
      e.producerNode === void 0 ||
      e.producerIndexOfThis === void 0 ||
      e.producerLastReadVersion === void 0
    ))
  ) {
    if (To(e))
      for (let n = e.nextProducerIndex; n < e.producerNode.length; n++)
        xo(e.producerNode[n], e.producerIndexOfThis[n]);
    for (; e.producerNode.length > e.nextProducerIndex; )
      e.producerNode.pop(),
        e.producerLastReadVersion.pop(),
        e.producerIndexOfThis.pop();
  }
}
function Mo(e) {
  _o(e);
  for (let t = 0; t < e.producerNode.length; t++) {
    let n = e.producerNode[t],
      r = e.producerLastReadVersion[t];
    if (r !== n.version || (Hd(n), r !== n.version)) return !0;
  }
  return !1;
}
function So(e) {
  if ((_o(e), To(e)))
    for (let t = 0; t < e.producerNode.length; t++)
      xo(e.producerNode[t], e.producerIndexOfThis[t]);
  (e.producerNode.length =
    e.producerLastReadVersion.length =
    e.producerIndexOfThis.length =
      0),
    e.liveConsumerNode &&
      (e.liveConsumerNode.length = e.liveConsumerIndexOfThis.length = 0);
}
function xo(e, t) {
  if ((zd(e), e.liveConsumerNode.length === 1 && Gd(e)))
    for (let r = 0; r < e.producerNode.length; r++)
      xo(e.producerNode[r], e.producerIndexOfThis[r]);
  let n = e.liveConsumerNode.length - 1;
  if (
    ((e.liveConsumerNode[t] = e.liveConsumerNode[n]),
    (e.liveConsumerIndexOfThis[t] = e.liveConsumerIndexOfThis[n]),
    e.liveConsumerNode.length--,
    e.liveConsumerIndexOfThis.length--,
    t < e.liveConsumerNode.length)
  ) {
    let r = e.liveConsumerIndexOfThis[t],
      o = e.liveConsumerNode[t];
    _o(o), (o.producerIndexOfThis[r] = t);
  }
}
function To(e) {
  return e.consumerIsAlwaysLive || (e?.liveConsumerNode?.length ?? 0) > 0;
}
function _o(e) {
  (e.producerNode ??= []),
    (e.producerIndexOfThis ??= []),
    (e.producerLastReadVersion ??= []);
}
function zd(e) {
  (e.liveConsumerNode ??= []), (e.liveConsumerIndexOfThis ??= []);
}
function Gd(e) {
  return e.producerNode !== void 0;
}
function qd() {
  throw new Error();
}
var Wd = qd;
function pa(e) {
  Wd = e;
}
function y(e) {
  return typeof e == "function";
}
function vt(e) {
  let n = e((r) => {
    Error.call(r), (r.stack = new Error().stack);
  });
  return (
    (n.prototype = Object.create(Error.prototype)),
    (n.prototype.constructor = n),
    n
  );
}
var Zn = vt(
  (e) =>
    function (n) {
      e(this),
        (this.message = n
          ? `${n.length} errors occurred during unsubscription:
${n.map((r, o) => `${o + 1}) ${r.toString()}`).join(`
  `)}`
          : ""),
        (this.name = "UnsubscriptionError"),
        (this.errors = n);
    }
);
function tn(e, t) {
  if (e) {
    let n = e.indexOf(t);
    0 <= n && e.splice(n, 1);
  }
}
var V = class e {
  constructor(t) {
    (this.initialTeardown = t),
      (this.closed = !1),
      (this._parentage = null),
      (this._finalizers = null);
  }
  unsubscribe() {
    let t;
    if (!this.closed) {
      this.closed = !0;
      let { _parentage: n } = this;
      if (n)
        if (((this._parentage = null), Array.isArray(n)))
          for (let i of n) i.remove(this);
        else n.remove(this);
      let { initialTeardown: r } = this;
      if (y(r))
        try {
          r();
        } catch (i) {
          t = i instanceof Zn ? i.errors : [i];
        }
      let { _finalizers: o } = this;
      if (o) {
        this._finalizers = null;
        for (let i of o)
          try {
            ga(i);
          } catch (s) {
            (t = t ?? []),
              s instanceof Zn ? (t = [...t, ...s.errors]) : t.push(s);
          }
      }
      if (t) throw new Zn(t);
    }
  }
  add(t) {
    var n;
    if (t && t !== this)
      if (this.closed) ga(t);
      else {
        if (t instanceof e) {
          if (t.closed || t._hasParent(this)) return;
          t._addParent(this);
        }
        (this._finalizers =
          (n = this._finalizers) !== null && n !== void 0 ? n : []).push(t);
      }
  }
  _hasParent(t) {
    let { _parentage: n } = this;
    return n === t || (Array.isArray(n) && n.includes(t));
  }
  _addParent(t) {
    let { _parentage: n } = this;
    this._parentage = Array.isArray(n) ? (n.push(t), n) : n ? [n, t] : t;
  }
  _removeParent(t) {
    let { _parentage: n } = this;
    n === t ? (this._parentage = null) : Array.isArray(n) && tn(n, t);
  }
  remove(t) {
    let { _finalizers: n } = this;
    n && tn(n, t), t instanceof e && t._removeParent(this);
  }
};
V.EMPTY = (() => {
  let e = new V();
  return (e.closed = !0), e;
})();
var No = V.EMPTY;
function Yn(e) {
  return (
    e instanceof V ||
    (e && "closed" in e && y(e.remove) && y(e.add) && y(e.unsubscribe))
  );
}
function ga(e) {
  y(e) ? e() : e.unsubscribe();
}
var pe = {
  onUnhandledError: null,
  onStoppedNotification: null,
  Promise: void 0,
  useDeprecatedSynchronousErrorHandling: !1,
  useDeprecatedNextContext: !1,
};
var yt = {
  setTimeout(e, t, ...n) {
    let { delegate: r } = yt;
    return r?.setTimeout ? r.setTimeout(e, t, ...n) : setTimeout(e, t, ...n);
  },
  clearTimeout(e) {
    let { delegate: t } = yt;
    return (t?.clearTimeout || clearTimeout)(e);
  },
  delegate: void 0,
};
function Qn(e) {
  yt.setTimeout(() => {
    let { onUnhandledError: t } = pe;
    if (t) t(e);
    else throw e;
  });
}
function nn() {}
var ma = Ao("C", void 0, void 0);
function va(e) {
  return Ao("E", void 0, e);
}
function ya(e) {
  return Ao("N", e, void 0);
}
function Ao(e, t, n) {
  return { kind: e, value: t, error: n };
}
var Xe = null;
function Dt(e) {
  if (pe.useDeprecatedSynchronousErrorHandling) {
    let t = !Xe;
    if ((t && (Xe = { errorThrown: !1, error: null }), e(), t)) {
      let { errorThrown: n, error: r } = Xe;
      if (((Xe = null), n)) throw r;
    }
  } else e();
}
function Da(e) {
  pe.useDeprecatedSynchronousErrorHandling &&
    Xe &&
    ((Xe.errorThrown = !0), (Xe.error = e));
}
var Je = class extends V {
    constructor(t) {
      super(),
        (this.isStopped = !1),
        t
          ? ((this.destination = t), Yn(t) && t.add(this))
          : (this.destination = Qd);
    }
    static create(t, n, r) {
      return new wt(t, n, r);
    }
    next(t) {
      this.isStopped ? Oo(ya(t), this) : this._next(t);
    }
    error(t) {
      this.isStopped
        ? Oo(va(t), this)
        : ((this.isStopped = !0), this._error(t));
    }
    complete() {
      this.isStopped ? Oo(ma, this) : ((this.isStopped = !0), this._complete());
    }
    unsubscribe() {
      this.closed ||
        ((this.isStopped = !0), super.unsubscribe(), (this.destination = null));
    }
    _next(t) {
      this.destination.next(t);
    }
    _error(t) {
      try {
        this.destination.error(t);
      } finally {
        this.unsubscribe();
      }
    }
    _complete() {
      try {
        this.destination.complete();
      } finally {
        this.unsubscribe();
      }
    }
  },
  Zd = Function.prototype.bind;
function Ro(e, t) {
  return Zd.call(e, t);
}
var Po = class {
    constructor(t) {
      this.partialObserver = t;
    }
    next(t) {
      let { partialObserver: n } = this;
      if (n.next)
        try {
          n.next(t);
        } catch (r) {
          Kn(r);
        }
    }
    error(t) {
      let { partialObserver: n } = this;
      if (n.error)
        try {
          n.error(t);
        } catch (r) {
          Kn(r);
        }
      else Kn(t);
    }
    complete() {
      let { partialObserver: t } = this;
      if (t.complete)
        try {
          t.complete();
        } catch (n) {
          Kn(n);
        }
    }
  },
  wt = class extends Je {
    constructor(t, n, r) {
      super();
      let o;
      if (y(t) || !t)
        o = { next: t ?? void 0, error: n ?? void 0, complete: r ?? void 0 };
      else {
        let i;
        this && pe.useDeprecatedNextContext
          ? ((i = Object.create(t)),
            (i.unsubscribe = () => this.unsubscribe()),
            (o = {
              next: t.next && Ro(t.next, i),
              error: t.error && Ro(t.error, i),
              complete: t.complete && Ro(t.complete, i),
            }))
          : (o = t);
      }
      this.destination = new Po(o);
    }
  };
function Kn(e) {
  pe.useDeprecatedSynchronousErrorHandling ? Da(e) : Qn(e);
}
function Yd(e) {
  throw e;
}
function Oo(e, t) {
  let { onStoppedNotification: n } = pe;
  n && yt.setTimeout(() => n(e, t));
}
var Qd = { closed: !0, next: nn, error: Yd, complete: nn };
var Ct = (typeof Symbol == "function" && Symbol.observable) || "@@observable";
function te(e) {
  return e;
}
function ko(...e) {
  return Fo(e);
}
function Fo(e) {
  return e.length === 0
    ? te
    : e.length === 1
    ? e[0]
    : function (n) {
        return e.reduce((r, o) => o(r), n);
      };
}
var R = (() => {
  class e {
    constructor(n) {
      n && (this._subscribe = n);
    }
    lift(n) {
      let r = new e();
      return (r.source = this), (r.operator = n), r;
    }
    subscribe(n, r, o) {
      let i = Xd(n) ? n : new wt(n, r, o);
      return (
        Dt(() => {
          let { operator: s, source: a } = this;
          i.add(
            s ? s.call(i, a) : a ? this._subscribe(i) : this._trySubscribe(i)
          );
        }),
        i
      );
    }
    _trySubscribe(n) {
      try {
        return this._subscribe(n);
      } catch (r) {
        n.error(r);
      }
    }
    forEach(n, r) {
      return (
        (r = wa(r)),
        new r((o, i) => {
          let s = new wt({
            next: (a) => {
              try {
                n(a);
              } catch (c) {
                i(c), s.unsubscribe();
              }
            },
            error: i,
            complete: o,
          });
          this.subscribe(s);
        })
      );
    }
    _subscribe(n) {
      var r;
      return (r = this.source) === null || r === void 0
        ? void 0
        : r.subscribe(n);
    }
    [Ct]() {
      return this;
    }
    pipe(...n) {
      return Fo(n)(this);
    }
    toPromise(n) {
      return (
        (n = wa(n)),
        new n((r, o) => {
          let i;
          this.subscribe(
            (s) => (i = s),
            (s) => o(s),
            () => r(i)
          );
        })
      );
    }
  }
  return (e.create = (t) => new e(t)), e;
})();
function wa(e) {
  var t;
  return (t = e ?? pe.Promise) !== null && t !== void 0 ? t : Promise;
}
function Kd(e) {
  return e && y(e.next) && y(e.error) && y(e.complete);
}
function Xd(e) {
  return (e && e instanceof Je) || (Kd(e) && Yn(e));
}
function Lo(e) {
  return y(e?.lift);
}
function _(e) {
  return (t) => {
    if (Lo(t))
      return t.lift(function (n) {
        try {
          return e(n, this);
        } catch (r) {
          this.error(r);
        }
      });
    throw new TypeError("Unable to lift unknown Observable type");
  };
}
function N(e, t, n, r, o) {
  return new jo(e, t, n, r, o);
}
var jo = class extends Je {
  constructor(t, n, r, o, i, s) {
    super(t),
      (this.onFinalize = i),
      (this.shouldUnsubscribe = s),
      (this._next = n
        ? function (a) {
            try {
              n(a);
            } catch (c) {
              t.error(c);
            }
          }
        : super._next),
      (this._error = o
        ? function (a) {
            try {
              o(a);
            } catch (c) {
              t.error(c);
            } finally {
              this.unsubscribe();
            }
          }
        : super._error),
      (this._complete = r
        ? function () {
            try {
              r();
            } catch (a) {
              t.error(a);
            } finally {
              this.unsubscribe();
            }
          }
        : super._complete);
  }
  unsubscribe() {
    var t;
    if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
      let { closed: n } = this;
      super.unsubscribe(),
        !n && ((t = this.onFinalize) === null || t === void 0 || t.call(this));
    }
  }
};
function Et() {
  return _((e, t) => {
    let n = null;
    e._refCount++;
    let r = N(t, void 0, void 0, void 0, () => {
      if (!e || e._refCount <= 0 || 0 < --e._refCount) {
        n = null;
        return;
      }
      let o = e._connection,
        i = n;
      (n = null), o && (!i || o === i) && o.unsubscribe(), t.unsubscribe();
    });
    e.subscribe(r), r.closed || (n = e.connect());
  });
}
var It = class extends R {
  constructor(t, n) {
    super(),
      (this.source = t),
      (this.subjectFactory = n),
      (this._subject = null),
      (this._refCount = 0),
      (this._connection = null),
      Lo(t) && (this.lift = t.lift);
  }
  _subscribe(t) {
    return this.getSubject().subscribe(t);
  }
  getSubject() {
    let t = this._subject;
    return (
      (!t || t.isStopped) && (this._subject = this.subjectFactory()),
      this._subject
    );
  }
  _teardown() {
    this._refCount = 0;
    let { _connection: t } = this;
    (this._subject = this._connection = null), t?.unsubscribe();
  }
  connect() {
    let t = this._connection;
    if (!t) {
      t = this._connection = new V();
      let n = this.getSubject();
      t.add(
        this.source.subscribe(
          N(
            n,
            void 0,
            () => {
              this._teardown(), n.complete();
            },
            (r) => {
              this._teardown(), n.error(r);
            },
            () => this._teardown()
          )
        )
      ),
        t.closed && ((this._connection = null), (t = V.EMPTY));
    }
    return t;
  }
  refCount() {
    return Et()(this);
  }
};
var Ca = vt(
  (e) =>
    function () {
      e(this),
        (this.name = "ObjectUnsubscribedError"),
        (this.message = "object unsubscribed");
    }
);
var Q = (() => {
    class e extends R {
      constructor() {
        super(),
          (this.closed = !1),
          (this.currentObservers = null),
          (this.observers = []),
          (this.isStopped = !1),
          (this.hasError = !1),
          (this.thrownError = null);
      }
      lift(n) {
        let r = new Xn(this, this);
        return (r.operator = n), r;
      }
      _throwIfClosed() {
        if (this.closed) throw new Ca();
      }
      next(n) {
        Dt(() => {
          if ((this._throwIfClosed(), !this.isStopped)) {
            this.currentObservers ||
              (this.currentObservers = Array.from(this.observers));
            for (let r of this.currentObservers) r.next(n);
          }
        });
      }
      error(n) {
        Dt(() => {
          if ((this._throwIfClosed(), !this.isStopped)) {
            (this.hasError = this.isStopped = !0), (this.thrownError = n);
            let { observers: r } = this;
            for (; r.length; ) r.shift().error(n);
          }
        });
      }
      complete() {
        Dt(() => {
          if ((this._throwIfClosed(), !this.isStopped)) {
            this.isStopped = !0;
            let { observers: n } = this;
            for (; n.length; ) n.shift().complete();
          }
        });
      }
      unsubscribe() {
        (this.isStopped = this.closed = !0),
          (this.observers = this.currentObservers = null);
      }
      get observed() {
        var n;
        return (
          ((n = this.observers) === null || n === void 0 ? void 0 : n.length) >
          0
        );
      }
      _trySubscribe(n) {
        return this._throwIfClosed(), super._trySubscribe(n);
      }
      _subscribe(n) {
        return (
          this._throwIfClosed(),
          this._checkFinalizedStatuses(n),
          this._innerSubscribe(n)
        );
      }
      _innerSubscribe(n) {
        let { hasError: r, isStopped: o, observers: i } = this;
        return r || o
          ? No
          : ((this.currentObservers = null),
            i.push(n),
            new V(() => {
              (this.currentObservers = null), tn(i, n);
            }));
      }
      _checkFinalizedStatuses(n) {
        let { hasError: r, thrownError: o, isStopped: i } = this;
        r ? n.error(o) : i && n.complete();
      }
      asObservable() {
        let n = new R();
        return (n.source = this), n;
      }
    }
    return (e.create = (t, n) => new Xn(t, n)), e;
  })(),
  Xn = class extends Q {
    constructor(t, n) {
      super(), (this.destination = t), (this.source = n);
    }
    next(t) {
      var n, r;
      (r =
        (n = this.destination) === null || n === void 0 ? void 0 : n.next) ===
        null ||
        r === void 0 ||
        r.call(n, t);
    }
    error(t) {
      var n, r;
      (r =
        (n = this.destination) === null || n === void 0 ? void 0 : n.error) ===
        null ||
        r === void 0 ||
        r.call(n, t);
    }
    complete() {
      var t, n;
      (n =
        (t = this.destination) === null || t === void 0
          ? void 0
          : t.complete) === null ||
        n === void 0 ||
        n.call(t);
    }
    _subscribe(t) {
      var n, r;
      return (r =
        (n = this.source) === null || n === void 0
          ? void 0
          : n.subscribe(t)) !== null && r !== void 0
        ? r
        : No;
    }
  };
var W = class extends Q {
  constructor(t) {
    super(), (this._value = t);
  }
  get value() {
    return this.getValue();
  }
  _subscribe(t) {
    let n = super._subscribe(t);
    return !n.closed && t.next(this._value), n;
  }
  getValue() {
    let { hasError: t, thrownError: n, _value: r } = this;
    if (t) throw n;
    return this._throwIfClosed(), r;
  }
  next(t) {
    super.next((this._value = t));
  }
};
var ne = new R((e) => e.complete());
function Ea(e) {
  return e && y(e.schedule);
}
function Ia(e) {
  return e[e.length - 1];
}
function ba(e) {
  return y(Ia(e)) ? e.pop() : void 0;
}
function $e(e) {
  return Ea(Ia(e)) ? e.pop() : void 0;
}
function Sa(e, t, n, r) {
  function o(i) {
    return i instanceof n
      ? i
      : new n(function (s) {
          s(i);
        });
  }
  return new (n || (n = Promise))(function (i, s) {
    function a(l) {
      try {
        u(r.next(l));
      } catch (d) {
        s(d);
      }
    }
    function c(l) {
      try {
        u(r.throw(l));
      } catch (d) {
        s(d);
      }
    }
    function u(l) {
      l.done ? i(l.value) : o(l.value).then(a, c);
    }
    u((r = r.apply(e, t || [])).next());
  });
}
function Ma(e) {
  var t = typeof Symbol == "function" && Symbol.iterator,
    n = t && e[t],
    r = 0;
  if (n) return n.call(e);
  if (e && typeof e.length == "number")
    return {
      next: function () {
        return (
          e && r >= e.length && (e = void 0), { value: e && e[r++], done: !e }
        );
      },
    };
  throw new TypeError(
    t ? "Object is not iterable." : "Symbol.iterator is not defined."
  );
}
function et(e) {
  return this instanceof et ? ((this.v = e), this) : new et(e);
}
function xa(e, t, n) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var r = n.apply(e, t || []),
    o,
    i = [];
  return (
    (o = {}),
    a("next"),
    a("throw"),
    a("return", s),
    (o[Symbol.asyncIterator] = function () {
      return this;
    }),
    o
  );
  function s(f) {
    return function (m) {
      return Promise.resolve(m).then(f, d);
    };
  }
  function a(f, m) {
    r[f] &&
      ((o[f] = function (S) {
        return new Promise(function (L, H) {
          i.push([f, S, L, H]) > 1 || c(f, S);
        });
      }),
      m && (o[f] = m(o[f])));
  }
  function c(f, m) {
    try {
      u(r[f](m));
    } catch (S) {
      h(i[0][3], S);
    }
  }
  function u(f) {
    f.value instanceof et
      ? Promise.resolve(f.value.v).then(l, d)
      : h(i[0][2], f);
  }
  function l(f) {
    c("next", f);
  }
  function d(f) {
    c("throw", f);
  }
  function h(f, m) {
    f(m), i.shift(), i.length && c(i[0][0], i[0][1]);
  }
}
function Ta(e) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var t = e[Symbol.asyncIterator],
    n;
  return t
    ? t.call(e)
    : ((e = typeof Ma == "function" ? Ma(e) : e[Symbol.iterator]()),
      (n = {}),
      r("next"),
      r("throw"),
      r("return"),
      (n[Symbol.asyncIterator] = function () {
        return this;
      }),
      n);
  function r(i) {
    n[i] =
      e[i] &&
      function (s) {
        return new Promise(function (a, c) {
          (s = e[i](s)), o(a, c, s.done, s.value);
        });
      };
  }
  function o(i, s, a, c) {
    Promise.resolve(c).then(function (u) {
      i({ value: u, done: a });
    }, s);
  }
}
var Jn = (e) => e && typeof e.length == "number" && typeof e != "function";
function er(e) {
  return y(e?.then);
}
function tr(e) {
  return y(e[Ct]);
}
function nr(e) {
  return Symbol.asyncIterator && y(e?.[Symbol.asyncIterator]);
}
function rr(e) {
  return new TypeError(
    `You provided ${
      e !== null && typeof e == "object" ? "an invalid object" : `'${e}'`
    } where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.`
  );
}
function Jd() {
  return typeof Symbol != "function" || !Symbol.iterator
    ? "@@iterator"
    : Symbol.iterator;
}
var or = Jd();
function ir(e) {
  return y(e?.[or]);
}
function sr(e) {
  return xa(this, arguments, function* () {
    let n = e.getReader();
    try {
      for (;;) {
        let { value: r, done: o } = yield et(n.read());
        if (o) return yield et(void 0);
        yield yield et(r);
      }
    } finally {
      n.releaseLock();
    }
  });
}
function ar(e) {
  return y(e?.getReader);
}
function q(e) {
  if (e instanceof R) return e;
  if (e != null) {
    if (tr(e)) return ef(e);
    if (Jn(e)) return tf(e);
    if (er(e)) return nf(e);
    if (nr(e)) return _a(e);
    if (ir(e)) return rf(e);
    if (ar(e)) return of(e);
  }
  throw rr(e);
}
function ef(e) {
  return new R((t) => {
    let n = e[Ct]();
    if (y(n.subscribe)) return n.subscribe(t);
    throw new TypeError(
      "Provided object does not correctly implement Symbol.observable"
    );
  });
}
function tf(e) {
  return new R((t) => {
    for (let n = 0; n < e.length && !t.closed; n++) t.next(e[n]);
    t.complete();
  });
}
function nf(e) {
  return new R((t) => {
    e.then(
      (n) => {
        t.closed || (t.next(n), t.complete());
      },
      (n) => t.error(n)
    ).then(null, Qn);
  });
}
function rf(e) {
  return new R((t) => {
    for (let n of e) if ((t.next(n), t.closed)) return;
    t.complete();
  });
}
function _a(e) {
  return new R((t) => {
    sf(e, t).catch((n) => t.error(n));
  });
}
function of(e) {
  return _a(sr(e));
}
function sf(e, t) {
  var n, r, o, i;
  return Sa(this, void 0, void 0, function* () {
    try {
      for (n = Ta(e); (r = yield n.next()), !r.done; ) {
        let s = r.value;
        if ((t.next(s), t.closed)) return;
      }
    } catch (s) {
      o = { error: s };
    } finally {
      try {
        r && !r.done && (i = n.return) && (yield i.call(n));
      } finally {
        if (o) throw o.error;
      }
    }
    t.complete();
  });
}
function J(e, t, n, r = 0, o = !1) {
  let i = t.schedule(function () {
    n(), o ? e.add(this.schedule(null, r)) : this.unsubscribe();
  }, r);
  if ((e.add(i), !o)) return i;
}
function cr(e, t = 0) {
  return _((n, r) => {
    n.subscribe(
      N(
        r,
        (o) => J(r, e, () => r.next(o), t),
        () => J(r, e, () => r.complete(), t),
        (o) => J(r, e, () => r.error(o), t)
      )
    );
  });
}
function ur(e, t = 0) {
  return _((n, r) => {
    r.add(e.schedule(() => n.subscribe(r), t));
  });
}
function Na(e, t) {
  return q(e).pipe(ur(t), cr(t));
}
function Aa(e, t) {
  return q(e).pipe(ur(t), cr(t));
}
function Ra(e, t) {
  return new R((n) => {
    let r = 0;
    return t.schedule(function () {
      r === e.length
        ? n.complete()
        : (n.next(e[r++]), n.closed || this.schedule());
    });
  });
}
function Oa(e, t) {
  return new R((n) => {
    let r;
    return (
      J(n, t, () => {
        (r = e[or]()),
          J(
            n,
            t,
            () => {
              let o, i;
              try {
                ({ value: o, done: i } = r.next());
              } catch (s) {
                n.error(s);
                return;
              }
              i ? n.complete() : n.next(o);
            },
            0,
            !0
          );
      }),
      () => y(r?.return) && r.return()
    );
  });
}
function lr(e, t) {
  if (!e) throw new Error("Iterable cannot be null");
  return new R((n) => {
    J(n, t, () => {
      let r = e[Symbol.asyncIterator]();
      J(
        n,
        t,
        () => {
          r.next().then((o) => {
            o.done ? n.complete() : n.next(o.value);
          });
        },
        0,
        !0
      );
    });
  });
}
function Pa(e, t) {
  return lr(sr(e), t);
}
function ka(e, t) {
  if (e != null) {
    if (tr(e)) return Na(e, t);
    if (Jn(e)) return Ra(e, t);
    if (er(e)) return Aa(e, t);
    if (nr(e)) return lr(e, t);
    if (ir(e)) return Oa(e, t);
    if (ar(e)) return Pa(e, t);
  }
  throw rr(e);
}
function z(e, t) {
  return t ? ka(e, t) : q(e);
}
function w(...e) {
  let t = $e(e);
  return z(e, t);
}
function bt(e, t) {
  let n = y(e) ? e : () => e,
    r = (o) => o.error(n());
  return new R(t ? (o) => t.schedule(r, 0, o) : r);
}
function Vo(e) {
  return !!e && (e instanceof R || (y(e.lift) && y(e.subscribe)));
}
var Te = vt(
  (e) =>
    function () {
      e(this),
        (this.name = "EmptyError"),
        (this.message = "no elements in sequence");
    }
);
function x(e, t) {
  return _((n, r) => {
    let o = 0;
    n.subscribe(
      N(r, (i) => {
        r.next(e.call(t, i, o++));
      })
    );
  });
}
var { isArray: af } = Array;
function cf(e, t) {
  return af(t) ? e(...t) : e(t);
}
function Fa(e) {
  return x((t) => cf(e, t));
}
var { isArray: uf } = Array,
  { getPrototypeOf: lf, prototype: df, keys: ff } = Object;
function La(e) {
  if (e.length === 1) {
    let t = e[0];
    if (uf(t)) return { args: t, keys: null };
    if (hf(t)) {
      let n = ff(t);
      return { args: n.map((r) => t[r]), keys: n };
    }
  }
  return { args: e, keys: null };
}
function hf(e) {
  return e && typeof e == "object" && lf(e) === df;
}
function ja(e, t) {
  return e.reduce((n, r, o) => ((n[r] = t[o]), n), {});
}
function dr(...e) {
  let t = $e(e),
    n = ba(e),
    { args: r, keys: o } = La(e);
  if (r.length === 0) return z([], t);
  let i = new R(pf(r, t, o ? (s) => ja(o, s) : te));
  return n ? i.pipe(Fa(n)) : i;
}
function pf(e, t, n = te) {
  return (r) => {
    Va(
      t,
      () => {
        let { length: o } = e,
          i = new Array(o),
          s = o,
          a = o;
        for (let c = 0; c < o; c++)
          Va(
            t,
            () => {
              let u = z(e[c], t),
                l = !1;
              u.subscribe(
                N(
                  r,
                  (d) => {
                    (i[c] = d), l || ((l = !0), a--), a || r.next(n(i.slice()));
                  },
                  () => {
                    --s || r.complete();
                  }
                )
              );
            },
            r
          );
      },
      r
    );
  };
}
function Va(e, t, n) {
  e ? J(n, e, t) : t();
}
function $a(e, t, n, r, o, i, s, a) {
  let c = [],
    u = 0,
    l = 0,
    d = !1,
    h = () => {
      d && !c.length && !u && t.complete();
    },
    f = (S) => (u < r ? m(S) : c.push(S)),
    m = (S) => {
      i && t.next(S), u++;
      let L = !1;
      q(n(S, l++)).subscribe(
        N(
          t,
          (H) => {
            o?.(H), i ? f(H) : t.next(H);
          },
          () => {
            L = !0;
          },
          void 0,
          () => {
            if (L)
              try {
                for (u--; c.length && u < r; ) {
                  let H = c.shift();
                  s ? J(t, s, () => m(H)) : m(H);
                }
                h();
              } catch (H) {
                t.error(H);
              }
          }
        )
      );
    };
  return (
    e.subscribe(
      N(t, f, () => {
        (d = !0), h();
      })
    ),
    () => {
      a?.();
    }
  );
}
function G(e, t, n = 1 / 0) {
  return y(t)
    ? G((r, o) => x((i, s) => t(r, i, o, s))(q(e(r, o))), n)
    : (typeof t == "number" && (n = t), _((r, o) => $a(r, o, e, n)));
}
function $o(e = 1 / 0) {
  return G(te, e);
}
function Ba() {
  return $o(1);
}
function Mt(...e) {
  return Ba()(z(e, $e(e)));
}
function fr(e) {
  return new R((t) => {
    q(e()).subscribe(t);
  });
}
function ge(e, t) {
  return _((n, r) => {
    let o = 0;
    n.subscribe(N(r, (i) => e.call(t, i, o++) && r.next(i)));
  });
}
function Be(e) {
  return _((t, n) => {
    let r = null,
      o = !1,
      i;
    (r = t.subscribe(
      N(n, void 0, void 0, (s) => {
        (i = q(e(s, Be(e)(t)))),
          r ? (r.unsubscribe(), (r = null), i.subscribe(n)) : (o = !0);
      })
    )),
      o && (r.unsubscribe(), (r = null), i.subscribe(n));
  });
}
function Ua(e, t, n, r, o) {
  return (i, s) => {
    let a = n,
      c = t,
      u = 0;
    i.subscribe(
      N(
        s,
        (l) => {
          let d = u++;
          (c = a ? e(c, l, d) : ((a = !0), l)), r && s.next(c);
        },
        o &&
          (() => {
            a && s.next(c), s.complete();
          })
      )
    );
  };
}
function St(e, t) {
  return y(t) ? G(e, t, 1) : G(e, 1);
}
function Ue(e) {
  return _((t, n) => {
    let r = !1;
    t.subscribe(
      N(
        n,
        (o) => {
          (r = !0), n.next(o);
        },
        () => {
          r || n.next(e), n.complete();
        }
      )
    );
  });
}
function _e(e) {
  return e <= 0
    ? () => ne
    : _((t, n) => {
        let r = 0;
        t.subscribe(
          N(n, (o) => {
            ++r <= e && (n.next(o), e <= r && n.complete());
          })
        );
      });
}
function Bo(e) {
  return x(() => e);
}
function hr(e = gf) {
  return _((t, n) => {
    let r = !1;
    t.subscribe(
      N(
        n,
        (o) => {
          (r = !0), n.next(o);
        },
        () => (r ? n.complete() : n.error(e()))
      )
    );
  });
}
function gf() {
  return new Te();
}
function rn(e) {
  return _((t, n) => {
    try {
      t.subscribe(n);
    } finally {
      n.add(e);
    }
  });
}
function Ee(e, t) {
  let n = arguments.length >= 2;
  return (r) =>
    r.pipe(
      e ? ge((o, i) => e(o, i, r)) : te,
      _e(1),
      n ? Ue(t) : hr(() => new Te())
    );
}
function xt(e) {
  return e <= 0
    ? () => ne
    : _((t, n) => {
        let r = [];
        t.subscribe(
          N(
            n,
            (o) => {
              r.push(o), e < r.length && r.shift();
            },
            () => {
              for (let o of r) n.next(o);
              n.complete();
            },
            void 0,
            () => {
              r = null;
            }
          )
        );
      });
}
function Uo(e, t) {
  let n = arguments.length >= 2;
  return (r) =>
    r.pipe(
      e ? ge((o, i) => e(o, i, r)) : te,
      xt(1),
      n ? Ue(t) : hr(() => new Te())
    );
}
function Ho(e, t) {
  return _(Ua(e, t, arguments.length >= 2, !0));
}
function zo(...e) {
  let t = $e(e);
  return _((n, r) => {
    (t ? Mt(e, n, t) : Mt(e, n)).subscribe(r);
  });
}
function me(e, t) {
  return _((n, r) => {
    let o = null,
      i = 0,
      s = !1,
      a = () => s && !o && r.complete();
    n.subscribe(
      N(
        r,
        (c) => {
          o?.unsubscribe();
          let u = 0,
            l = i++;
          q(e(c, l)).subscribe(
            (o = N(
              r,
              (d) => r.next(t ? t(c, d, l, u++) : d),
              () => {
                (o = null), a();
              }
            ))
          );
        },
        () => {
          (s = !0), a();
        }
      )
    );
  });
}
function Go(e) {
  return _((t, n) => {
    q(e).subscribe(N(n, () => n.complete(), nn)), !n.closed && t.subscribe(n);
  });
}
function Z(e, t, n) {
  let r = y(e) || t || n ? { next: e, error: t, complete: n } : e;
  return r
    ? _((o, i) => {
        var s;
        (s = r.subscribe) === null || s === void 0 || s.call(r);
        let a = !0;
        o.subscribe(
          N(
            i,
            (c) => {
              var u;
              (u = r.next) === null || u === void 0 || u.call(r, c), i.next(c);
            },
            () => {
              var c;
              (a = !1),
                (c = r.complete) === null || c === void 0 || c.call(r),
                i.complete();
            },
            (c) => {
              var u;
              (a = !1),
                (u = r.error) === null || u === void 0 || u.call(r, c),
                i.error(c);
            },
            () => {
              var c, u;
              a && ((c = r.unsubscribe) === null || c === void 0 || c.call(r)),
                (u = r.finalize) === null || u === void 0 || u.call(r);
            }
          )
        );
      })
    : te;
}
var v = class extends Error {
  constructor(t, n) {
    super(Ri(t, n)), (this.code = t);
  }
};
function Ri(e, t) {
  return `${`NG0${Math.abs(e)}`}${t ? ": " + t : ""}`;
}
function Oi(e) {
  return { toString: e }.toString();
}
var sn = globalThis;
function k(e) {
  for (let t in e) if (e[t] === k) return t;
  throw Error("Could not find renamed property on target object.");
}
function re(e) {
  if (typeof e == "string") return e;
  if (Array.isArray(e)) return "[" + e.map(re).join(", ") + "]";
  if (e == null) return "" + e;
  if (e.overriddenName) return `${e.overriddenName}`;
  if (e.name) return `${e.name}`;
  let t = e.toString();
  if (t == null) return "" + t;
  let n = t.indexOf(`
`);
  return n === -1 ? t : t.substring(0, n);
}
function Ha(e, t) {
  return e == null || e === ""
    ? t === null
      ? ""
      : t
    : t == null || t === ""
    ? e
    : e + " " + t;
}
var mf = k({ __forward_ref__: k });
function bc(e) {
  return (
    (e.__forward_ref__ = bc),
    (e.toString = function () {
      return re(this());
    }),
    e
  );
}
function ue(e) {
  return Mc(e) ? e() : e;
}
function Mc(e) {
  return (
    typeof e == "function" && e.hasOwnProperty(mf) && e.__forward_ref__ === bc
  );
}
function D(e) {
  return {
    token: e.token,
    providedIn: e.providedIn || null,
    factory: e.factory,
    value: void 0,
  };
}
function Fr(e) {
  return za(e, xc) || za(e, Tc);
}
function Sc(e) {
  return Fr(e) !== null;
}
function za(e, t) {
  return e.hasOwnProperty(t) ? e[t] : null;
}
function vf(e) {
  let t = e && (e[xc] || e[Tc]);
  return t || null;
}
function Ga(e) {
  return e && (e.hasOwnProperty(qa) || e.hasOwnProperty(yf)) ? e[qa] : null;
}
var xc = k({ ɵprov: k }),
  qa = k({ ɵinj: k }),
  Tc = k({ ngInjectableDef: k }),
  yf = k({ ngInjectorDef: k }),
  I = class {
    constructor(t, n) {
      (this._desc = t),
        (this.ngMetadataName = "InjectionToken"),
        (this.ɵprov = void 0),
        typeof n == "number"
          ? (this.__NG_ELEMENT_ID__ = n)
          : n !== void 0 &&
            (this.ɵprov = D({
              token: this,
              providedIn: n.providedIn || "root",
              factory: n.factory,
            }));
    }
    get multi() {
      return this;
    }
    toString() {
      return `InjectionToken ${this._desc}`;
    }
  };
function _c(e) {
  return e && !!e.ɵproviders;
}
var Df = k({ ɵcmp: k }),
  wf = k({ ɵdir: k }),
  Cf = k({ ɵpipe: k }),
  Ef = k({ ɵmod: k }),
  wr = k({ ɵfac: k }),
  on = k({ __NG_ELEMENT_ID__: k }),
  Wa = k({ __NG_ENV_ID__: k });
function If(e) {
  return typeof e == "string" ? e : e == null ? "" : String(e);
}
function bf(e) {
  return typeof e == "function"
    ? e.name || e.toString()
    : typeof e == "object" && e != null && typeof e.type == "function"
    ? e.type.name || e.type.toString()
    : If(e);
}
function Mf(e, t) {
  let n = t ? `. Dependency path: ${t.join(" > ")} > ${e}` : "";
  throw new v(-200, e);
}
function Pi(e, t) {
  throw new v(-201, !1);
}
var b = (function (e) {
    return (
      (e[(e.Default = 0)] = "Default"),
      (e[(e.Host = 1)] = "Host"),
      (e[(e.Self = 2)] = "Self"),
      (e[(e.SkipSelf = 4)] = "SkipSelf"),
      (e[(e.Optional = 8)] = "Optional"),
      e
    );
  })(b || {}),
  ti;
function Nc() {
  return ti;
}
function ce(e) {
  let t = ti;
  return (ti = e), t;
}
function Ac(e, t, n) {
  let r = Fr(e);
  if (r && r.providedIn == "root")
    return r.value === void 0 ? (r.value = r.factory()) : r.value;
  if (n & b.Optional) return null;
  if (t !== void 0) return t;
  Pi(e, "Injector");
}
var Sf = {},
  an = Sf,
  xf = "__NG_DI_FLAG__",
  Cr = "ngTempTokenPath",
  Tf = "ngTokenPath",
  _f = /\n/gm,
  Nf = "\u0275",
  Za = "__source",
  At;
function Af() {
  return At;
}
function He(e) {
  let t = At;
  return (At = e), t;
}
function Rf(e, t = b.Default) {
  if (At === void 0) throw new v(-203, !1);
  return At === null
    ? Ac(e, void 0, t)
    : At.get(e, t & b.Optional ? null : void 0, t);
}
function M(e, t = b.Default) {
  return (Nc() || Rf)(ue(e), t);
}
function p(e, t = b.Default) {
  return M(e, Lr(t));
}
function Lr(e) {
  return typeof e > "u" || typeof e == "number"
    ? e
    : 0 | (e.optional && 8) | (e.host && 1) | (e.self && 2) | (e.skipSelf && 4);
}
function ni(e) {
  let t = [];
  for (let n = 0; n < e.length; n++) {
    let r = ue(e[n]);
    if (Array.isArray(r)) {
      if (r.length === 0) throw new v(900, !1);
      let o,
        i = b.Default;
      for (let s = 0; s < r.length; s++) {
        let a = r[s],
          c = Of(a);
        typeof c == "number" ? (c === -1 ? (o = a.token) : (i |= c)) : (o = a);
      }
      t.push(M(o, i));
    } else t.push(M(r));
  }
  return t;
}
function Of(e) {
  return e[xf];
}
function Pf(e, t, n, r) {
  let o = e[Cr];
  throw (
    (t[Za] && o.unshift(t[Za]),
    (e.message = kf(
      `
` + e.message,
      o,
      n,
      r
    )),
    (e[Tf] = o),
    (e[Cr] = null),
    e)
  );
}
function kf(e, t, n, r = null) {
  e =
    e &&
    e.charAt(0) ===
      `
` &&
    e.charAt(1) == Nf
      ? e.slice(2)
      : e;
  let o = re(t);
  if (Array.isArray(t)) o = t.map(re).join(" -> ");
  else if (typeof t == "object") {
    let i = [];
    for (let s in t)
      if (t.hasOwnProperty(s)) {
        let a = t[s];
        i.push(s + ":" + (typeof a == "string" ? JSON.stringify(a) : re(a)));
      }
    o = `{${i.join(", ")}}`;
  }
  return `${n}${r ? "(" + r + ")" : ""}[${o}]: ${e.replace(
    _f,
    `
  `
  )}`;
}
function Ot(e, t) {
  let n = e.hasOwnProperty(wr);
  return n ? e[wr] : null;
}
function ki(e, t) {
  e.forEach((n) => (Array.isArray(n) ? ki(n, t) : t(n)));
}
function Rc(e, t, n) {
  t >= e.length ? e.push(n) : e.splice(t, 0, n);
}
function Er(e, t) {
  return t >= e.length - 1 ? e.pop() : e.splice(t, 1)[0];
}
var cn = {},
  Pt = [],
  kt = new I(""),
  Oc = new I("", -1),
  Pc = new I(""),
  Ir = class {
    get(t, n = an) {
      if (n === an) {
        let r = new Error(`NullInjectorError: No provider for ${re(t)}!`);
        throw ((r.name = "NullInjectorError"), r);
      }
      return n;
    }
  },
  kc = (function (e) {
    return (e[(e.OnPush = 0)] = "OnPush"), (e[(e.Default = 1)] = "Default"), e;
  })(kc || {}),
  be = (function (e) {
    return (
      (e[(e.Emulated = 0)] = "Emulated"),
      (e[(e.None = 2)] = "None"),
      (e[(e.ShadowDom = 3)] = "ShadowDom"),
      e
    );
  })(be || {}),
  qe = (function (e) {
    return (
      (e[(e.None = 0)] = "None"),
      (e[(e.SignalBased = 1)] = "SignalBased"),
      (e[(e.HasDecoratorInputTransform = 2)] = "HasDecoratorInputTransform"),
      e
    );
  })(qe || {});
function Ff(e, t, n) {
  let r = e.length;
  for (;;) {
    let o = e.indexOf(t, n);
    if (o === -1) return o;
    if (o === 0 || e.charCodeAt(o - 1) <= 32) {
      let i = t.length;
      if (o + i === r || e.charCodeAt(o + i) <= 32) return o;
    }
    n = o + 1;
  }
}
function ri(e, t, n) {
  let r = 0;
  for (; r < n.length; ) {
    let o = n[r];
    if (typeof o == "number") {
      if (o !== 0) break;
      r++;
      let i = n[r++],
        s = n[r++],
        a = n[r++];
      e.setAttribute(t, s, a, i);
    } else {
      let i = o,
        s = n[++r];
      jf(i) ? e.setProperty(t, i, s) : e.setAttribute(t, i, s), r++;
    }
  }
  return r;
}
function Lf(e) {
  return e === 3 || e === 4 || e === 6;
}
function jf(e) {
  return e.charCodeAt(0) === 64;
}
function Fi(e, t) {
  if (!(t === null || t.length === 0))
    if (e === null || e.length === 0) e = t.slice();
    else {
      let n = -1;
      for (let r = 0; r < t.length; r++) {
        let o = t[r];
        typeof o == "number"
          ? (n = o)
          : n === 0 ||
            (n === -1 || n === 2
              ? Ya(e, n, o, null, t[++r])
              : Ya(e, n, o, null, null));
      }
    }
  return e;
}
function Ya(e, t, n, r, o) {
  let i = 0,
    s = e.length;
  if (t === -1) s = -1;
  else
    for (; i < e.length; ) {
      let a = e[i++];
      if (typeof a == "number") {
        if (a === t) {
          s = -1;
          break;
        } else if (a > t) {
          s = i - 1;
          break;
        }
      }
    }
  for (; i < e.length; ) {
    let a = e[i];
    if (typeof a == "number") break;
    if (a === n) {
      if (r === null) {
        o !== null && (e[i + 1] = o);
        return;
      } else if (r === e[i + 1]) {
        e[i + 2] = o;
        return;
      }
    }
    i++, r !== null && i++, o !== null && i++;
  }
  s !== -1 && (e.splice(s, 0, t), (i = s + 1)),
    e.splice(i++, 0, n),
    r !== null && e.splice(i++, 0, r),
    o !== null && e.splice(i++, 0, o);
}
var Fc = "ng-template";
function Vf(e, t, n, r) {
  let o = 0;
  if (r) {
    for (; o < t.length && typeof t[o] == "string"; o += 2)
      if (t[o] === "class" && Ff(t[o + 1].toLowerCase(), n, 0) !== -1)
        return !0;
  } else if (Li(e)) return !1;
  if (((o = t.indexOf(1, o)), o > -1)) {
    let i;
    for (; ++o < t.length && typeof (i = t[o]) == "string"; )
      if (i.toLowerCase() === n) return !0;
  }
  return !1;
}
function Li(e) {
  return e.type === 4 && e.value !== Fc;
}
function $f(e, t, n) {
  let r = e.type === 4 && !n ? Fc : e.value;
  return t === r;
}
function Bf(e, t, n) {
  let r = 4,
    o = e.attrs,
    i = o !== null ? zf(o) : 0,
    s = !1;
  for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "number") {
      if (!s && !ve(r) && !ve(c)) return !1;
      if (s && ve(c)) continue;
      (s = !1), (r = c | (r & 1));
      continue;
    }
    if (!s)
      if (r & 4) {
        if (
          ((r = 2 | (r & 1)),
          (c !== "" && !$f(e, c, n)) || (c === "" && t.length === 1))
        ) {
          if (ve(r)) return !1;
          s = !0;
        }
      } else if (r & 8) {
        if (o === null || !Vf(e, o, c, n)) {
          if (ve(r)) return !1;
          s = !0;
        }
      } else {
        let u = t[++a],
          l = Uf(c, o, Li(e), n);
        if (l === -1) {
          if (ve(r)) return !1;
          s = !0;
          continue;
        }
        if (u !== "") {
          let d;
          if (
            (l > i ? (d = "") : (d = o[l + 1].toLowerCase()), r & 2 && u !== d)
          ) {
            if (ve(r)) return !1;
            s = !0;
          }
        }
      }
  }
  return ve(r) || s;
}
function ve(e) {
  return (e & 1) === 0;
}
function Uf(e, t, n, r) {
  if (t === null) return -1;
  let o = 0;
  if (r || !n) {
    let i = !1;
    for (; o < t.length; ) {
      let s = t[o];
      if (s === e) return o;
      if (s === 3 || s === 6) i = !0;
      else if (s === 1 || s === 2) {
        let a = t[++o];
        for (; typeof a == "string"; ) a = t[++o];
        continue;
      } else {
        if (s === 4) break;
        if (s === 0) {
          o += 4;
          continue;
        }
      }
      o += i ? 1 : 2;
    }
    return -1;
  } else return Gf(t, e);
}
function Hf(e, t, n = !1) {
  for (let r = 0; r < t.length; r++) if (Bf(e, t[r], n)) return !0;
  return !1;
}
function zf(e) {
  for (let t = 0; t < e.length; t++) {
    let n = e[t];
    if (Lf(n)) return t;
  }
  return e.length;
}
function Gf(e, t) {
  let n = e.indexOf(4);
  if (n > -1)
    for (n++; n < e.length; ) {
      let r = e[n];
      if (typeof r == "number") return -1;
      if (r === t) return n;
      n++;
    }
  return -1;
}
function Qa(e, t) {
  return e ? ":not(" + t.trim() + ")" : t;
}
function qf(e) {
  let t = e[0],
    n = 1,
    r = 2,
    o = "",
    i = !1;
  for (; n < e.length; ) {
    let s = e[n];
    if (typeof s == "string")
      if (r & 2) {
        let a = e[++n];
        o += "[" + s + (a.length > 0 ? '="' + a + '"' : "") + "]";
      } else r & 8 ? (o += "." + s) : r & 4 && (o += " " + s);
    else
      o !== "" && !ve(s) && ((t += Qa(i, o)), (o = "")),
        (r = s),
        (i = i || !ve(r));
    n++;
  }
  return o !== "" && (t += Qa(i, o)), t;
}
function Wf(e) {
  return e.map(qf).join(",");
}
function Zf(e) {
  let t = [],
    n = [],
    r = 1,
    o = 2;
  for (; r < e.length; ) {
    let i = e[r];
    if (typeof i == "string")
      o === 2 ? i !== "" && t.push(i, e[++r]) : o === 8 && n.push(i);
    else {
      if (!ve(o)) break;
      o = i;
    }
    r++;
  }
  return { attrs: t, classes: n };
}
function jr(e) {
  return Oi(() => {
    let t = Bc(e),
      n = j(g({}, t), {
        decls: e.decls,
        vars: e.vars,
        template: e.template,
        consts: e.consts || null,
        ngContentSelectors: e.ngContentSelectors,
        onPush: e.changeDetection === kc.OnPush,
        directiveDefs: null,
        pipeDefs: null,
        dependencies: (t.standalone && e.dependencies) || null,
        getStandaloneInjector: null,
        signals: e.signals ?? !1,
        data: e.data || {},
        encapsulation: e.encapsulation || be.Emulated,
        styles: e.styles || Pt,
        _: null,
        schemas: e.schemas || null,
        tView: null,
        id: "",
      });
    Uc(n);
    let r = e.dependencies;
    return (
      (n.directiveDefs = Xa(r, !1)), (n.pipeDefs = Xa(r, !0)), (n.id = Kf(n)), n
    );
  });
}
function Yf(e) {
  return ot(e) || Lc(e);
}
function Qf(e) {
  return e !== null;
}
function Ka(e, t) {
  if (e == null) return cn;
  let n = {};
  for (let r in e)
    if (e.hasOwnProperty(r)) {
      let o = e[r],
        i,
        s,
        a = qe.None;
      Array.isArray(o)
        ? ((a = o[0]), (i = o[1]), (s = o[2] ?? i))
        : ((i = o), (s = o)),
        t ? ((n[i] = a !== qe.None ? [r, a] : r), (t[i] = s)) : (n[i] = r);
    }
  return n;
}
function ji(e) {
  return Oi(() => {
    let t = Bc(e);
    return Uc(t), t;
  });
}
function ot(e) {
  return e[Df] || null;
}
function Lc(e) {
  return e[wf] || null;
}
function jc(e) {
  return e[Cf] || null;
}
function Vc(e) {
  let t = ot(e) || Lc(e) || jc(e);
  return t !== null ? t.standalone : !1;
}
function $c(e, t) {
  let n = e[Ef] || null;
  if (!n && t === !0)
    throw new Error(`Type ${re(e)} does not have '\u0275mod' property.`);
  return n;
}
function Bc(e) {
  let t = {};
  return {
    type: e.type,
    providersResolver: null,
    factory: null,
    hostBindings: e.hostBindings || null,
    hostVars: e.hostVars || 0,
    hostAttrs: e.hostAttrs || null,
    contentQueries: e.contentQueries || null,
    declaredInputs: t,
    inputTransforms: null,
    inputConfig: e.inputs || cn,
    exportAs: e.exportAs || null,
    standalone: e.standalone === !0,
    signals: e.signals === !0,
    selectors: e.selectors || Pt,
    viewQuery: e.viewQuery || null,
    features: e.features || null,
    setInput: null,
    findHostDirectiveDefs: null,
    hostDirectives: null,
    inputs: Ka(e.inputs, t),
    outputs: Ka(e.outputs),
    debugInfo: null,
  };
}
function Uc(e) {
  e.features?.forEach((t) => t(e));
}
function Xa(e, t) {
  if (!e) return null;
  let n = t ? jc : Yf;
  return () => (typeof e == "function" ? e() : e).map((r) => n(r)).filter(Qf);
}
function Kf(e) {
  let t = 0,
    n = [
      e.selectors,
      e.ngContentSelectors,
      e.hostVars,
      e.hostAttrs,
      e.consts,
      e.vars,
      e.decls,
      e.encapsulation,
      e.standalone,
      e.signals,
      e.exportAs,
      JSON.stringify(e.inputs),
      JSON.stringify(e.outputs),
      Object.getOwnPropertyNames(e.type.prototype),
      !!e.contentQueries,
      !!e.viewQuery,
    ].join("|");
  for (let o of n) t = (Math.imul(31, t) + o.charCodeAt(0)) << 0;
  return (t += 2147483648), "c" + t;
}
function Vr(e) {
  return { ɵproviders: e };
}
function Xf(...e) {
  return { ɵproviders: Hc(!0, e), ɵfromNgModule: !0 };
}
function Hc(e, ...t) {
  let n = [],
    r = new Set(),
    o,
    i = (s) => {
      n.push(s);
    };
  return (
    ki(t, (s) => {
      let a = s;
      oi(a, i, [], r) && ((o ||= []), o.push(a));
    }),
    o !== void 0 && zc(o, i),
    n
  );
}
function zc(e, t) {
  for (let n = 0; n < e.length; n++) {
    let { ngModule: r, providers: o } = e[n];
    Vi(o, (i) => {
      t(i, r);
    });
  }
}
function oi(e, t, n, r) {
  if (((e = ue(e)), !e)) return !1;
  let o = null,
    i = Ga(e),
    s = !i && ot(e);
  if (!i && !s) {
    let c = e.ngModule;
    if (((i = Ga(c)), i)) o = c;
    else return !1;
  } else {
    if (s && !s.standalone) return !1;
    o = e;
  }
  let a = r.has(o);
  if (s) {
    if (a) return !1;
    if ((r.add(o), s.dependencies)) {
      let c =
        typeof s.dependencies == "function" ? s.dependencies() : s.dependencies;
      for (let u of c) oi(u, t, n, r);
    }
  } else if (i) {
    if (i.imports != null && !a) {
      r.add(o);
      let u;
      try {
        ki(i.imports, (l) => {
          oi(l, t, n, r) && ((u ||= []), u.push(l));
        });
      } finally {
      }
      u !== void 0 && zc(u, t);
    }
    if (!a) {
      let u = Ot(o) || (() => new o());
      t({ provide: o, useFactory: u, deps: Pt }, o),
        t({ provide: Pc, useValue: o, multi: !0 }, o),
        t({ provide: kt, useValue: () => M(o), multi: !0 }, o);
    }
    let c = i.providers;
    if (c != null && !a) {
      let u = e;
      Vi(c, (l) => {
        t(l, u);
      });
    }
  } else return !1;
  return o !== e && e.providers !== void 0;
}
function Vi(e, t) {
  for (let n of e)
    _c(n) && (n = n.ɵproviders), Array.isArray(n) ? Vi(n, t) : t(n);
}
var Jf = k({ provide: String, useValue: k });
function Gc(e) {
  return e !== null && typeof e == "object" && Jf in e;
}
function eh(e) {
  return !!(e && e.useExisting);
}
function th(e) {
  return !!(e && e.useFactory);
}
function ii(e) {
  return typeof e == "function";
}
var $r = new I(""),
  gr = {},
  nh = {},
  qo;
function $i() {
  return qo === void 0 && (qo = new Ir()), qo;
}
var fe = class {},
  un = class extends fe {
    get destroyed() {
      return this._destroyed;
    }
    constructor(t, n, r, o) {
      super(),
        (this.parent = n),
        (this.source = r),
        (this.scopes = o),
        (this.records = new Map()),
        (this._ngOnDestroyHooks = new Set()),
        (this._onDestroyHooks = []),
        (this._destroyed = !1),
        ai(t, (s) => this.processProvider(s)),
        this.records.set(Oc, Tt(void 0, this)),
        o.has("environment") && this.records.set(fe, Tt(void 0, this));
      let i = this.records.get($r);
      i != null && typeof i.value == "string" && this.scopes.add(i.value),
        (this.injectorDefTypes = new Set(this.get(Pc, Pt, b.Self)));
    }
    destroy() {
      this.assertNotDestroyed(), (this._destroyed = !0);
      let t = P(null);
      try {
        for (let r of this._ngOnDestroyHooks) r.ngOnDestroy();
        let n = this._onDestroyHooks;
        this._onDestroyHooks = [];
        for (let r of n) r();
      } finally {
        this.records.clear(),
          this._ngOnDestroyHooks.clear(),
          this.injectorDefTypes.clear(),
          P(t);
      }
    }
    onDestroy(t) {
      return (
        this.assertNotDestroyed(),
        this._onDestroyHooks.push(t),
        () => this.removeOnDestroy(t)
      );
    }
    runInContext(t) {
      this.assertNotDestroyed();
      let n = He(this),
        r = ce(void 0),
        o;
      try {
        return t();
      } finally {
        He(n), ce(r);
      }
    }
    get(t, n = an, r = b.Default) {
      if ((this.assertNotDestroyed(), t.hasOwnProperty(Wa))) return t[Wa](this);
      r = Lr(r);
      let o,
        i = He(this),
        s = ce(void 0);
      try {
        if (!(r & b.SkipSelf)) {
          let c = this.records.get(t);
          if (c === void 0) {
            let u = ch(t) && Fr(t);
            u && this.injectableDefInScope(u)
              ? (c = Tt(si(t), gr))
              : (c = null),
              this.records.set(t, c);
          }
          if (c != null) return this.hydrate(t, c);
        }
        let a = r & b.Self ? $i() : this.parent;
        return (n = r & b.Optional && n === an ? null : n), a.get(t, n);
      } catch (a) {
        if (a.name === "NullInjectorError") {
          if (((a[Cr] = a[Cr] || []).unshift(re(t)), i)) throw a;
          return Pf(a, t, "R3InjectorError", this.source);
        } else throw a;
      } finally {
        ce(s), He(i);
      }
    }
    resolveInjectorInitializers() {
      let t = P(null),
        n = He(this),
        r = ce(void 0),
        o;
      try {
        let i = this.get(kt, Pt, b.Self);
        for (let s of i) s();
      } finally {
        He(n), ce(r), P(t);
      }
    }
    toString() {
      let t = [],
        n = this.records;
      for (let r of n.keys()) t.push(re(r));
      return `R3Injector[${t.join(", ")}]`;
    }
    assertNotDestroyed() {
      if (this._destroyed) throw new v(205, !1);
    }
    processProvider(t) {
      t = ue(t);
      let n = ii(t) ? t : ue(t && t.provide),
        r = oh(t);
      if (!ii(t) && t.multi === !0) {
        let o = this.records.get(n);
        o ||
          ((o = Tt(void 0, gr, !0)),
          (o.factory = () => ni(o.multi)),
          this.records.set(n, o)),
          (n = t),
          o.multi.push(t);
      }
      this.records.set(n, r);
    }
    hydrate(t, n) {
      let r = P(null);
      try {
        return (
          n.value === gr && ((n.value = nh), (n.value = n.factory())),
          typeof n.value == "object" &&
            n.value &&
            ah(n.value) &&
            this._ngOnDestroyHooks.add(n.value),
          n.value
        );
      } finally {
        P(r);
      }
    }
    injectableDefInScope(t) {
      if (!t.providedIn) return !1;
      let n = ue(t.providedIn);
      return typeof n == "string"
        ? n === "any" || this.scopes.has(n)
        : this.injectorDefTypes.has(n);
    }
    removeOnDestroy(t) {
      let n = this._onDestroyHooks.indexOf(t);
      n !== -1 && this._onDestroyHooks.splice(n, 1);
    }
  };
function si(e) {
  let t = Fr(e),
    n = t !== null ? t.factory : Ot(e);
  if (n !== null) return n;
  if (e instanceof I) throw new v(204, !1);
  if (e instanceof Function) return rh(e);
  throw new v(204, !1);
}
function rh(e) {
  if (e.length > 0) throw new v(204, !1);
  let n = vf(e);
  return n !== null ? () => n.factory(e) : () => new e();
}
function oh(e) {
  if (Gc(e)) return Tt(void 0, e.useValue);
  {
    let t = ih(e);
    return Tt(t, gr);
  }
}
function ih(e, t, n) {
  let r;
  if (ii(e)) {
    let o = ue(e);
    return Ot(o) || si(o);
  } else if (Gc(e)) r = () => ue(e.useValue);
  else if (th(e)) r = () => e.useFactory(...ni(e.deps || []));
  else if (eh(e)) r = () => M(ue(e.useExisting));
  else {
    let o = ue(e && (e.useClass || e.provide));
    if (sh(e)) r = () => new o(...ni(e.deps));
    else return Ot(o) || si(o);
  }
  return r;
}
function Tt(e, t, n = !1) {
  return { factory: e, value: t, multi: n ? [] : void 0 };
}
function sh(e) {
  return !!e.deps;
}
function ah(e) {
  return (
    e !== null && typeof e == "object" && typeof e.ngOnDestroy == "function"
  );
}
function ch(e) {
  return typeof e == "function" || (typeof e == "object" && e instanceof I);
}
function ai(e, t) {
  for (let n of e)
    Array.isArray(n) ? ai(n, t) : n && _c(n) ? ai(n.ɵproviders, t) : t(n);
}
function Re(e, t) {
  e instanceof un && e.assertNotDestroyed();
  let n,
    r = He(e),
    o = ce(void 0);
  try {
    return t();
  } finally {
    He(r), ce(o);
  }
}
function uh() {
  return Nc() !== void 0 || Af() != null;
}
function lh(e) {
  return typeof e == "function";
}
var Oe = 0,
  T = 1,
  C = 2,
  X = 3,
  ye = 4,
  we = 5,
  br = 6,
  Ja = 7,
  We = 8,
  Ft = 9,
  Ne = 10,
  Me = 11,
  ln = 12,
  ec = 13,
  yn = 14,
  Se = 15,
  dn = 16,
  _t = 17,
  Br = 18,
  Ur = 19,
  qc = 20,
  Ge = 21,
  Wo = 22,
  le = 23,
  it = 25,
  Wc = 1;
var st = 7,
  Mr = 8,
  Sr = 9,
  de = 10,
  xr = (function (e) {
    return (
      (e[(e.None = 0)] = "None"),
      (e[(e.HasTransplantedViews = 2)] = "HasTransplantedViews"),
      e
    );
  })(xr || {});
function nt(e) {
  return Array.isArray(e) && typeof e[Wc] == "object";
}
function Pe(e) {
  return Array.isArray(e) && e[Wc] === !0;
}
function Zc(e) {
  return (e.flags & 4) !== 0;
}
function Bi(e) {
  return e.componentOffset > -1;
}
function dh(e) {
  return (e.flags & 1) === 1;
}
function Dn(e) {
  return !!e.template;
}
function ci(e) {
  return (e[C] & 512) !== 0;
}
var ui = class {
  constructor(t, n, r) {
    (this.previousValue = t), (this.currentValue = n), (this.firstChange = r);
  }
  isFirstChange() {
    return this.firstChange;
  }
};
function Yc(e, t, n, r) {
  t !== null ? t.applyValueToInputSignal(t, r) : (e[n] = r);
}
function Hr() {
  return Qc;
}
function Qc(e) {
  return e.type.prototype.ngOnChanges && (e.setInput = hh), fh;
}
Hr.ngInherit = !0;
function fh() {
  let e = Xc(this),
    t = e?.current;
  if (t) {
    let n = e.previous;
    if (n === cn) e.previous = t;
    else for (let r in t) n[r] = t[r];
    (e.current = null), this.ngOnChanges(t);
  }
}
function hh(e, t, n, r, o) {
  let i = this.declaredInputs[r],
    s = Xc(e) || ph(e, { previous: cn, current: null }),
    a = s.current || (s.current = {}),
    c = s.previous,
    u = c[i];
  (a[i] = new ui(u && u.currentValue, n, c === cn)), Yc(e, t, o, n);
}
var Kc = "__ngSimpleChanges__";
function Xc(e) {
  return e[Kc] || null;
}
function ph(e, t) {
  return (e[Kc] = t);
}
var tc = null;
var ze = function (e, t, n) {
    tc?.(e, t, n);
  },
  gh = "svg",
  mh = "math";
function Ze(e) {
  for (; Array.isArray(e); ) e = e[Oe];
  return e;
}
function ke(e, t) {
  return Ze(t[e.index]);
}
function vh(e, t) {
  return e.data[t];
}
function wn(e, t) {
  let n = t[e];
  return nt(n) ? n : n[Oe];
}
function Ui(e) {
  return (e[C] & 128) === 128;
}
function yh(e) {
  return Pe(e[X]);
}
function nc(e, t) {
  return t == null ? null : e[t];
}
function Jc(e) {
  e[_t] = 0;
}
function eu(e) {
  e[C] & 1024 || ((e[C] |= 1024), Ui(e) && zr(e));
}
function fn(e) {
  return !!(e[C] & 9216 || e[le]?.dirty);
}
function li(e) {
  e[Ne].changeDetectionScheduler?.notify(7),
    e[C] & 64 && (e[C] |= 1024),
    fn(e) && zr(e);
}
function zr(e) {
  e[Ne].changeDetectionScheduler?.notify(0);
  let t = at(e);
  for (; t !== null && !(t[C] & 8192 || ((t[C] |= 8192), !Ui(t))); ) t = at(t);
}
function tu(e, t) {
  if ((e[C] & 256) === 256) throw new v(911, !1);
  e[Ge] === null && (e[Ge] = []), e[Ge].push(t);
}
function Dh(e, t) {
  if (e[Ge] === null) return;
  let n = e[Ge].indexOf(t);
  n !== -1 && e[Ge].splice(n, 1);
}
function at(e) {
  let t = e[X];
  return Pe(t) ? t[X] : t;
}
var O = { lFrame: lu(null), bindingsEnabled: !0, skipHydrationRootTNode: null };
var nu = !1;
function wh() {
  return O.lFrame.elementDepthCount;
}
function Ch() {
  O.lFrame.elementDepthCount++;
}
function Eh() {
  O.lFrame.elementDepthCount--;
}
function ru() {
  return O.bindingsEnabled;
}
function Ih() {
  return O.skipHydrationRootTNode !== null;
}
function bh(e) {
  return O.skipHydrationRootTNode === e;
}
function Mh() {
  O.skipHydrationRootTNode = null;
}
function De() {
  return O.lFrame.lView;
}
function Hi() {
  return O.lFrame.tView;
}
function Fe() {
  let e = ou();
  for (; e !== null && e.type === 64; ) e = e.parent;
  return e;
}
function ou() {
  return O.lFrame.currentTNode;
}
function Sh() {
  let e = O.lFrame,
    t = e.currentTNode;
  return e.isParent ? t : t.parent;
}
function Gr(e, t) {
  let n = O.lFrame;
  (n.currentTNode = e), (n.isParent = t);
}
function iu() {
  return O.lFrame.isParent;
}
function xh() {
  O.lFrame.isParent = !1;
}
function su() {
  return nu;
}
function rc(e) {
  nu = e;
}
function Th(e) {
  return (O.lFrame.bindingIndex = e);
}
function _h() {
  return O.lFrame.inI18n;
}
function Nh(e, t) {
  let n = O.lFrame;
  (n.bindingIndex = n.bindingRootIndex = e), di(t);
}
function Ah() {
  return O.lFrame.currentDirectiveIndex;
}
function di(e) {
  O.lFrame.currentDirectiveIndex = e;
}
function au(e) {
  O.lFrame.currentQueryIndex = e;
}
function Rh(e) {
  let t = e[T];
  return t.type === 2 ? t.declTNode : t.type === 1 ? e[we] : null;
}
function cu(e, t, n) {
  if (n & b.SkipSelf) {
    let o = t,
      i = e;
    for (; (o = o.parent), o === null && !(n & b.Host); )
      if (((o = Rh(i)), o === null || ((i = i[yn]), o.type & 10))) break;
    if (o === null) return !1;
    (t = o), (e = i);
  }
  let r = (O.lFrame = uu());
  return (r.currentTNode = t), (r.lView = e), !0;
}
function zi(e) {
  let t = uu(),
    n = e[T];
  (O.lFrame = t),
    (t.currentTNode = n.firstChild),
    (t.lView = e),
    (t.tView = n),
    (t.contextLView = e),
    (t.bindingIndex = n.bindingStartIndex),
    (t.inI18n = !1);
}
function uu() {
  let e = O.lFrame,
    t = e === null ? null : e.child;
  return t === null ? lu(e) : t;
}
function lu(e) {
  let t = {
    currentTNode: null,
    isParent: !0,
    lView: null,
    tView: null,
    selectedIndex: -1,
    contextLView: null,
    elementDepthCount: 0,
    currentNamespace: null,
    currentDirectiveIndex: -1,
    bindingRootIndex: -1,
    bindingIndex: -1,
    currentQueryIndex: 0,
    parent: e,
    child: null,
    inI18n: !1,
  };
  return e !== null && (e.child = t), t;
}
function du() {
  let e = O.lFrame;
  return (O.lFrame = e.parent), (e.currentTNode = null), (e.lView = null), e;
}
var fu = du;
function Gi() {
  let e = du();
  (e.isParent = !0),
    (e.tView = null),
    (e.selectedIndex = -1),
    (e.contextLView = null),
    (e.elementDepthCount = 0),
    (e.currentDirectiveIndex = -1),
    (e.currentNamespace = null),
    (e.bindingRootIndex = -1),
    (e.bindingIndex = -1),
    (e.currentQueryIndex = 0);
}
function Oh() {
  return O.lFrame.selectedIndex;
}
function ct(e) {
  O.lFrame.selectedIndex = e;
}
function Ph() {
  return O.lFrame.currentNamespace;
}
var hu = !0;
function pu() {
  return hu;
}
function gu(e) {
  hu = e;
}
function kh(e, t, n) {
  let { ngOnChanges: r, ngOnInit: o, ngDoCheck: i } = t.type.prototype;
  if (r) {
    let s = Qc(t);
    (n.preOrderHooks ??= []).push(e, s),
      (n.preOrderCheckHooks ??= []).push(e, s);
  }
  o && (n.preOrderHooks ??= []).push(0 - e, o),
    i &&
      ((n.preOrderHooks ??= []).push(e, i),
      (n.preOrderCheckHooks ??= []).push(e, i));
}
function mu(e, t) {
  for (let n = t.directiveStart, r = t.directiveEnd; n < r; n++) {
    let i = e.data[n].type.prototype,
      {
        ngAfterContentInit: s,
        ngAfterContentChecked: a,
        ngAfterViewInit: c,
        ngAfterViewChecked: u,
        ngOnDestroy: l,
      } = i;
    s && (e.contentHooks ??= []).push(-n, s),
      a &&
        ((e.contentHooks ??= []).push(n, a),
        (e.contentCheckHooks ??= []).push(n, a)),
      c && (e.viewHooks ??= []).push(-n, c),
      u &&
        ((e.viewHooks ??= []).push(n, u), (e.viewCheckHooks ??= []).push(n, u)),
      l != null && (e.destroyHooks ??= []).push(n, l);
  }
}
function mr(e, t, n) {
  vu(e, t, 3, n);
}
function vr(e, t, n, r) {
  (e[C] & 3) === n && vu(e, t, n, r);
}
function Zo(e, t) {
  let n = e[C];
  (n & 3) === t && ((n &= 16383), (n += 1), (e[C] = n));
}
function vu(e, t, n, r) {
  let o = r !== void 0 ? e[_t] & 65535 : 0,
    i = r ?? -1,
    s = t.length - 1,
    a = 0;
  for (let c = o; c < s; c++)
    if (typeof t[c + 1] == "number") {
      if (((a = t[c]), r != null && a >= r)) break;
    } else
      t[c] < 0 && (e[_t] += 65536),
        (a < i || i == -1) &&
          (Fh(e, n, t, c), (e[_t] = (e[_t] & 4294901760) + c + 2)),
        c++;
}
function oc(e, t) {
  ze(4, e, t);
  let n = P(null);
  try {
    t.call(e);
  } finally {
    P(n), ze(5, e, t);
  }
}
function Fh(e, t, n, r) {
  let o = n[r] < 0,
    i = n[r + 1],
    s = o ? -n[r] : n[r],
    a = e[s];
  o
    ? e[C] >> 14 < e[_t] >> 16 &&
      (e[C] & 3) === t &&
      ((e[C] += 16384), oc(a, i))
    : oc(a, i);
}
var Rt = -1,
  hn = class {
    constructor(t, n, r) {
      (this.factory = t),
        (this.resolving = !1),
        (this.canSeeViewProviders = n),
        (this.injectImpl = r);
    }
  };
function Lh(e) {
  return e instanceof hn;
}
function jh(e) {
  return (e.flags & 8) !== 0;
}
function Vh(e) {
  return (e.flags & 16) !== 0;
}
var Yo = {},
  fi = class {
    constructor(t, n) {
      (this.injector = t), (this.parentInjector = n);
    }
    get(t, n, r) {
      r = Lr(r);
      let o = this.injector.get(t, Yo, r);
      return o !== Yo || n === Yo ? o : this.parentInjector.get(t, n, r);
    }
  };
function yu(e) {
  return e !== Rt;
}
function Tr(e) {
  return e & 32767;
}
function $h(e) {
  return e >> 16;
}
function _r(e, t) {
  let n = $h(e),
    r = t;
  for (; n > 0; ) (r = r[yn]), n--;
  return r;
}
var hi = !0;
function ic(e) {
  let t = hi;
  return (hi = e), t;
}
var Bh = 256,
  Du = Bh - 1,
  wu = 5,
  Uh = 0,
  Ie = {};
function Hh(e, t, n) {
  let r;
  typeof n == "string"
    ? (r = n.charCodeAt(0) || 0)
    : n.hasOwnProperty(on) && (r = n[on]),
    r == null && (r = n[on] = Uh++);
  let o = r & Du,
    i = 1 << o;
  t.data[e + (o >> wu)] |= i;
}
function Cu(e, t) {
  let n = Eu(e, t);
  if (n !== -1) return n;
  let r = t[T];
  r.firstCreatePass &&
    ((e.injectorIndex = t.length),
    Qo(r.data, e),
    Qo(t, null),
    Qo(r.blueprint, null));
  let o = qi(e, t),
    i = e.injectorIndex;
  if (yu(o)) {
    let s = Tr(o),
      a = _r(o, t),
      c = a[T].data;
    for (let u = 0; u < 8; u++) t[i + u] = a[s + u] | c[s + u];
  }
  return (t[i + 8] = o), i;
}
function Qo(e, t) {
  e.push(0, 0, 0, 0, 0, 0, 0, 0, t);
}
function Eu(e, t) {
  return e.injectorIndex === -1 ||
    (e.parent && e.parent.injectorIndex === e.injectorIndex) ||
    t[e.injectorIndex + 8] === null
    ? -1
    : e.injectorIndex;
}
function qi(e, t) {
  if (e.parent && e.parent.injectorIndex !== -1) return e.parent.injectorIndex;
  let n = 0,
    r = null,
    o = t;
  for (; o !== null; ) {
    if (((r = xu(o)), r === null)) return Rt;
    if ((n++, (o = o[yn]), r.injectorIndex !== -1))
      return r.injectorIndex | (n << 16);
  }
  return Rt;
}
function zh(e, t, n) {
  Hh(e, t, n);
}
function Iu(e, t, n) {
  if (n & b.Optional || e !== void 0) return e;
  Pi(t, "NodeInjector");
}
function bu(e, t, n, r) {
  if (
    (n & b.Optional && r === void 0 && (r = null), !(n & (b.Self | b.Host)))
  ) {
    let o = e[Ft],
      i = ce(void 0);
    try {
      return o ? o.get(t, r, n & b.Optional) : Ac(t, r, n & b.Optional);
    } finally {
      ce(i);
    }
  }
  return Iu(r, t, n);
}
function Mu(e, t, n, r = b.Default, o) {
  if (e !== null) {
    if (t[C] & 2048 && !(r & b.Self)) {
      let s = Yh(e, t, n, r, Ie);
      if (s !== Ie) return s;
    }
    let i = Su(e, t, n, r, Ie);
    if (i !== Ie) return i;
  }
  return bu(t, n, r, o);
}
function Su(e, t, n, r, o) {
  let i = Wh(n);
  if (typeof i == "function") {
    if (!cu(t, e, r)) return r & b.Host ? Iu(o, n, r) : bu(t, n, r, o);
    try {
      let s;
      if (((s = i(r)), s == null && !(r & b.Optional))) Pi(n);
      else return s;
    } finally {
      fu();
    }
  } else if (typeof i == "number") {
    let s = null,
      a = Eu(e, t),
      c = Rt,
      u = r & b.Host ? t[Se][we] : null;
    for (
      (a === -1 || r & b.SkipSelf) &&
      ((c = a === -1 ? qi(e, t) : t[a + 8]),
      c === Rt || !ac(r, !1)
        ? (a = -1)
        : ((s = t[T]), (a = Tr(c)), (t = _r(c, t))));
      a !== -1;

    ) {
      let l = t[T];
      if (sc(i, a, l.data)) {
        let d = Gh(a, t, n, s, r, u);
        if (d !== Ie) return d;
      }
      (c = t[a + 8]),
        c !== Rt && ac(r, t[T].data[a + 8] === u) && sc(i, a, t)
          ? ((s = l), (a = Tr(c)), (t = _r(c, t)))
          : (a = -1);
    }
  }
  return o;
}
function Gh(e, t, n, r, o, i) {
  let s = t[T],
    a = s.data[e + 8],
    c = r == null ? Bi(a) && hi : r != s && (a.type & 3) !== 0,
    u = o & b.Host && i === a,
    l = qh(a, s, n, c, u);
  return l !== null ? pn(t, s, l, a) : Ie;
}
function qh(e, t, n, r, o) {
  let i = e.providerIndexes,
    s = t.data,
    a = i & 1048575,
    c = e.directiveStart,
    u = e.directiveEnd,
    l = i >> 20,
    d = r ? a : a + l,
    h = o ? a + l : u;
  for (let f = d; f < h; f++) {
    let m = s[f];
    if ((f < c && n === m) || (f >= c && m.type === n)) return f;
  }
  if (o) {
    let f = s[c];
    if (f && Dn(f) && f.type === n) return c;
  }
  return null;
}
function pn(e, t, n, r) {
  let o = e[n],
    i = t.data;
  if (Lh(o)) {
    let s = o;
    s.resolving && Mf(bf(i[n]));
    let a = ic(s.canSeeViewProviders);
    s.resolving = !0;
    let c,
      u = s.injectImpl ? ce(s.injectImpl) : null,
      l = cu(e, r, b.Default);
    try {
      (o = e[n] = s.factory(void 0, i, e, r)),
        t.firstCreatePass && n >= r.directiveStart && kh(n, i[n], t);
    } finally {
      u !== null && ce(u), ic(a), (s.resolving = !1), fu();
    }
  }
  return o;
}
function Wh(e) {
  if (typeof e == "string") return e.charCodeAt(0) || 0;
  let t = e.hasOwnProperty(on) ? e[on] : void 0;
  return typeof t == "number" ? (t >= 0 ? t & Du : Zh) : t;
}
function sc(e, t, n) {
  let r = 1 << e;
  return !!(n[t + (e >> wu)] & r);
}
function ac(e, t) {
  return !(e & b.Self) && !(e & b.Host && t);
}
var rt = class {
  constructor(t, n) {
    (this._tNode = t), (this._lView = n);
  }
  get(t, n, r) {
    return Mu(this._tNode, this._lView, t, Lr(r), n);
  }
};
function Zh() {
  return new rt(Fe(), De());
}
function Wi(e) {
  return Oi(() => {
    let t = e.prototype.constructor,
      n = t[wr] || pi(t),
      r = Object.prototype,
      o = Object.getPrototypeOf(e.prototype).constructor;
    for (; o && o !== r; ) {
      let i = o[wr] || pi(o);
      if (i && i !== n) return i;
      o = Object.getPrototypeOf(o);
    }
    return (i) => new i();
  });
}
function pi(e) {
  return Mc(e)
    ? () => {
        let t = pi(ue(e));
        return t && t();
      }
    : Ot(e);
}
function Yh(e, t, n, r, o) {
  let i = e,
    s = t;
  for (; i !== null && s !== null && s[C] & 2048 && !(s[C] & 512); ) {
    let a = Su(i, s, n, r | b.Self, Ie);
    if (a !== Ie) return a;
    let c = i.parent;
    if (!c) {
      let u = s[qc];
      if (u) {
        let l = u.get(n, Ie, r);
        if (l !== Ie) return l;
      }
      (c = xu(s)), (s = s[yn]);
    }
    i = c;
  }
  return o;
}
function xu(e) {
  let t = e[T],
    n = t.type;
  return n === 2 ? t.declTNode : n === 1 ? e[we] : null;
}
function cc(e, t = null, n = null, r) {
  let o = Tu(e, t, n, r);
  return o.resolveInjectorInitializers(), o;
}
function Tu(e, t = null, n = null, r, o = new Set()) {
  let i = [n || Pt, Xf(e)];
  return (
    (r = r || (typeof e == "object" ? void 0 : re(e))),
    new un(i, t || $i(), r || null, o)
  );
}
var tt = class tt {
  static create(t, n) {
    if (Array.isArray(t)) return cc({ name: "" }, n, t, "");
    {
      let r = t.name ?? "";
      return cc({ name: r }, t.parent, t.providers, r);
    }
  }
};
(tt.THROW_IF_NOT_FOUND = an),
  (tt.NULL = new Ir()),
  (tt.ɵprov = D({ token: tt, providedIn: "any", factory: () => M(Oc) })),
  (tt.__NG_ELEMENT_ID__ = -1);
var ut = tt;
var Qh = new I("");
Qh.__NG_ELEMENT_ID__ = (e) => {
  let t = Fe();
  if (t === null) throw new v(204, !1);
  if (t.type & 2) return t.value;
  if (e & b.Optional) return null;
  throw new v(204, !1);
};
var Kh = "ngOriginalError";
function Ko(e) {
  return e[Kh];
}
var Ae = class {
    constructor() {
      this._console = console;
    }
    handleError(t) {
      let n = this._findOriginalError(t);
      this._console.error("ERROR", t),
        n && this._console.error("ORIGINAL ERROR", n);
    }
    _findOriginalError(t) {
      let n = t && Ko(t);
      for (; n && Ko(n); ) n = Ko(n);
      return n || null;
    }
  },
  _u = new I("", {
    providedIn: "root",
    factory: () => p(Ae).handleError.bind(void 0),
  }),
  Nu = (() => {
    let t = class t {};
    (t.__NG_ELEMENT_ID__ = Xh), (t.__NG_ENV_ID__ = (r) => r);
    let e = t;
    return e;
  })(),
  gi = class extends Nu {
    constructor(t) {
      super(), (this._lView = t);
    }
    onDestroy(t) {
      return tu(this._lView, t), () => Dh(this._lView, t);
    }
  };
function Xh() {
  return new gi(De());
}
function Jh() {
  return Zi(Fe(), De());
}
function Zi(e, t) {
  return new qr(ke(e, t));
}
var qr = (() => {
  let t = class t {
    constructor(r) {
      this.nativeElement = r;
    }
  };
  t.__NG_ELEMENT_ID__ = Jh;
  let e = t;
  return e;
})();
var Bt = (() => {
  let t = class t {
    constructor() {
      (this.taskId = 0),
        (this.pendingTasks = new Set()),
        (this.hasPendingTasks = new W(!1));
    }
    get _hasPendingTasks() {
      return this.hasPendingTasks.value;
    }
    add() {
      this._hasPendingTasks || this.hasPendingTasks.next(!0);
      let r = this.taskId++;
      return this.pendingTasks.add(r), r;
    }
    remove(r) {
      this.pendingTasks.delete(r),
        this.pendingTasks.size === 0 &&
          this._hasPendingTasks &&
          this.hasPendingTasks.next(!1);
    }
    ngOnDestroy() {
      this.pendingTasks.clear(),
        this._hasPendingTasks && this.hasPendingTasks.next(!1);
    }
  };
  t.ɵprov = D({ token: t, providedIn: "root", factory: () => new t() });
  let e = t;
  return e;
})();
var mi = class extends Q {
    constructor(t = !1) {
      super(),
        (this.destroyRef = void 0),
        (this.pendingTasks = void 0),
        (this.__isAsync = t),
        uh() &&
          ((this.destroyRef = p(Nu, { optional: !0 }) ?? void 0),
          (this.pendingTasks = p(Bt, { optional: !0 }) ?? void 0));
    }
    emit(t) {
      let n = P(null);
      try {
        super.next(t);
      } finally {
        P(n);
      }
    }
    subscribe(t, n, r) {
      let o = t,
        i = n || (() => null),
        s = r;
      if (t && typeof t == "object") {
        let c = t;
        (o = c.next?.bind(c)),
          (i = c.error?.bind(c)),
          (s = c.complete?.bind(c));
      }
      this.__isAsync &&
        ((i = this.wrapInTimeout(i)),
        o && (o = this.wrapInTimeout(o)),
        s && (s = this.wrapInTimeout(s)));
      let a = super.subscribe({ next: o, error: i, complete: s });
      return t instanceof V && t.add(a), a;
    }
    wrapInTimeout(t) {
      return (n) => {
        let r = this.pendingTasks?.add();
        setTimeout(() => {
          t(n), r !== void 0 && this.pendingTasks?.remove(r);
        });
      };
    }
  },
  K = mi;
function Au(e) {
  return (e.flags & 128) === 128;
}
var Ru = new Map(),
  ep = 0;
function tp() {
  return ep++;
}
function np(e) {
  Ru.set(e[Ur], e);
}
function rp(e) {
  Ru.delete(e[Ur]);
}
var uc = "__ngContext__";
function Lt(e, t) {
  nt(t) ? ((e[uc] = t[Ur]), np(t)) : (e[uc] = t);
}
function Ou(e) {
  return ku(e[ln]);
}
function Pu(e) {
  return ku(e[ye]);
}
function ku(e) {
  for (; e !== null && !Pe(e); ) e = e[ye];
  return e;
}
var vi;
function Fu(e) {
  vi = e;
}
function op() {
  if (vi !== void 0) return vi;
  if (typeof document < "u") return document;
  throw new v(210, !1);
}
var Yi = new I("", { providedIn: "root", factory: () => ip }),
  ip = "ng",
  Qi = new I(""),
  Ut = new I("", { providedIn: "platform", factory: () => "unknown" });
var Ki = new I("", {
  providedIn: "root",
  factory: () =>
    op().body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") ||
    null,
});
var sp = "h",
  ap = "b";
var cp = () => null;
function Xi(e, t, n = !1) {
  return cp(e, t, n);
}
var Lu = !1,
  up = new I("", { providedIn: "root", factory: () => Lu });
var pr;
function lp() {
  if (pr === void 0 && ((pr = null), sn.trustedTypes))
    try {
      pr = sn.trustedTypes.createPolicy("angular", {
        createHTML: (e) => e,
        createScript: (e) => e,
        createScriptURL: (e) => e,
      });
    } catch {}
  return pr;
}
function dp(e) {
  return lp()?.createScriptURL(e) || e;
}
function ju(e) {
  return dp(e[0]);
}
function Vu(e) {
  return e instanceof Function ? e() : e;
}
var lt = (function (e) {
    return (
      (e[(e.Important = 1)] = "Important"),
      (e[(e.DashCase = 2)] = "DashCase"),
      e
    );
  })(lt || {}),
  fp;
function Ji(e, t) {
  return fp(e, t);
}
function Nt(e, t, n, r, o) {
  if (r != null) {
    let i,
      s = !1;
    Pe(r) ? (i = r) : nt(r) && ((s = !0), (r = r[Oe]));
    let a = Ze(r);
    e === 0 && n !== null
      ? o == null
        ? zu(t, n, a)
        : Nr(t, n, a, o || null, !0)
      : e === 1 && n !== null
      ? Nr(t, n, a, o || null, !0)
      : e === 2
      ? xp(t, a, s)
      : e === 3 && t.destroyNode(a),
      i != null && _p(t, e, i, n, o);
  }
}
function hp(e, t) {
  return e.createText(t);
}
function $u(e, t, n) {
  return e.createElement(t, n);
}
function pp(e, t) {
  Bu(e, t), (t[Oe] = null), (t[we] = null);
}
function gp(e, t, n, r, o, i) {
  (r[Oe] = o), (r[we] = t), Wr(e, r, n, 1, o, i);
}
function Bu(e, t) {
  t[Ne].changeDetectionScheduler?.notify(8), Wr(e, t, t[Me], 2, null, null);
}
function mp(e) {
  let t = e[ln];
  if (!t) return Xo(e[T], e);
  for (; t; ) {
    let n = null;
    if (nt(t)) n = t[ln];
    else {
      let r = t[de];
      r && (n = r);
    }
    if (!n) {
      for (; t && !t[ye] && t !== e; ) nt(t) && Xo(t[T], t), (t = t[X]);
      t === null && (t = e), nt(t) && Xo(t[T], t), (n = t && t[ye]);
    }
    t = n;
  }
}
function vp(e, t, n, r) {
  let o = de + r,
    i = n.length;
  r > 0 && (n[o - 1][ye] = t),
    r < i - de
      ? ((t[ye] = n[o]), Rc(n, de + r, t))
      : (n.push(t), (t[ye] = null)),
    (t[X] = n);
  let s = t[dn];
  s !== null && n !== s && Uu(s, t);
  let a = t[Br];
  a !== null && a.insertView(e), li(t), (t[C] |= 128);
}
function Uu(e, t) {
  let n = e[Sr],
    r = t[X];
  if (nt(r)) e[C] |= xr.HasTransplantedViews;
  else {
    let o = r[X][Se];
    t[Se] !== o && (e[C] |= xr.HasTransplantedViews);
  }
  n === null ? (e[Sr] = [t]) : n.push(t);
}
function es(e, t) {
  let n = e[Sr],
    r = n.indexOf(t);
  n.splice(r, 1);
}
function yi(e, t) {
  if (e.length <= de) return;
  let n = de + t,
    r = e[n];
  if (r) {
    let o = r[dn];
    o !== null && o !== e && es(o, r), t > 0 && (e[n - 1][ye] = r[ye]);
    let i = Er(e, de + t);
    pp(r[T], r);
    let s = i[Br];
    s !== null && s.detachView(i[T]),
      (r[X] = null),
      (r[ye] = null),
      (r[C] &= -129);
  }
  return r;
}
function Hu(e, t) {
  if (!(t[C] & 256)) {
    let n = t[Me];
    n.destroyNode && Wr(e, t, n, 3, null, null), mp(t);
  }
}
function Xo(e, t) {
  if (t[C] & 256) return;
  let n = P(null);
  try {
    (t[C] &= -129),
      (t[C] |= 256),
      t[le] && So(t[le]),
      Dp(e, t),
      yp(e, t),
      t[T].type === 1 && t[Me].destroy();
    let r = t[dn];
    if (r !== null && Pe(t[X])) {
      r !== t[X] && es(r, t);
      let o = t[Br];
      o !== null && o.detachView(e);
    }
    rp(t);
  } finally {
    P(n);
  }
}
function yp(e, t) {
  let n = e.cleanup,
    r = t[Ja];
  if (n !== null)
    for (let i = 0; i < n.length - 1; i += 2)
      if (typeof n[i] == "string") {
        let s = n[i + 3];
        s >= 0 ? r[s]() : r[-s].unsubscribe(), (i += 2);
      } else {
        let s = r[n[i + 1]];
        n[i].call(s);
      }
  r !== null && (t[Ja] = null);
  let o = t[Ge];
  if (o !== null) {
    t[Ge] = null;
    for (let i = 0; i < o.length; i++) {
      let s = o[i];
      s();
    }
  }
}
function Dp(e, t) {
  let n;
  if (e != null && (n = e.destroyHooks) != null)
    for (let r = 0; r < n.length; r += 2) {
      let o = t[n[r]];
      if (!(o instanceof hn)) {
        let i = n[r + 1];
        if (Array.isArray(i))
          for (let s = 0; s < i.length; s += 2) {
            let a = o[i[s]],
              c = i[s + 1];
            ze(4, a, c);
            try {
              c.call(a);
            } finally {
              ze(5, a, c);
            }
          }
        else {
          ze(4, o, i);
          try {
            i.call(o);
          } finally {
            ze(5, o, i);
          }
        }
      }
    }
}
function wp(e, t, n) {
  return Cp(e, t.parent, n);
}
function Cp(e, t, n) {
  let r = t;
  for (; r !== null && r.type & 168; ) (t = r), (r = t.parent);
  if (r === null) return n[Oe];
  {
    let { componentOffset: o } = r;
    if (o > -1) {
      let { encapsulation: i } = e.data[r.directiveStart + o];
      if (i === be.None || i === be.Emulated) return null;
    }
    return ke(r, n);
  }
}
function Nr(e, t, n, r, o) {
  e.insertBefore(t, n, r, o);
}
function zu(e, t, n) {
  e.appendChild(t, n);
}
function lc(e, t, n, r, o) {
  r !== null ? Nr(e, t, n, r, o) : zu(e, t, n);
}
function Ep(e, t, n, r) {
  e.removeChild(t, n, r);
}
function ts(e, t) {
  return e.parentNode(t);
}
function Ip(e, t) {
  return e.nextSibling(t);
}
function bp(e, t, n) {
  return Sp(e, t, n);
}
function Mp(e, t, n) {
  return e.type & 40 ? ke(e, n) : null;
}
var Sp = Mp,
  dc;
function Gu(e, t, n, r) {
  let o = wp(e, r, t),
    i = t[Me],
    s = r.parent || t[we],
    a = bp(s, r, t);
  if (o != null)
    if (Array.isArray(n))
      for (let c = 0; c < n.length; c++) lc(i, o, n[c], a, !1);
    else lc(i, o, n, a, !1);
  dc !== void 0 && dc(i, r, t, n, o);
}
function yr(e, t) {
  if (t !== null) {
    let n = t.type;
    if (n & 3) return ke(t, e);
    if (n & 4) return Di(-1, e[t.index]);
    if (n & 8) {
      let r = t.child;
      if (r !== null) return yr(e, r);
      {
        let o = e[t.index];
        return Pe(o) ? Di(-1, o) : Ze(o);
      }
    } else {
      if (n & 32) return Ji(t, e)() || Ze(e[t.index]);
      {
        let r = qu(e, t);
        if (r !== null) {
          if (Array.isArray(r)) return r[0];
          let o = at(e[Se]);
          return yr(o, r);
        } else return yr(e, t.next);
      }
    }
  }
  return null;
}
function qu(e, t) {
  if (t !== null) {
    let r = e[Se][we],
      o = t.projection;
    return r.projection[o];
  }
  return null;
}
function Di(e, t) {
  let n = de + e + 1;
  if (n < t.length) {
    let r = t[n],
      o = r[T].firstChild;
    if (o !== null) return yr(r, o);
  }
  return t[st];
}
function xp(e, t, n) {
  let r = ts(e, t);
  r && Ep(e, r, t, n);
}
function ns(e, t, n, r, o, i, s) {
  for (; n != null; ) {
    if (n.type === 128) {
      n = n.next;
      continue;
    }
    let a = r[n.index],
      c = n.type;
    if (
      (s && t === 0 && (a && Lt(Ze(a), r), (n.flags |= 2)),
      (n.flags & 32) !== 32)
    )
      if (c & 8) ns(e, t, n.child, r, o, i, !1), Nt(t, e, o, a, i);
      else if (c & 32) {
        let u = Ji(n, r),
          l;
        for (; (l = u()); ) Nt(t, e, o, l, i);
        Nt(t, e, o, a, i);
      } else c & 16 ? Tp(e, t, r, n, o, i) : Nt(t, e, o, a, i);
    n = s ? n.projectionNext : n.next;
  }
}
function Wr(e, t, n, r, o, i) {
  ns(n, r, e.firstChild, t, o, i, !1);
}
function Tp(e, t, n, r, o, i) {
  let s = n[Se],
    c = s[we].projection[r.projection];
  if (Array.isArray(c))
    for (let u = 0; u < c.length; u++) {
      let l = c[u];
      Nt(t, e, o, l, i);
    }
  else {
    let u = c,
      l = s[X];
    Au(r) && (u.flags |= 128), ns(e, t, u, l, o, i, !0);
  }
}
function _p(e, t, n, r, o) {
  let i = n[st],
    s = Ze(n);
  i !== s && Nt(t, e, r, i, o);
  for (let a = de; a < n.length; a++) {
    let c = n[a];
    Wr(c[T], c, e, t, r, i);
  }
}
function Np(e, t, n) {
  e.setAttribute(t, "style", n);
}
function Wu(e, t, n) {
  n === "" ? e.removeAttribute(t, "class") : e.setAttribute(t, "class", n);
}
function Zu(e, t, n) {
  let { mergedAttrs: r, classes: o, styles: i } = n;
  r !== null && ri(e, t, r),
    o !== null && Wu(e, t, o),
    i !== null && Np(e, t, i);
}
var Yu = {};
function Ap(e, t, n, r) {
  if (!r)
    if ((t[C] & 3) === 3) {
      let i = e.preOrderCheckHooks;
      i !== null && mr(t, i, n);
    } else {
      let i = e.preOrderHooks;
      i !== null && vr(t, i, 0, n);
    }
  ct(n);
}
function rs(e, t = b.Default) {
  let n = De();
  if (n === null) return M(e, t);
  let r = Fe();
  return Mu(r, n, ue(e), t);
}
function Qu(e, t, n, r, o, i) {
  let s = P(null);
  try {
    let a = null;
    o & qe.SignalBased && (a = t[r][da]),
      a !== null && a.transformFn !== void 0 && (i = a.transformFn(i)),
      o & qe.HasDecoratorInputTransform &&
        (i = e.inputTransforms[r].call(t, i)),
      e.setInput !== null ? e.setInput(t, a, i, n, r) : Yc(t, a, r, i);
  } finally {
    P(s);
  }
}
function Rp(e, t) {
  let n = e.hostBindingOpCodes;
  if (n !== null)
    try {
      for (let r = 0; r < n.length; r++) {
        let o = n[r];
        if (o < 0) ct(~o);
        else {
          let i = o,
            s = n[++r],
            a = n[++r];
          Nh(s, i);
          let c = t[i];
          a(2, c);
        }
      }
    } finally {
      ct(-1);
    }
}
function os(e, t, n, r, o, i, s, a, c, u, l) {
  let d = t.blueprint.slice();
  return (
    (d[Oe] = o),
    (d[C] = r | 4 | 128 | 8 | 64),
    (u !== null || (e && e[C] & 2048)) && (d[C] |= 2048),
    Jc(d),
    (d[X] = d[yn] = e),
    (d[We] = n),
    (d[Ne] = s || (e && e[Ne])),
    (d[Me] = a || (e && e[Me])),
    (d[Ft] = c || (e && e[Ft]) || null),
    (d[we] = i),
    (d[Ur] = tp()),
    (d[br] = l),
    (d[qc] = u),
    (d[Se] = t.type == 2 ? e[Se] : d),
    d
  );
}
function is(e, t, n, r, o) {
  let i = e.data[t];
  if (i === null) (i = Op(e, t, n, r, o)), _h() && (i.flags |= 32);
  else if (i.type & 64) {
    (i.type = n), (i.value = r), (i.attrs = o);
    let s = Sh();
    i.injectorIndex = s === null ? -1 : s.injectorIndex;
  }
  return Gr(i, !0), i;
}
function Op(e, t, n, r, o) {
  let i = ou(),
    s = iu(),
    a = s ? i : i && i.parent,
    c = (e.data[t] = $p(e, a, n, t, r, o));
  return (
    e.firstChild === null && (e.firstChild = c),
    i !== null &&
      (s
        ? i.child == null && c.parent !== null && (i.child = c)
        : i.next === null && ((i.next = c), (c.prev = i))),
    c
  );
}
function Ku(e, t, n, r) {
  if (n === 0) return -1;
  let o = t.length;
  for (let i = 0; i < n; i++) t.push(r), e.blueprint.push(r), e.data.push(null);
  return o;
}
function Xu(e, t, n, r, o) {
  let i = Oh(),
    s = r & 2;
  try {
    ct(-1), s && t.length > it && Ap(e, t, it, !1), ze(s ? 2 : 0, o), n(r, o);
  } finally {
    ct(i), ze(s ? 3 : 1, o);
  }
}
function Ju(e, t, n) {
  if (Zc(t)) {
    let r = P(null);
    try {
      let o = t.directiveStart,
        i = t.directiveEnd;
      for (let s = o; s < i; s++) {
        let a = e.data[s];
        if (a.contentQueries) {
          let c = n[s];
          a.contentQueries(1, c, s);
        }
      }
    } finally {
      P(r);
    }
  }
}
function Pp(e, t, n) {
  ru() && (Gp(e, t, n, ke(n, t)), (n.flags & 64) === 64 && rl(e, t, n));
}
function kp(e, t, n = ke) {
  let r = t.localNames;
  if (r !== null) {
    let o = t.index + 1;
    for (let i = 0; i < r.length; i += 2) {
      let s = r[i + 1],
        a = s === -1 ? n(t, e) : e[s];
      e[o++] = a;
    }
  }
}
function el(e) {
  let t = e.tView;
  return t === null || t.incompleteFirstPass
    ? (e.tView = tl(
        1,
        null,
        e.template,
        e.decls,
        e.vars,
        e.directiveDefs,
        e.pipeDefs,
        e.viewQuery,
        e.schemas,
        e.consts,
        e.id
      ))
    : t;
}
function tl(e, t, n, r, o, i, s, a, c, u, l) {
  let d = it + r,
    h = d + o,
    f = Fp(d, h),
    m = typeof u == "function" ? u() : u;
  return (f[T] = {
    type: e,
    blueprint: f,
    template: n,
    queries: null,
    viewQuery: a,
    declTNode: t,
    data: f.slice().fill(null, d),
    bindingStartIndex: d,
    expandoStartIndex: h,
    hostBindingOpCodes: null,
    firstCreatePass: !0,
    firstUpdatePass: !0,
    staticViewQueries: !1,
    staticContentQueries: !1,
    preOrderHooks: null,
    preOrderCheckHooks: null,
    contentHooks: null,
    contentCheckHooks: null,
    viewHooks: null,
    viewCheckHooks: null,
    destroyHooks: null,
    cleanup: null,
    contentQueries: null,
    components: null,
    directiveRegistry: typeof i == "function" ? i() : i,
    pipeRegistry: typeof s == "function" ? s() : s,
    firstChild: null,
    schemas: c,
    consts: m,
    incompleteFirstPass: !1,
    ssrId: l,
  });
}
function Fp(e, t) {
  let n = [];
  for (let r = 0; r < t; r++) n.push(r < e ? null : Yu);
  return n;
}
function Lp(e, t, n, r) {
  let i = r.get(up, Lu) || n === be.ShadowDom,
    s = e.selectRootElement(t, i);
  return jp(s), s;
}
function jp(e) {
  Vp(e);
}
var Vp = () => null;
function $p(e, t, n, r, o, i) {
  let s = t ? t.injectorIndex : -1,
    a = 0;
  return (
    Ih() && (a |= 128),
    {
      type: n,
      index: r,
      insertBeforeIndex: null,
      injectorIndex: s,
      directiveStart: -1,
      directiveEnd: -1,
      directiveStylingLast: -1,
      componentOffset: -1,
      propertyBindings: null,
      flags: a,
      providerIndexes: 0,
      value: o,
      attrs: i,
      mergedAttrs: null,
      localNames: null,
      initialInputs: void 0,
      inputs: null,
      outputs: null,
      tView: null,
      next: null,
      prev: null,
      projectionNext: null,
      child: null,
      parent: t,
      projection: null,
      styles: null,
      stylesWithoutHost: null,
      residualStyles: void 0,
      classes: null,
      classesWithoutHost: null,
      residualClasses: void 0,
      classBindings: 0,
      styleBindings: 0,
    }
  );
}
function fc(e, t, n, r, o) {
  for (let i in t) {
    if (!t.hasOwnProperty(i)) continue;
    let s = t[i];
    if (s === void 0) continue;
    r ??= {};
    let a,
      c = qe.None;
    Array.isArray(s) ? ((a = s[0]), (c = s[1])) : (a = s);
    let u = i;
    if (o !== null) {
      if (!o.hasOwnProperty(i)) continue;
      u = o[i];
    }
    e === 0 ? hc(r, n, u, a, c) : hc(r, n, u, a);
  }
  return r;
}
function hc(e, t, n, r, o) {
  let i;
  e.hasOwnProperty(n) ? (i = e[n]).push(t, r) : (i = e[n] = [t, r]),
    o !== void 0 && i.push(o);
}
function Bp(e, t, n) {
  let r = t.directiveStart,
    o = t.directiveEnd,
    i = e.data,
    s = t.attrs,
    a = [],
    c = null,
    u = null;
  for (let l = r; l < o; l++) {
    let d = i[l],
      h = n ? n.get(d) : null,
      f = h ? h.inputs : null,
      m = h ? h.outputs : null;
    (c = fc(0, d.inputs, l, c, f)), (u = fc(1, d.outputs, l, u, m));
    let S = c !== null && s !== null && !Li(t) ? eg(c, l, s) : null;
    a.push(S);
  }
  c !== null &&
    (c.hasOwnProperty("class") && (t.flags |= 8),
    c.hasOwnProperty("style") && (t.flags |= 16)),
    (t.initialInputs = a),
    (t.inputs = c),
    (t.outputs = u);
}
function Up(e, t, n, r) {
  if (ru()) {
    let o = r === null ? null : { "": -1 },
      i = Wp(e, n),
      s,
      a;
    i === null ? (s = a = null) : ([s, a] = i),
      s !== null && nl(e, t, n, s, o, a),
      o && Zp(n, r, o);
  }
  n.mergedAttrs = Fi(n.mergedAttrs, n.attrs);
}
function nl(e, t, n, r, o, i) {
  for (let u = 0; u < r.length; u++) zh(Cu(n, t), e, r[u].type);
  Qp(n, e.data.length, r.length);
  for (let u = 0; u < r.length; u++) {
    let l = r[u];
    l.providersResolver && l.providersResolver(l);
  }
  let s = !1,
    a = !1,
    c = Ku(e, t, r.length, null);
  for (let u = 0; u < r.length; u++) {
    let l = r[u];
    (n.mergedAttrs = Fi(n.mergedAttrs, l.hostAttrs)),
      Kp(e, n, t, c, l),
      Yp(c, l, o),
      l.contentQueries !== null && (n.flags |= 4),
      (l.hostBindings !== null || l.hostAttrs !== null || l.hostVars !== 0) &&
        (n.flags |= 64);
    let d = l.type.prototype;
    !s &&
      (d.ngOnChanges || d.ngOnInit || d.ngDoCheck) &&
      ((e.preOrderHooks ??= []).push(n.index), (s = !0)),
      !a &&
        (d.ngOnChanges || d.ngDoCheck) &&
        ((e.preOrderCheckHooks ??= []).push(n.index), (a = !0)),
      c++;
  }
  Bp(e, n, i);
}
function Hp(e, t, n, r, o) {
  let i = o.hostBindings;
  if (i) {
    let s = e.hostBindingOpCodes;
    s === null && (s = e.hostBindingOpCodes = []);
    let a = ~t.index;
    zp(s) != a && s.push(a), s.push(n, r, i);
  }
}
function zp(e) {
  let t = e.length;
  for (; t > 0; ) {
    let n = e[--t];
    if (typeof n == "number" && n < 0) return n;
  }
  return 0;
}
function Gp(e, t, n, r) {
  let o = n.directiveStart,
    i = n.directiveEnd;
  Bi(n) && Xp(t, n, e.data[o + n.componentOffset]),
    e.firstCreatePass || Cu(n, t),
    Lt(r, t);
  let s = n.initialInputs;
  for (let a = o; a < i; a++) {
    let c = e.data[a],
      u = pn(t, e, a, n);
    if ((Lt(u, t), s !== null && Jp(t, a - o, u, c, n, s), Dn(c))) {
      let l = wn(n.index, t);
      l[We] = pn(t, e, a, n);
    }
  }
}
function rl(e, t, n) {
  let r = n.directiveStart,
    o = n.directiveEnd,
    i = n.index,
    s = Ah();
  try {
    ct(i);
    for (let a = r; a < o; a++) {
      let c = e.data[a],
        u = t[a];
      di(a),
        (c.hostBindings !== null || c.hostVars !== 0 || c.hostAttrs !== null) &&
          qp(c, u);
    }
  } finally {
    ct(-1), di(s);
  }
}
function qp(e, t) {
  e.hostBindings !== null && e.hostBindings(1, t);
}
function Wp(e, t) {
  let n = e.directiveRegistry,
    r = null,
    o = null;
  if (n)
    for (let i = 0; i < n.length; i++) {
      let s = n[i];
      if (Hf(t, s.selectors, !1))
        if ((r || (r = []), Dn(s)))
          if (s.findHostDirectiveDefs !== null) {
            let a = [];
            (o = o || new Map()),
              s.findHostDirectiveDefs(s, a, o),
              r.unshift(...a, s);
            let c = a.length;
            wi(e, t, c);
          } else r.unshift(s), wi(e, t, 0);
        else
          (o = o || new Map()), s.findHostDirectiveDefs?.(s, r, o), r.push(s);
    }
  return r === null ? null : [r, o];
}
function wi(e, t, n) {
  (t.componentOffset = n), (e.components ??= []).push(t.index);
}
function Zp(e, t, n) {
  if (t) {
    let r = (e.localNames = []);
    for (let o = 0; o < t.length; o += 2) {
      let i = n[t[o + 1]];
      if (i == null) throw new v(-301, !1);
      r.push(t[o], i);
    }
  }
}
function Yp(e, t, n) {
  if (n) {
    if (t.exportAs)
      for (let r = 0; r < t.exportAs.length; r++) n[t.exportAs[r]] = e;
    Dn(t) && (n[""] = e);
  }
}
function Qp(e, t, n) {
  (e.flags |= 1),
    (e.directiveStart = t),
    (e.directiveEnd = t + n),
    (e.providerIndexes = t);
}
function Kp(e, t, n, r, o) {
  e.data[r] = o;
  let i = o.factory || (o.factory = Ot(o.type, !0)),
    s = new hn(i, Dn(o), rs);
  (e.blueprint[r] = s), (n[r] = s), Hp(e, t, r, Ku(e, n, o.hostVars, Yu), o);
}
function Xp(e, t, n) {
  let r = ke(t, e),
    o = el(n),
    i = e[Ne].rendererFactory,
    s = 16;
  n.signals ? (s = 4096) : n.onPush && (s = 64);
  let a = ss(
    e,
    os(e, o, null, s, r, t, null, i.createRenderer(r, n), null, null, null)
  );
  e[t.index] = a;
}
function Jp(e, t, n, r, o, i) {
  let s = i[t];
  if (s !== null)
    for (let a = 0; a < s.length; ) {
      let c = s[a++],
        u = s[a++],
        l = s[a++],
        d = s[a++];
      Qu(r, n, c, u, l, d);
    }
}
function eg(e, t, n) {
  let r = null,
    o = 0;
  for (; o < n.length; ) {
    let i = n[o];
    if (i === 0) {
      o += 4;
      continue;
    } else if (i === 5) {
      o += 2;
      continue;
    }
    if (typeof i == "number") break;
    if (e.hasOwnProperty(i)) {
      r === null && (r = []);
      let s = e[i];
      for (let a = 0; a < s.length; a += 3)
        if (s[a] === t) {
          r.push(i, s[a + 1], s[a + 2], n[o + 1]);
          break;
        }
    }
    o += 2;
  }
  return r;
}
function tg(e, t, n, r) {
  return [e, !0, 0, t, null, r, null, n, null, null];
}
function ol(e, t) {
  let n = e.contentQueries;
  if (n !== null) {
    let r = P(null);
    try {
      for (let o = 0; o < n.length; o += 2) {
        let i = n[o],
          s = n[o + 1];
        if (s !== -1) {
          let a = e.data[s];
          au(i), a.contentQueries(2, t[s], s);
        }
      }
    } finally {
      P(r);
    }
  }
}
function ss(e, t) {
  return e[ln] ? (e[ec][ye] = t) : (e[ln] = t), (e[ec] = t), t;
}
function Ci(e, t, n) {
  au(0);
  let r = P(null);
  try {
    t(e, n);
  } finally {
    P(r);
  }
}
function ng(e, t) {
  let n = e[Ft],
    r = n ? n.get(Ae, null) : null;
  r && r.handleError(t);
}
function il(e, t, n, r, o) {
  for (let i = 0; i < n.length; ) {
    let s = n[i++],
      a = n[i++],
      c = n[i++],
      u = t[s],
      l = e.data[s];
    Qu(l, u, r, a, c, o);
  }
}
function rg(e, t) {
  let n = wn(t, e),
    r = n[T];
  og(r, n);
  let o = n[Oe];
  o !== null && n[br] === null && (n[br] = Xi(o, n[Ft])), sl(r, n, n[We]);
}
function og(e, t) {
  for (let n = t.length; n < e.blueprint.length; n++) t.push(e.blueprint[n]);
}
function sl(e, t, n) {
  zi(t);
  try {
    let r = e.viewQuery;
    r !== null && Ci(1, r, n);
    let o = e.template;
    o !== null && Xu(e, t, o, 1, n),
      e.firstCreatePass && (e.firstCreatePass = !1),
      t[Br]?.finishViewCreation(e),
      e.staticContentQueries && ol(e, t),
      e.staticViewQueries && Ci(2, e.viewQuery, n);
    let i = e.components;
    i !== null && ig(t, i);
  } catch (r) {
    throw (
      (e.firstCreatePass &&
        ((e.incompleteFirstPass = !0), (e.firstCreatePass = !1)),
      r)
    );
  } finally {
    (t[C] &= -5), Gi();
  }
}
function ig(e, t) {
  for (let n = 0; n < t.length; n++) rg(e, t[n]);
}
function pc(e, t) {
  return !t || t.firstChild === null || Au(e);
}
function sg(e, t, n, r = !0) {
  let o = t[T];
  if ((vp(o, t, e, n), r)) {
    let s = Di(n, e),
      a = t[Me],
      c = ts(a, e[st]);
    c !== null && gp(o, e[we], a, t, c, s);
  }
  let i = t[br];
  i !== null && i.firstChild !== null && (i.firstChild = null);
}
function Ar(e, t, n, r, o = !1) {
  for (; n !== null; ) {
    if (n.type === 128) {
      n = o ? n.projectionNext : n.next;
      continue;
    }
    let i = t[n.index];
    i !== null && r.push(Ze(i)), Pe(i) && ag(i, r);
    let s = n.type;
    if (s & 8) Ar(e, t, n.child, r);
    else if (s & 32) {
      let a = Ji(n, t),
        c;
      for (; (c = a()); ) r.push(c);
    } else if (s & 16) {
      let a = qu(t, n);
      if (Array.isArray(a)) r.push(...a);
      else {
        let c = at(t[Se]);
        Ar(c[T], c, a, r, !0);
      }
    }
    n = o ? n.projectionNext : n.next;
  }
  return r;
}
function ag(e, t) {
  for (let n = de; n < e.length; n++) {
    let r = e[n],
      o = r[T].firstChild;
    o !== null && Ar(r[T], r, o, t);
  }
  e[st] !== e[Oe] && t.push(e[st]);
}
var al = [];
function cg(e) {
  return e[le] ?? ug(e);
}
function ug(e) {
  let t = al.pop() ?? Object.create(dg);
  return (t.lView = e), t;
}
function lg(e) {
  e.lView[le] !== e && ((e.lView = null), al.push(e));
}
var dg = j(g({}, Io), {
  consumerIsAlwaysLive: !0,
  consumerMarkedDirty: (e) => {
    zr(e.lView);
  },
  consumerOnSignalRead() {
    this.lView[le] = this;
  },
});
function fg(e) {
  let t = e[le] ?? Object.create(hg);
  return (t.lView = e), t;
}
var hg = j(g({}, Io), {
  consumerIsAlwaysLive: !0,
  consumerMarkedDirty: (e) => {
    let t = at(e.lView);
    for (; t && !cl(t[T]); ) t = at(t);
    t && eu(t);
  },
  consumerOnSignalRead() {
    this.lView[le] = this;
  },
});
function cl(e) {
  return e.type !== 2;
}
var pg = 100;
function ul(e, t = !0, n = 0) {
  let r = e[Ne],
    o = r.rendererFactory,
    i = !1;
  i || o.begin?.();
  try {
    gg(e, n);
  } catch (s) {
    throw (t && ng(e, s), s);
  } finally {
    i || (o.end?.(), r.inlineEffectRunner?.flush());
  }
}
function gg(e, t) {
  let n = su();
  try {
    rc(!0), Ei(e, t);
    let r = 0;
    for (; fn(e); ) {
      if (r === pg) throw new v(103, !1);
      r++, Ei(e, 1);
    }
  } finally {
    rc(n);
  }
}
function mg(e, t, n, r) {
  let o = t[C];
  if ((o & 256) === 256) return;
  let i = !1,
    s = !1;
  !i && t[Ne].inlineEffectRunner?.flush(), zi(t);
  let a = !0,
    c = null,
    u = null;
  i ||
    (cl(e)
      ? ((u = cg(t)), (c = bo(u)))
      : fa() === null
      ? ((a = !1), (u = fg(t)), (c = bo(u)))
      : t[le] && (So(t[le]), (t[le] = null)));
  try {
    Jc(t), Th(e.bindingStartIndex), n !== null && Xu(e, t, n, 2, r);
    let l = (o & 3) === 3;
    if (!i)
      if (l) {
        let f = e.preOrderCheckHooks;
        f !== null && mr(t, f, null);
      } else {
        let f = e.preOrderHooks;
        f !== null && vr(t, f, 0, null), Zo(t, 0);
      }
    if ((s || vg(t), ll(t, 0), e.contentQueries !== null && ol(e, t), !i))
      if (l) {
        let f = e.contentCheckHooks;
        f !== null && mr(t, f);
      } else {
        let f = e.contentHooks;
        f !== null && vr(t, f, 1), Zo(t, 1);
      }
    Rp(e, t);
    let d = e.components;
    d !== null && fl(t, d, 0);
    let h = e.viewQuery;
    if ((h !== null && Ci(2, h, r), !i))
      if (l) {
        let f = e.viewCheckHooks;
        f !== null && mr(t, f);
      } else {
        let f = e.viewHooks;
        f !== null && vr(t, f, 2), Zo(t, 2);
      }
    if ((e.firstUpdatePass === !0 && (e.firstUpdatePass = !1), t[Wo])) {
      for (let f of t[Wo]) f();
      t[Wo] = null;
    }
    i || (t[C] &= -73);
  } catch (l) {
    throw (i || zr(t), l);
  } finally {
    u !== null && (ha(u, c), a && lg(u)), Gi();
  }
}
function ll(e, t) {
  for (let n = Ou(e); n !== null; n = Pu(n))
    for (let r = de; r < n.length; r++) {
      let o = n[r];
      dl(o, t);
    }
}
function vg(e) {
  for (let t = Ou(e); t !== null; t = Pu(t)) {
    if (!(t[C] & xr.HasTransplantedViews)) continue;
    let n = t[Sr];
    for (let r = 0; r < n.length; r++) {
      let o = n[r];
      eu(o);
    }
  }
}
function yg(e, t, n) {
  let r = wn(t, e);
  dl(r, n);
}
function dl(e, t) {
  Ui(e) && Ei(e, t);
}
function Ei(e, t) {
  let r = e[T],
    o = e[C],
    i = e[le],
    s = !!(t === 0 && o & 16);
  if (
    ((s ||= !!(o & 64 && t === 0)),
    (s ||= !!(o & 1024)),
    (s ||= !!(i?.dirty && Mo(i))),
    (s ||= !1),
    i && (i.dirty = !1),
    (e[C] &= -9217),
    s)
  )
    mg(r, e, r.template, e[We]);
  else if (o & 8192) {
    ll(e, 1);
    let a = r.components;
    a !== null && fl(e, a, 1);
  }
}
function fl(e, t, n) {
  for (let r = 0; r < t.length; r++) yg(e, t[r], n);
}
function hl(e, t) {
  let n = su() ? 64 : 1088;
  for (e[Ne].changeDetectionScheduler?.notify(t); e; ) {
    e[C] |= n;
    let r = at(e);
    if (ci(e) && !r) return e;
    e = r;
  }
  return null;
}
var jt = class {
  get rootNodes() {
    let t = this._lView,
      n = t[T];
    return Ar(n, t, n.firstChild, []);
  }
  constructor(t, n, r = !0) {
    (this._lView = t),
      (this._cdRefInjectingView = n),
      (this.notifyErrorHandler = r),
      (this._appRef = null),
      (this._attachedToViewContainer = !1);
  }
  get context() {
    return this._lView[We];
  }
  set context(t) {
    this._lView[We] = t;
  }
  get destroyed() {
    return (this._lView[C] & 256) === 256;
  }
  destroy() {
    if (this._appRef) this._appRef.detachView(this);
    else if (this._attachedToViewContainer) {
      let t = this._lView[X];
      if (Pe(t)) {
        let n = t[Mr],
          r = n ? n.indexOf(this) : -1;
        r > -1 && (yi(t, r), Er(n, r));
      }
      this._attachedToViewContainer = !1;
    }
    Hu(this._lView[T], this._lView);
  }
  onDestroy(t) {
    tu(this._lView, t);
  }
  markForCheck() {
    hl(this._cdRefInjectingView || this._lView, 4);
  }
  detach() {
    this._lView[C] &= -129;
  }
  reattach() {
    li(this._lView), (this._lView[C] |= 128);
  }
  detectChanges() {
    (this._lView[C] |= 1024), ul(this._lView, this.notifyErrorHandler);
  }
  checkNoChanges() {}
  attachToViewContainerRef() {
    if (this._appRef) throw new v(902, !1);
    this._attachedToViewContainer = !0;
  }
  detachFromAppRef() {
    this._appRef = null;
    let t = ci(this._lView),
      n = this._lView[dn];
    n !== null && !t && es(n, this._lView), Bu(this._lView[T], this._lView);
  }
  attachToAppRef(t) {
    if (this._attachedToViewContainer) throw new v(902, !1);
    this._appRef = t;
    let n = ci(this._lView),
      r = this._lView[dn];
    r !== null && !n && Uu(r, this._lView), li(this._lView);
  }
};
var Db = new RegExp(`^(\\d+)*(${ap}|${sp})*(.*)`);
var Dg = () => null;
function gc(e, t) {
  return Dg(e, t);
}
var gn = class {},
  as = new I("", { providedIn: "root", factory: () => !1 });
var pl = new I(""),
  Ii = class {},
  Rr = class {};
function wg(e) {
  let t = Error(`No component factory found for ${re(e)}.`);
  return (t[Cg] = e), t;
}
var Cg = "ngComponent";
var bi = class {
    resolveComponentFactory(t) {
      throw wg(t);
    }
  },
  ps = class ps {};
ps.NULL = new bi();
var Vt = ps,
  $t = class {};
var Eg = (() => {
  let t = class t {};
  t.ɵprov = D({ token: t, providedIn: "root", factory: () => null });
  let e = t;
  return e;
})();
var mc = new Set();
function cs(e) {
  mc.has(e) ||
    (mc.add(e),
    performance?.mark?.("mark_feature_usage", { detail: { feature: e } }));
}
function gl(e) {
  let t = !0;
  return (
    setTimeout(() => {
      t && ((t = !1), e());
    }),
    typeof sn.requestAnimationFrame == "function" &&
      sn.requestAnimationFrame(() => {
        t && ((t = !1), e());
      }),
    () => {
      t = !1;
    }
  );
}
function vc(e) {
  let t = !0;
  return (
    queueMicrotask(() => {
      t && e();
    }),
    () => {
      t = !1;
    }
  );
}
function yc(...e) {}
var $ = class e {
    constructor({
      enableLongStackTrace: t = !1,
      shouldCoalesceEventChangeDetection: n = !1,
      shouldCoalesceRunChangeDetection: r = !1,
    }) {
      if (
        ((this.hasPendingMacrotasks = !1),
        (this.hasPendingMicrotasks = !1),
        (this.isStable = !0),
        (this.onUnstable = new K(!1)),
        (this.onMicrotaskEmpty = new K(!1)),
        (this.onStable = new K(!1)),
        (this.onError = new K(!1)),
        typeof Zone > "u")
      )
        throw new v(908, !1);
      Zone.assertZonePatched();
      let o = this;
      (o._nesting = 0),
        (o._outer = o._inner = Zone.current),
        Zone.TaskTrackingZoneSpec &&
          (o._inner = o._inner.fork(new Zone.TaskTrackingZoneSpec())),
        t &&
          Zone.longStackTraceZoneSpec &&
          (o._inner = o._inner.fork(Zone.longStackTraceZoneSpec)),
        (o.shouldCoalesceEventChangeDetection = !r && n),
        (o.shouldCoalesceRunChangeDetection = r),
        (o.callbackScheduled = !1),
        Mg(o);
    }
    static isInAngularZone() {
      return typeof Zone < "u" && Zone.current.get("isAngularZone") === !0;
    }
    static assertInAngularZone() {
      if (!e.isInAngularZone()) throw new v(909, !1);
    }
    static assertNotInAngularZone() {
      if (e.isInAngularZone()) throw new v(909, !1);
    }
    run(t, n, r) {
      return this._inner.run(t, n, r);
    }
    runTask(t, n, r, o) {
      let i = this._inner,
        s = i.scheduleEventTask("NgZoneEvent: " + o, t, Ig, yc, yc);
      try {
        return i.runTask(s, n, r);
      } finally {
        i.cancelTask(s);
      }
    }
    runGuarded(t, n, r) {
      return this._inner.runGuarded(t, n, r);
    }
    runOutsideAngular(t) {
      return this._outer.run(t);
    }
  },
  Ig = {};
function us(e) {
  if (e._nesting == 0 && !e.hasPendingMicrotasks && !e.isStable)
    try {
      e._nesting++, e.onMicrotaskEmpty.emit(null);
    } finally {
      if ((e._nesting--, !e.hasPendingMicrotasks))
        try {
          e.runOutsideAngular(() => e.onStable.emit(null));
        } finally {
          e.isStable = !0;
        }
    }
}
function bg(e) {
  e.isCheckStableRunning ||
    e.callbackScheduled ||
    ((e.callbackScheduled = !0),
    Zone.root.run(() => {
      gl(() => {
        (e.callbackScheduled = !1),
          Mi(e),
          (e.isCheckStableRunning = !0),
          us(e),
          (e.isCheckStableRunning = !1);
      });
    }),
    Mi(e));
}
function Mg(e) {
  let t = () => {
    bg(e);
  };
  e._inner = e._inner.fork({
    name: "angular",
    properties: { isAngularZone: !0 },
    onInvokeTask: (n, r, o, i, s, a) => {
      if (Sg(a)) return n.invokeTask(o, i, s, a);
      try {
        return Dc(e), n.invokeTask(o, i, s, a);
      } finally {
        ((e.shouldCoalesceEventChangeDetection && i.type === "eventTask") ||
          e.shouldCoalesceRunChangeDetection) &&
          t(),
          wc(e);
      }
    },
    onInvoke: (n, r, o, i, s, a, c) => {
      try {
        return Dc(e), n.invoke(o, i, s, a, c);
      } finally {
        e.shouldCoalesceRunChangeDetection &&
          !e.callbackScheduled &&
          !xg(a) &&
          t(),
          wc(e);
      }
    },
    onHasTask: (n, r, o, i) => {
      n.hasTask(o, i),
        r === o &&
          (i.change == "microTask"
            ? ((e._hasPendingMicrotasks = i.microTask), Mi(e), us(e))
            : i.change == "macroTask" &&
              (e.hasPendingMacrotasks = i.macroTask));
    },
    onHandleError: (n, r, o, i) => (
      n.handleError(o, i), e.runOutsideAngular(() => e.onError.emit(i)), !1
    ),
  });
}
function Mi(e) {
  e._hasPendingMicrotasks ||
  ((e.shouldCoalesceEventChangeDetection ||
    e.shouldCoalesceRunChangeDetection) &&
    e.callbackScheduled === !0)
    ? (e.hasPendingMicrotasks = !0)
    : (e.hasPendingMicrotasks = !1);
}
function Dc(e) {
  e._nesting++, e.isStable && ((e.isStable = !1), e.onUnstable.emit(null));
}
function wc(e) {
  e._nesting--, us(e);
}
var Si = class {
  constructor() {
    (this.hasPendingMicrotasks = !1),
      (this.hasPendingMacrotasks = !1),
      (this.isStable = !0),
      (this.onUnstable = new K()),
      (this.onMicrotaskEmpty = new K()),
      (this.onStable = new K()),
      (this.onError = new K());
  }
  run(t, n, r) {
    return t.apply(n, r);
  }
  runGuarded(t, n, r) {
    return t.apply(n, r);
  }
  runOutsideAngular(t) {
    return t();
  }
  runTask(t, n, r, o) {
    return t.apply(n, r);
  }
};
function Sg(e) {
  return ml(e, "__ignore_ng_zone__");
}
function xg(e) {
  return ml(e, "__scheduler_tick__");
}
function ml(e, t) {
  return !Array.isArray(e) || e.length !== 1 ? !1 : e[0]?.data?.[t] === !0;
}
var vl = (() => {
  let t = class t {
    constructor() {
      (this.handler = null), (this.internalCallbacks = []);
    }
    execute() {
      this.executeInternalCallbacks(), this.handler?.execute();
    }
    executeInternalCallbacks() {
      let r = [...this.internalCallbacks];
      this.internalCallbacks.length = 0;
      for (let o of r) o();
    }
    ngOnDestroy() {
      this.handler?.destroy(),
        (this.handler = null),
        (this.internalCallbacks.length = 0);
    }
  };
  t.ɵprov = D({ token: t, providedIn: "root", factory: () => new t() });
  let e = t;
  return e;
})();
function xi(e, t, n) {
  let r = n ? e.styles : null,
    o = n ? e.classes : null,
    i = 0;
  if (t !== null)
    for (let s = 0; s < t.length; s++) {
      let a = t[s];
      if (typeof a == "number") i = a;
      else if (i == 1) o = Ha(o, a);
      else if (i == 2) {
        let c = a,
          u = t[++s];
        r = Ha(r, c + ": " + u + ";");
      }
    }
  n ? (e.styles = r) : (e.stylesWithoutHost = r),
    n ? (e.classes = o) : (e.classesWithoutHost = o);
}
var Or = class extends Vt {
  constructor(t) {
    super(), (this.ngModule = t);
  }
  resolveComponentFactory(t) {
    let n = ot(t);
    return new mn(n, this.ngModule);
  }
};
function Cc(e, t) {
  let n = [];
  for (let r in e) {
    if (!e.hasOwnProperty(r)) continue;
    let o = e[r];
    if (o === void 0) continue;
    let i = Array.isArray(o),
      s = i ? o[0] : o,
      a = i ? o[1] : qe.None;
    t
      ? n.push({
          propName: s,
          templateName: r,
          isSignal: (a & qe.SignalBased) !== 0,
        })
      : n.push({ propName: s, templateName: r });
  }
  return n;
}
function Tg(e) {
  let t = e.toLowerCase();
  return t === "svg" ? gh : t === "math" ? mh : null;
}
var mn = class extends Rr {
    get inputs() {
      let t = this.componentDef,
        n = t.inputTransforms,
        r = Cc(t.inputs, !0);
      if (n !== null)
        for (let o of r)
          n.hasOwnProperty(o.propName) && (o.transform = n[o.propName]);
      return r;
    }
    get outputs() {
      return Cc(this.componentDef.outputs, !1);
    }
    constructor(t, n) {
      super(),
        (this.componentDef = t),
        (this.ngModule = n),
        (this.componentType = t.type),
        (this.selector = Wf(t.selectors)),
        (this.ngContentSelectors = t.ngContentSelectors
          ? t.ngContentSelectors
          : []),
        (this.isBoundToModule = !!n);
    }
    create(t, n, r, o) {
      let i = P(null);
      try {
        o = o || this.ngModule;
        let s = o instanceof fe ? o : o?.injector;
        s &&
          this.componentDef.getStandaloneInjector !== null &&
          (s = this.componentDef.getStandaloneInjector(s) || s);
        let a = s ? new fi(t, s) : t,
          c = a.get($t, null);
        if (c === null) throw new v(407, !1);
        let u = a.get(Eg, null),
          l = a.get(vl, null),
          d = a.get(gn, null),
          h = {
            rendererFactory: c,
            sanitizer: u,
            inlineEffectRunner: null,
            afterRenderEventManager: l,
            changeDetectionScheduler: d,
          },
          f = c.createRenderer(null, this.componentDef),
          m = this.componentDef.selectors[0][0] || "div",
          S = r
            ? Lp(f, r, this.componentDef.encapsulation, a)
            : $u(f, m, Tg(m)),
          L = 512;
        this.componentDef.signals
          ? (L |= 4096)
          : this.componentDef.onPush || (L |= 16);
        let H = null;
        S !== null && (H = Xi(S, a, !0));
        let Ke = tl(0, null, null, 1, 0, null, null, null, null, null, null),
          ae = os(null, Ke, null, L, null, null, h, f, a, null, H);
        zi(ae);
        let ca, Wn;
        try {
          let Ve = this.componentDef,
            mt,
            wo = null;
          Ve.findHostDirectiveDefs
            ? ((mt = []),
              (wo = new Map()),
              Ve.findHostDirectiveDefs(Ve, mt, wo),
              mt.push(Ve))
            : (mt = [Ve]);
          let Fd = _g(ae, S),
            Ld = Ng(Fd, S, Ve, mt, ae, h, f);
          (Wn = vh(Ke, it)),
            S && Og(f, Ve, S, r),
            n !== void 0 && Pg(Wn, this.ngContentSelectors, n),
            (ca = Rg(Ld, Ve, mt, wo, ae, [kg])),
            sl(Ke, ae, null);
        } finally {
          Gi();
        }
        return new Ti(this.componentType, ca, Zi(Wn, ae), ae, Wn);
      } finally {
        P(i);
      }
    }
  },
  Ti = class extends Ii {
    constructor(t, n, r, o, i) {
      super(),
        (this.location = r),
        (this._rootLView = o),
        (this._tNode = i),
        (this.previousInputValues = null),
        (this.instance = n),
        (this.hostView = this.changeDetectorRef = new jt(o, void 0, !1)),
        (this.componentType = t);
    }
    setInput(t, n) {
      let r = this._tNode.inputs,
        o;
      if (r !== null && (o = r[t])) {
        if (
          ((this.previousInputValues ??= new Map()),
          this.previousInputValues.has(t) &&
            Object.is(this.previousInputValues.get(t), n))
        )
          return;
        let i = this._rootLView;
        il(i[T], i, o, t, n), this.previousInputValues.set(t, n);
        let s = wn(this._tNode.index, i);
        hl(s, 1);
      }
    }
    get injector() {
      return new rt(this._tNode, this._rootLView);
    }
    destroy() {
      this.hostView.destroy();
    }
    onDestroy(t) {
      this.hostView.onDestroy(t);
    }
  };
function _g(e, t) {
  let n = e[T],
    r = it;
  return (e[r] = t), is(n, r, 2, "#host", null);
}
function Ng(e, t, n, r, o, i, s) {
  let a = o[T];
  Ag(r, e, t, s);
  let c = null;
  t !== null && (c = Xi(t, o[Ft]));
  let u = i.rendererFactory.createRenderer(t, n),
    l = 16;
  n.signals ? (l = 4096) : n.onPush && (l = 64);
  let d = os(o, el(n), null, l, o[e.index], e, i, u, null, null, c);
  return (
    a.firstCreatePass && wi(a, e, r.length - 1), ss(o, d), (o[e.index] = d)
  );
}
function Ag(e, t, n, r) {
  for (let o of e) t.mergedAttrs = Fi(t.mergedAttrs, o.hostAttrs);
  t.mergedAttrs !== null &&
    (xi(t, t.mergedAttrs, !0), n !== null && Zu(r, n, t));
}
function Rg(e, t, n, r, o, i) {
  let s = Fe(),
    a = o[T],
    c = ke(s, o);
  nl(a, o, s, n, null, r);
  for (let l = 0; l < n.length; l++) {
    let d = s.directiveStart + l,
      h = pn(o, a, d, s);
    Lt(h, o);
  }
  rl(a, o, s), c && Lt(c, o);
  let u = pn(o, a, s.directiveStart + s.componentOffset, s);
  if (((e[We] = o[We] = u), i !== null)) for (let l of i) l(u, t);
  return Ju(a, s, o), u;
}
function Og(e, t, n, r) {
  if (r) ri(e, n, ["ng-version", "18.1.1"]);
  else {
    let { attrs: o, classes: i } = Zf(t.selectors[0]);
    o && ri(e, n, o), i && i.length > 0 && Wu(e, n, i.join(" "));
  }
}
function Pg(e, t, n) {
  let r = (e.projection = []);
  for (let o = 0; o < t.length; o++) {
    let i = n[o];
    r.push(i != null ? Array.from(i) : null);
  }
}
function kg() {
  let e = Fe();
  mu(De()[T], e);
}
var Zr = (() => {
  let t = class t {};
  t.__NG_ELEMENT_ID__ = Fg;
  let e = t;
  return e;
})();
function Fg() {
  let e = Fe();
  return jg(e, De());
}
var Lg = Zr,
  yl = class extends Lg {
    constructor(t, n, r) {
      super(),
        (this._lContainer = t),
        (this._hostTNode = n),
        (this._hostLView = r);
    }
    get element() {
      return Zi(this._hostTNode, this._hostLView);
    }
    get injector() {
      return new rt(this._hostTNode, this._hostLView);
    }
    get parentInjector() {
      let t = qi(this._hostTNode, this._hostLView);
      if (yu(t)) {
        let n = _r(t, this._hostLView),
          r = Tr(t),
          o = n[T].data[r + 8];
        return new rt(o, n);
      } else return new rt(null, this._hostLView);
    }
    clear() {
      for (; this.length > 0; ) this.remove(this.length - 1);
    }
    get(t) {
      let n = Ec(this._lContainer);
      return (n !== null && n[t]) || null;
    }
    get length() {
      return this._lContainer.length - de;
    }
    createEmbeddedView(t, n, r) {
      let o, i;
      typeof r == "number"
        ? (o = r)
        : r != null && ((o = r.index), (i = r.injector));
      let s = gc(this._lContainer, t.ssrId),
        a = t.createEmbeddedViewImpl(n || {}, i, s);
      return this.insertImpl(a, o, pc(this._hostTNode, s)), a;
    }
    createComponent(t, n, r, o, i) {
      let s = t && !lh(t),
        a;
      if (s) a = n;
      else {
        let m = n || {};
        (a = m.index),
          (r = m.injector),
          (o = m.projectableNodes),
          (i = m.environmentInjector || m.ngModuleRef);
      }
      let c = s ? t : new mn(ot(t)),
        u = r || this.parentInjector;
      if (!i && c.ngModule == null) {
        let S = (s ? u : this.parentInjector).get(fe, null);
        S && (i = S);
      }
      let l = ot(c.componentType ?? {}),
        d = gc(this._lContainer, l?.id ?? null),
        h = d?.firstChild ?? null,
        f = c.create(u, o, h, i);
      return this.insertImpl(f.hostView, a, pc(this._hostTNode, d)), f;
    }
    insert(t, n) {
      return this.insertImpl(t, n, !0);
    }
    insertImpl(t, n, r) {
      let o = t._lView;
      if (yh(o)) {
        let a = this.indexOf(t);
        if (a !== -1) this.detach(a);
        else {
          let c = o[X],
            u = new yl(c, c[we], c[X]);
          u.detach(u.indexOf(t));
        }
      }
      let i = this._adjustIndex(n),
        s = this._lContainer;
      return sg(s, o, i, r), t.attachToViewContainerRef(), Rc(Jo(s), i, t), t;
    }
    move(t, n) {
      return this.insert(t, n);
    }
    indexOf(t) {
      let n = Ec(this._lContainer);
      return n !== null ? n.indexOf(t) : -1;
    }
    remove(t) {
      let n = this._adjustIndex(t, -1),
        r = yi(this._lContainer, n);
      r && (Er(Jo(this._lContainer), n), Hu(r[T], r));
    }
    detach(t) {
      let n = this._adjustIndex(t, -1),
        r = yi(this._lContainer, n);
      return r && Er(Jo(this._lContainer), n) != null ? new jt(r) : null;
    }
    _adjustIndex(t, n = 0) {
      return t ?? this.length + n;
    }
  };
function Ec(e) {
  return e[Mr];
}
function Jo(e) {
  return e[Mr] || (e[Mr] = []);
}
function jg(e, t) {
  let n,
    r = t[e.index];
  return (
    Pe(r) ? (n = r) : ((n = tg(r, t, null, e)), (t[e.index] = n), ss(t, n)),
    $g(n, t, e, r),
    new yl(n, e, t)
  );
}
function Vg(e, t) {
  let n = e[Me],
    r = n.createComment(""),
    o = ke(t, e),
    i = ts(n, o);
  return Nr(n, i, r, Ip(n, o), !1), r;
}
var $g = Bg;
function Bg(e, t, n, r) {
  if (e[st]) return;
  let o;
  n.type & 8 ? (o = Ze(r)) : (o = Vg(t, n)), (e[st] = o);
}
var Ye = class {},
  vn = class {};
var _i = class extends Ye {
    constructor(t, n, r) {
      super(),
        (this._parent = n),
        (this._bootstrapComponents = []),
        (this.destroyCbs = []),
        (this.componentFactoryResolver = new Or(this));
      let o = $c(t);
      (this._bootstrapComponents = Vu(o.bootstrap)),
        (this._r3Injector = Tu(
          t,
          n,
          [
            { provide: Ye, useValue: this },
            { provide: Vt, useValue: this.componentFactoryResolver },
            ...r,
          ],
          re(t),
          new Set(["environment"])
        )),
        this._r3Injector.resolveInjectorInitializers(),
        (this.instance = this._r3Injector.get(t));
    }
    get injector() {
      return this._r3Injector;
    }
    destroy() {
      let t = this._r3Injector;
      !t.destroyed && t.destroy(),
        this.destroyCbs.forEach((n) => n()),
        (this.destroyCbs = null);
    }
    onDestroy(t) {
      this.destroyCbs.push(t);
    }
  },
  Ni = class extends vn {
    constructor(t) {
      super(), (this.moduleType = t);
    }
    create(t) {
      return new _i(this.moduleType, t, []);
    }
  };
var Pr = class extends Ye {
  constructor(t) {
    super(),
      (this.componentFactoryResolver = new Or(this)),
      (this.instance = null);
    let n = new un(
      [
        ...t.providers,
        { provide: Ye, useValue: this },
        { provide: Vt, useValue: this.componentFactoryResolver },
      ],
      t.parent || $i(),
      t.debugName,
      new Set(["environment"])
    );
    (this.injector = n),
      t.runEnvironmentInitializers && n.resolveInjectorInitializers();
  }
  destroy() {
    this.injector.destroy();
  }
  onDestroy(t) {
    this.injector.onDestroy(t);
  }
};
function ls(e, t, n = null) {
  return new Pr({
    providers: e,
    parent: t,
    debugName: n,
    runEnvironmentInitializers: !0,
  }).injector;
}
function Ug(e) {
  return (e.flags & 32) === 32;
}
function Ic(e, t, n, r, o) {
  let i = t.inputs,
    s = o ? "class" : "style";
  il(e, n, i[s], s, r);
}
function Hg(e, t, n, r, o, i) {
  let s = t.consts,
    a = nc(s, o),
    c = is(t, e, 2, r, a);
  return (
    Up(t, n, c, nc(s, i)),
    c.attrs !== null && xi(c, c.attrs, !1),
    c.mergedAttrs !== null && xi(c, c.mergedAttrs, !0),
    t.queries !== null && t.queries.elementStart(t, c),
    c
  );
}
function F(e, t, n, r) {
  let o = De(),
    i = Hi(),
    s = it + e,
    a = o[Me],
    c = i.firstCreatePass ? Hg(s, i, o, t, n, r) : i.data[s],
    u = zg(i, o, c, a, t, e);
  o[s] = u;
  let l = dh(c);
  return (
    Gr(c, !0),
    Zu(a, u, c),
    !Ug(c) && pu() && Gu(i, o, u, c),
    wh() === 0 && Lt(u, o),
    Ch(),
    l && (Pp(i, o, c), Ju(i, c, o)),
    r !== null && kp(o, c),
    F
  );
}
function B() {
  let e = Fe();
  iu() ? xh() : ((e = e.parent), Gr(e, !1));
  let t = e;
  bh(t) && Mh(), Eh();
  let n = Hi();
  return (
    n.firstCreatePass && (mu(n, e), Zc(e) && n.queries.elementEnd(e)),
    t.classesWithoutHost != null &&
      jh(t) &&
      Ic(n, t, De(), t.classesWithoutHost, !0),
    t.stylesWithoutHost != null &&
      Vh(t) &&
      Ic(n, t, De(), t.stylesWithoutHost, !1),
    B
  );
}
function U(e, t, n, r) {
  return F(e, t, n, r), B(), U;
}
var zg = (e, t, n, r, o, i) => (gu(!0), $u(r, o, Ph()));
var kr = "en-US";
var Gg = kr;
function qg(e) {
  typeof e == "string" && (Gg = e.toLowerCase().replace(/_/g, "-"));
}
function ee(e, t = "") {
  let n = De(),
    r = Hi(),
    o = e + it,
    i = r.firstCreatePass ? is(r, o, 1, t, null) : r.data[o],
    s = Wg(r, n, i, t, e);
  (n[o] = s), pu() && Gu(r, n, s, i), Gr(i, !1);
}
var Wg = (e, t, n, r, o) => (gu(!0), hp(t[Me], r));
var Zg = (() => {
  let t = class t {
    constructor(r) {
      (this._injector = r), (this.cachedInjectors = new Map());
    }
    getOrCreateStandaloneInjector(r) {
      if (!r.standalone) return null;
      if (!this.cachedInjectors.has(r)) {
        let o = Hc(!1, r.type),
          i =
            o.length > 0
              ? ls([o], this._injector, `Standalone[${r.type.name}]`)
              : null;
        this.cachedInjectors.set(r, i);
      }
      return this.cachedInjectors.get(r);
    }
    ngOnDestroy() {
      try {
        for (let r of this.cachedInjectors.values()) r !== null && r.destroy();
      } finally {
        this.cachedInjectors.clear();
      }
    }
  };
  t.ɵprov = D({
    token: t,
    providedIn: "environment",
    factory: () => new t(M(fe)),
  });
  let e = t;
  return e;
})();
function Yr(e) {
  cs("NgStandalone"),
    (e.getStandaloneInjector = (t) =>
      t.get(Zg).getOrCreateStandaloneInjector(e));
}
var Qr = (() => {
  let t = class t {
    log(r) {
      console.log(r);
    }
    warn(r) {
      console.warn(r);
    }
  };
  (t.ɵfac = function (o) {
    return new (o || t)();
  }),
    (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "platform" }));
  let e = t;
  return e;
})();
var Dl = new I("");
function Cn(e) {
  return !!e && typeof e.then == "function";
}
function wl(e) {
  return !!e && typeof e.subscribe == "function";
}
var Cl = new I(""),
  El = (() => {
    let t = class t {
      constructor() {
        (this.initialized = !1),
          (this.done = !1),
          (this.donePromise = new Promise((r, o) => {
            (this.resolve = r), (this.reject = o);
          })),
          (this.appInits = p(Cl, { optional: !0 }) ?? []);
      }
      runInitializers() {
        if (this.initialized) return;
        let r = [];
        for (let i of this.appInits) {
          let s = i();
          if (Cn(s)) r.push(s);
          else if (wl(s)) {
            let a = new Promise((c, u) => {
              s.subscribe({ complete: c, error: u });
            });
            r.push(a);
          }
        }
        let o = () => {
          (this.done = !0), this.resolve();
        };
        Promise.all(r)
          .then(() => {
            o();
          })
          .catch((i) => {
            this.reject(i);
          }),
          r.length === 0 && o(),
          (this.initialized = !0);
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })(),
  ds = new I("");
function Yg() {
  pa(() => {
    throw new v(600, !1);
  });
}
function Qg(e) {
  return e.isBoundToModule;
}
var Kg = 10;
function Xg(e, t, n) {
  try {
    let r = n();
    return Cn(r)
      ? r.catch((o) => {
          throw (t.runOutsideAngular(() => e.handleError(o)), o);
        })
      : r;
  } catch (r) {
    throw (t.runOutsideAngular(() => e.handleError(r)), r);
  }
}
var Ht = (() => {
  let t = class t {
    constructor() {
      (this._bootstrapListeners = []),
        (this._runningTick = !1),
        (this._destroyed = !1),
        (this._destroyListeners = []),
        (this._views = []),
        (this.internalErrorHandler = p(_u)),
        (this.afterRenderEffectManager = p(vl)),
        (this.zonelessEnabled = p(as)),
        (this.externalTestViews = new Set()),
        (this.beforeRender = new Q()),
        (this.afterTick = new Q()),
        (this.componentTypes = []),
        (this.components = []),
        (this.isStable = p(Bt).hasPendingTasks.pipe(x((r) => !r))),
        (this._injector = p(fe));
    }
    get allViews() {
      return [...this.externalTestViews.keys(), ...this._views];
    }
    get destroyed() {
      return this._destroyed;
    }
    get injector() {
      return this._injector;
    }
    bootstrap(r, o) {
      let i = r instanceof Rr;
      if (!this._injector.get(El).done) {
        let f = !i && Vc(r),
          m = !1;
        throw new v(405, m);
      }
      let a;
      i ? (a = r) : (a = this._injector.get(Vt).resolveComponentFactory(r)),
        this.componentTypes.push(a.componentType);
      let c = Qg(a) ? void 0 : this._injector.get(Ye),
        u = o || a.selector,
        l = a.create(ut.NULL, [], u, c),
        d = l.location.nativeElement,
        h = l.injector.get(Dl, null);
      return (
        h?.registerApplication(d),
        l.onDestroy(() => {
          this.detachView(l.hostView),
            ei(this.components, l),
            h?.unregisterApplication(d);
        }),
        this._loadComponent(l),
        l
      );
    }
    tick() {
      this._tick(!0);
    }
    _tick(r) {
      if (this._runningTick) throw new v(101, !1);
      let o = P(null);
      try {
        (this._runningTick = !0), this.detectChangesInAttachedViews(r);
      } catch (i) {
        this.internalErrorHandler(i);
      } finally {
        (this._runningTick = !1), P(o), this.afterTick.next();
      }
    }
    detectChangesInAttachedViews(r) {
      let o = null;
      this._injector.destroyed ||
        (o = this._injector.get($t, null, { optional: !0 }));
      let i = 0,
        s = this.afterRenderEffectManager;
      for (; i < Kg; ) {
        let a = i === 0;
        if (r || !a) {
          this.beforeRender.next(a);
          for (let { _lView: c, notifyErrorHandler: u } of this._views)
            Jg(c, u, a, this.zonelessEnabled);
        } else o?.begin?.(), o?.end?.();
        if (
          (i++,
          s.executeInternalCallbacks(),
          !this.allViews.some(({ _lView: c }) => fn(c)) &&
            (s.execute(), !this.allViews.some(({ _lView: c }) => fn(c))))
        )
          break;
      }
    }
    attachView(r) {
      let o = r;
      this._views.push(o), o.attachToAppRef(this);
    }
    detachView(r) {
      let o = r;
      ei(this._views, o), o.detachFromAppRef();
    }
    _loadComponent(r) {
      this.attachView(r.hostView), this.tick(), this.components.push(r);
      let o = this._injector.get(ds, []);
      [...this._bootstrapListeners, ...o].forEach((i) => i(r));
    }
    ngOnDestroy() {
      if (!this._destroyed)
        try {
          this._destroyListeners.forEach((r) => r()),
            this._views.slice().forEach((r) => r.destroy());
        } finally {
          (this._destroyed = !0),
            (this._views = []),
            (this._bootstrapListeners = []),
            (this._destroyListeners = []);
        }
    }
    onDestroy(r) {
      return (
        this._destroyListeners.push(r), () => ei(this._destroyListeners, r)
      );
    }
    destroy() {
      if (this._destroyed) throw new v(406, !1);
      let r = this._injector;
      r.destroy && !r.destroyed && r.destroy();
    }
    get viewCount() {
      return this._views.length;
    }
    warnIfDestroyed() {}
  };
  (t.ɵfac = function (o) {
    return new (o || t)();
  }),
    (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
  let e = t;
  return e;
})();
function ei(e, t) {
  let n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
}
function Jg(e, t, n, r) {
  if (!n && !fn(e)) return;
  ul(e, t, n && !r ? 0 : 1);
}
var Ai = class {
    constructor(t, n) {
      (this.ngModuleFactory = t), (this.componentFactories = n);
    }
  },
  fs = (() => {
    let t = class t {
      compileModuleSync(r) {
        return new Ni(r);
      }
      compileModuleAsync(r) {
        return Promise.resolve(this.compileModuleSync(r));
      }
      compileModuleAndAllComponentsSync(r) {
        let o = this.compileModuleSync(r),
          i = $c(r),
          s = Vu(i.declarations).reduce((a, c) => {
            let u = ot(c);
            return u && a.push(new mn(u)), a;
          }, []);
        return new Ai(o, s);
      }
      compileModuleAndAllComponentsAsync(r) {
        return Promise.resolve(this.compileModuleAndAllComponentsSync(r));
      }
      clearCache() {}
      clearCacheFor(r) {}
      getModuleId(r) {}
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })();
var em = (() => {
    let t = class t {
      constructor() {
        (this.zone = p($)),
          (this.changeDetectionScheduler = p(gn)),
          (this.applicationRef = p(Ht));
      }
      initialize() {
        this._onMicrotaskEmptySubscription ||
          (this._onMicrotaskEmptySubscription =
            this.zone.onMicrotaskEmpty.subscribe({
              next: () => {
                this.changeDetectionScheduler.runningTick ||
                  this.zone.run(() => {
                    this.applicationRef.tick();
                  });
              },
            }));
      }
      ngOnDestroy() {
        this._onMicrotaskEmptySubscription?.unsubscribe();
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })(),
  tm = new I("", { factory: () => !1 });
function Il({ ngZoneFactory: e, ignoreChangesOutsideZone: t }) {
  return (
    (e ??= () => new $(Ml())),
    [
      { provide: $, useFactory: e },
      {
        provide: kt,
        multi: !0,
        useFactory: () => {
          let n = p(em, { optional: !0 });
          return () => n.initialize();
        },
      },
      {
        provide: kt,
        multi: !0,
        useFactory: () => {
          let n = p(rm);
          return () => {
            n.initialize();
          };
        },
      },
      { provide: _u, useFactory: nm },
      t === !0 ? { provide: pl, useValue: !0 } : [],
    ]
  );
}
function nm() {
  let e = p($),
    t = p(Ae);
  return (n) => e.runOutsideAngular(() => t.handleError(n));
}
function bl(e) {
  let t = e?.ignoreChangesOutsideZone,
    n = Il({
      ngZoneFactory: () => {
        let r = Ml(e);
        return (
          r.shouldCoalesceEventChangeDetection && cs("NgZone_CoalesceEvent"),
          new $(r)
        );
      },
      ignoreChangesOutsideZone: t,
    });
  return Vr([{ provide: tm, useValue: !0 }, { provide: as, useValue: !1 }, n]);
}
function Ml(e) {
  return {
    enableLongStackTrace: !1,
    shouldCoalesceEventChangeDetection: e?.eventCoalescing ?? !1,
    shouldCoalesceRunChangeDetection: e?.runCoalescing ?? !1,
  };
}
var rm = (() => {
  let t = class t {
    constructor() {
      (this.subscription = new V()),
        (this.initialized = !1),
        (this.zone = p($)),
        (this.pendingTasks = p(Bt));
    }
    initialize() {
      if (this.initialized) return;
      this.initialized = !0;
      let r = null;
      !this.zone.isStable &&
        !this.zone.hasPendingMacrotasks &&
        !this.zone.hasPendingMicrotasks &&
        (r = this.pendingTasks.add()),
        this.zone.runOutsideAngular(() => {
          this.subscription.add(
            this.zone.onStable.subscribe(() => {
              $.assertNotInAngularZone(),
                queueMicrotask(() => {
                  r !== null &&
                    !this.zone.hasPendingMacrotasks &&
                    !this.zone.hasPendingMicrotasks &&
                    (this.pendingTasks.remove(r), (r = null));
                });
            })
          );
        }),
        this.subscription.add(
          this.zone.onUnstable.subscribe(() => {
            $.assertInAngularZone(), (r ??= this.pendingTasks.add());
          })
        );
    }
    ngOnDestroy() {
      this.subscription.unsubscribe();
    }
  };
  (t.ɵfac = function (o) {
    return new (o || t)();
  }),
    (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
  let e = t;
  return e;
})();
var om = (() => {
  let t = class t {
    constructor() {
      (this.appRef = p(Ht)),
        (this.taskService = p(Bt)),
        (this.ngZone = p($)),
        (this.zonelessEnabled = p(as)),
        (this.disableScheduling = p(pl, { optional: !0 }) ?? !1),
        (this.zoneIsDefined = typeof Zone < "u" && !!Zone.root.run),
        (this.schedulerTickApplyArgs = [{ data: { __scheduler_tick__: !0 } }]),
        (this.subscriptions = new V()),
        (this.cancelScheduledCallback = null),
        (this.shouldRefreshViews = !1),
        (this.useMicrotaskScheduler = !1),
        (this.runningTick = !1),
        (this.pendingRenderTaskId = null),
        this.subscriptions.add(
          this.appRef.afterTick.subscribe(() => {
            this.runningTick || this.cleanup();
          })
        ),
        this.subscriptions.add(
          this.ngZone.onUnstable.subscribe(() => {
            this.runningTick || this.cleanup();
          })
        ),
        (this.disableScheduling ||=
          !this.zonelessEnabled &&
          (this.ngZone instanceof Si || !this.zoneIsDefined));
    }
    notify(r) {
      if (!this.zonelessEnabled && r === 5) return;
      switch (r) {
        case 3:
        case 2:
        case 0:
        case 4:
        case 5:
        case 1: {
          this.shouldRefreshViews = !0;
          break;
        }
        case 8:
        case 7:
        case 6:
        case 9:
        default:
      }
      if (!this.shouldScheduleTick()) return;
      let o = this.useMicrotaskScheduler ? vc : gl;
      (this.pendingRenderTaskId = this.taskService.add()),
        this.zoneIsDefined
          ? Zone.root.run(() => {
              this.cancelScheduledCallback = o(() => {
                this.tick(this.shouldRefreshViews);
              });
            })
          : (this.cancelScheduledCallback = o(() => {
              this.tick(this.shouldRefreshViews);
            }));
    }
    shouldScheduleTick() {
      return !(
        this.disableScheduling ||
        this.pendingRenderTaskId !== null ||
        this.runningTick ||
        this.appRef._runningTick ||
        (!this.zonelessEnabled && this.zoneIsDefined && $.isInAngularZone())
      );
    }
    tick(r) {
      if (this.runningTick || this.appRef.destroyed) return;
      let o = this.taskService.add();
      try {
        this.ngZone.run(
          () => {
            (this.runningTick = !0), this.appRef._tick(r);
          },
          void 0,
          this.schedulerTickApplyArgs
        );
      } catch (i) {
        throw (this.taskService.remove(o), i);
      } finally {
        this.cleanup();
      }
      (this.useMicrotaskScheduler = !0),
        vc(() => {
          (this.useMicrotaskScheduler = !1), this.taskService.remove(o);
        });
    }
    ngOnDestroy() {
      this.subscriptions.unsubscribe(), this.cleanup();
    }
    cleanup() {
      if (
        ((this.shouldRefreshViews = !1),
        (this.runningTick = !1),
        this.cancelScheduledCallback?.(),
        (this.cancelScheduledCallback = null),
        this.pendingRenderTaskId !== null)
      ) {
        let r = this.pendingRenderTaskId;
        (this.pendingRenderTaskId = null), this.taskService.remove(r);
      }
    }
  };
  (t.ɵfac = function (o) {
    return new (o || t)();
  }),
    (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
  let e = t;
  return e;
})();
function im() {
  return (typeof $localize < "u" && $localize.locale) || kr;
}
var hs = new I("", {
  providedIn: "root",
  factory: () => p(hs, b.Optional | b.SkipSelf) || im(),
});
var Sl = new I("");
var Dr = null;
function sm(e = [], t) {
  return ut.create({
    name: t,
    providers: [
      { provide: $r, useValue: "platform" },
      { provide: Sl, useValue: new Set([() => (Dr = null)]) },
      ...e,
    ],
  });
}
function am(e = []) {
  if (Dr) return Dr;
  let t = sm(e);
  return (Dr = t), Yg(), cm(t), t;
}
function cm(e) {
  e.get(Qi, null)?.forEach((n) => n());
}
var En = (() => {
  let t = class t {};
  t.__NG_ELEMENT_ID__ = um;
  let e = t;
  return e;
})();
function um(e) {
  return lm(Fe(), De(), (e & 16) === 16);
}
function lm(e, t, n) {
  if (Bi(e) && !n) {
    let r = wn(e.index, t);
    return new jt(r, r);
  } else if (e.type & 175) {
    let r = t[Se];
    return new jt(r, t);
  }
  return null;
}
function xl(e) {
  try {
    let { rootComponent: t, appProviders: n, platformProviders: r } = e,
      o = am(r),
      i = [Il({}), { provide: gn, useExisting: om }, ...(n || [])],
      a = new Pr({
        providers: i,
        parent: o,
        debugName: "",
        runEnvironmentInitializers: !1,
      }).injector,
      c = a.get($);
    return c.run(() => {
      a.resolveInjectorInitializers();
      let u = a.get(Ae, null),
        l;
      c.runOutsideAngular(() => {
        l = c.onError.subscribe({
          next: (f) => {
            u.handleError(f);
          },
        });
      });
      let d = () => a.destroy(),
        h = o.get(Sl);
      return (
        h.add(d),
        a.onDestroy(() => {
          l.unsubscribe(), h.delete(d);
        }),
        Xg(u, c, () => {
          let f = a.get(El);
          return (
            f.runInitializers(),
            f.donePromise.then(() => {
              let m = a.get(hs, kr);
              qg(m || kr);
              let S = a.get(Ht);
              return t !== void 0 && S.bootstrap(t), S;
            })
          );
        })
      );
    });
  } catch (t) {
    return Promise.reject(t);
  }
}
var Tl = new I("");
var kl = null;
function zt() {
  return kl;
}
function Fl(e) {
  kl ??= e;
}
var Xr = class {};
var oe = new I(""),
  Ll = (() => {
    let t = class t {
      historyGo(r) {
        throw new Error("");
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: () => p(mm), providedIn: "platform" }));
    let e = t;
    return e;
  })();
var mm = (() => {
  let t = class t extends Ll {
    constructor() {
      super(),
        (this._doc = p(oe)),
        (this._location = window.location),
        (this._history = window.history);
    }
    getBaseHrefFromDOM() {
      return zt().getBaseHref(this._doc);
    }
    onPopState(r) {
      let o = zt().getGlobalEventTarget(this._doc, "window");
      return (
        o.addEventListener("popstate", r, !1),
        () => o.removeEventListener("popstate", r)
      );
    }
    onHashChange(r) {
      let o = zt().getGlobalEventTarget(this._doc, "window");
      return (
        o.addEventListener("hashchange", r, !1),
        () => o.removeEventListener("hashchange", r)
      );
    }
    get href() {
      return this._location.href;
    }
    get protocol() {
      return this._location.protocol;
    }
    get hostname() {
      return this._location.hostname;
    }
    get port() {
      return this._location.port;
    }
    get pathname() {
      return this._location.pathname;
    }
    get search() {
      return this._location.search;
    }
    get hash() {
      return this._location.hash;
    }
    set pathname(r) {
      this._location.pathname = r;
    }
    pushState(r, o, i) {
      this._history.pushState(r, o, i);
    }
    replaceState(r, o, i) {
      this._history.replaceState(r, o, i);
    }
    forward() {
      this._history.forward();
    }
    back() {
      this._history.back();
    }
    historyGo(r = 0) {
      this._history.go(r);
    }
    getState() {
      return this._history.state;
    }
  };
  (t.ɵfac = function (o) {
    return new (o || t)();
  }),
    (t.ɵprov = D({ token: t, factory: () => new t(), providedIn: "platform" }));
  let e = t;
  return e;
})();
function jl(e, t) {
  if (e.length == 0) return t;
  if (t.length == 0) return e;
  let n = 0;
  return (
    e.endsWith("/") && n++,
    t.startsWith("/") && n++,
    n == 2 ? e + t.substring(1) : n == 1 ? e + t : e + "/" + t
  );
}
function _l(e) {
  let t = e.match(/#|\?|$/),
    n = (t && t.index) || e.length,
    r = n - (e[n - 1] === "/" ? 1 : 0);
  return e.slice(0, r) + e.slice(n);
}
function dt(e) {
  return e && e[0] !== "?" ? "?" + e : e;
}
var eo = (() => {
    let t = class t {
      historyGo(r) {
        throw new Error("");
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: () => p(Vl), providedIn: "root" }));
    let e = t;
    return e;
  })(),
  vm = new I(""),
  Vl = (() => {
    let t = class t extends eo {
      constructor(r, o) {
        super(),
          (this._platformLocation = r),
          (this._removeListenerFns = []),
          (this._baseHref =
            o ??
            this._platformLocation.getBaseHrefFromDOM() ??
            p(oe).location?.origin ??
            "");
      }
      ngOnDestroy() {
        for (; this._removeListenerFns.length; )
          this._removeListenerFns.pop()();
      }
      onPopState(r) {
        this._removeListenerFns.push(
          this._platformLocation.onPopState(r),
          this._platformLocation.onHashChange(r)
        );
      }
      getBaseHref() {
        return this._baseHref;
      }
      prepareExternalUrl(r) {
        return jl(this._baseHref, r);
      }
      path(r = !1) {
        let o =
            this._platformLocation.pathname + dt(this._platformLocation.search),
          i = this._platformLocation.hash;
        return i && r ? `${o}${i}` : o;
      }
      pushState(r, o, i, s) {
        let a = this.prepareExternalUrl(i + dt(s));
        this._platformLocation.pushState(r, o, a);
      }
      replaceState(r, o, i, s) {
        let a = this.prepareExternalUrl(i + dt(s));
        this._platformLocation.replaceState(r, o, a);
      }
      forward() {
        this._platformLocation.forward();
      }
      back() {
        this._platformLocation.back();
      }
      getState() {
        return this._platformLocation.getState();
      }
      historyGo(r = 0) {
        this._platformLocation.historyGo?.(r);
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(M(Ll), M(vm, 8));
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })();
var In = (() => {
  let t = class t {
    constructor(r) {
      (this._subject = new K()),
        (this._urlChangeListeners = []),
        (this._urlChangeSubscription = null),
        (this._locationStrategy = r);
      let o = this._locationStrategy.getBaseHref();
      (this._basePath = wm(_l(Nl(o)))),
        this._locationStrategy.onPopState((i) => {
          this._subject.emit({
            url: this.path(!0),
            pop: !0,
            state: i.state,
            type: i.type,
          });
        });
    }
    ngOnDestroy() {
      this._urlChangeSubscription?.unsubscribe(),
        (this._urlChangeListeners = []);
    }
    path(r = !1) {
      return this.normalize(this._locationStrategy.path(r));
    }
    getState() {
      return this._locationStrategy.getState();
    }
    isCurrentPathEqualTo(r, o = "") {
      return this.path() == this.normalize(r + dt(o));
    }
    normalize(r) {
      return t.stripTrailingSlash(Dm(this._basePath, Nl(r)));
    }
    prepareExternalUrl(r) {
      return (
        r && r[0] !== "/" && (r = "/" + r),
        this._locationStrategy.prepareExternalUrl(r)
      );
    }
    go(r, o = "", i = null) {
      this._locationStrategy.pushState(i, "", r, o),
        this._notifyUrlChangeListeners(this.prepareExternalUrl(r + dt(o)), i);
    }
    replaceState(r, o = "", i = null) {
      this._locationStrategy.replaceState(i, "", r, o),
        this._notifyUrlChangeListeners(this.prepareExternalUrl(r + dt(o)), i);
    }
    forward() {
      this._locationStrategy.forward();
    }
    back() {
      this._locationStrategy.back();
    }
    historyGo(r = 0) {
      this._locationStrategy.historyGo?.(r);
    }
    onUrlChange(r) {
      return (
        this._urlChangeListeners.push(r),
        (this._urlChangeSubscription ??= this.subscribe((o) => {
          this._notifyUrlChangeListeners(o.url, o.state);
        })),
        () => {
          let o = this._urlChangeListeners.indexOf(r);
          this._urlChangeListeners.splice(o, 1),
            this._urlChangeListeners.length === 0 &&
              (this._urlChangeSubscription?.unsubscribe(),
              (this._urlChangeSubscription = null));
        }
      );
    }
    _notifyUrlChangeListeners(r = "", o) {
      this._urlChangeListeners.forEach((i) => i(r, o));
    }
    subscribe(r, o, i) {
      return this._subject.subscribe({ next: r, error: o, complete: i });
    }
  };
  (t.normalizeQueryParams = dt),
    (t.joinWithSlash = jl),
    (t.stripTrailingSlash = _l),
    (t.ɵfac = function (o) {
      return new (o || t)(M(eo));
    }),
    (t.ɵprov = D({ token: t, factory: () => ym(), providedIn: "root" }));
  let e = t;
  return e;
})();
function ym() {
  return new In(M(eo));
}
function Dm(e, t) {
  if (!e || !t.startsWith(e)) return t;
  let n = t.substring(e.length);
  return n === "" || ["/", ";", "?", "#"].includes(n[0]) ? n : t;
}
function Nl(e) {
  return e.replace(/\/index.html$/, "");
}
function wm(e) {
  if (new RegExp("^(https?:)?//").test(e)) {
    let [, n] = e.split(/\/\/[^\/]+/);
    return n;
  }
  return e;
}
function $l(e, t) {
  t = encodeURIComponent(t);
  for (let n of e.split(";")) {
    let r = n.indexOf("="),
      [o, i] = r == -1 ? [n, ""] : [n.slice(0, r), n.slice(r + 1)];
    if (o.trim() === t) return decodeURIComponent(i);
  }
  return null;
}
var Bl = "browser",
  Cm = "server";
function gs(e) {
  return e === Cm;
}
var Jr = class {};
var ys = class extends Xr {
    constructor() {
      super(...arguments), (this.supportsDOMEvents = !0);
    }
  },
  Ds = class e extends ys {
    static makeCurrent() {
      Fl(new e());
    }
    onAndCancel(t, n, r) {
      return (
        t.addEventListener(n, r),
        () => {
          t.removeEventListener(n, r);
        }
      );
    }
    dispatchEvent(t, n) {
      t.dispatchEvent(n);
    }
    remove(t) {
      t.parentNode && t.parentNode.removeChild(t);
    }
    createElement(t, n) {
      return (n = n || this.getDefaultDocument()), n.createElement(t);
    }
    createHtmlDocument() {
      return document.implementation.createHTMLDocument("fakeTitle");
    }
    getDefaultDocument() {
      return document;
    }
    isElementNode(t) {
      return t.nodeType === Node.ELEMENT_NODE;
    }
    isShadowRoot(t) {
      return t instanceof DocumentFragment;
    }
    getGlobalEventTarget(t, n) {
      return n === "window"
        ? window
        : n === "document"
        ? t
        : n === "body"
        ? t.body
        : null;
    }
    getBaseHref(t) {
      let n = Im();
      return n == null ? null : bm(n);
    }
    resetBaseElement() {
      bn = null;
    }
    getUserAgent() {
      return window.navigator.userAgent;
    }
    getCookie(t) {
      return $l(document.cookie, t);
    }
  },
  bn = null;
function Im() {
  return (
    (bn = bn || document.querySelector("base")),
    bn ? bn.getAttribute("href") : null
  );
}
function bm(e) {
  return new URL(e, document.baseURI).pathname;
}
var Mm = (() => {
    let t = class t {
      build() {
        return new XMLHttpRequest();
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac }));
    let e = t;
    return e;
  })(),
  to = new I(""),
  Gl = (() => {
    let t = class t {
      constructor(r, o) {
        (this._zone = o),
          (this._eventNameToPlugin = new Map()),
          r.forEach((i) => {
            i.manager = this;
          }),
          (this._plugins = r.slice().reverse());
      }
      addEventListener(r, o, i) {
        return this._findPluginFor(o).addEventListener(r, o, i);
      }
      getZone() {
        return this._zone;
      }
      _findPluginFor(r) {
        let o = this._eventNameToPlugin.get(r);
        if (o) return o;
        if (((o = this._plugins.find((s) => s.supports(r))), !o))
          throw new v(5101, !1);
        return this._eventNameToPlugin.set(r, o), o;
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(M(to), M($));
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac }));
    let e = t;
    return e;
  })(),
  Mn = class {
    constructor(t) {
      this._doc = t;
    }
  },
  ms = "ng-app-id",
  ql = (() => {
    let t = class t {
      constructor(r, o, i, s = {}) {
        (this.doc = r),
          (this.appId = o),
          (this.nonce = i),
          (this.platformId = s),
          (this.styleRef = new Map()),
          (this.hostNodes = new Set()),
          (this.styleNodesInDOM = this.collectServerRenderedStyles()),
          (this.platformIsServer = gs(s)),
          this.resetHostNodes();
      }
      addStyles(r) {
        for (let o of r)
          this.changeUsageCount(o, 1) === 1 && this.onStyleAdded(o);
      }
      removeStyles(r) {
        for (let o of r)
          this.changeUsageCount(o, -1) <= 0 && this.onStyleRemoved(o);
      }
      ngOnDestroy() {
        let r = this.styleNodesInDOM;
        r && (r.forEach((o) => o.remove()), r.clear());
        for (let o of this.getAllStyles()) this.onStyleRemoved(o);
        this.resetHostNodes();
      }
      addHost(r) {
        this.hostNodes.add(r);
        for (let o of this.getAllStyles()) this.addStyleToHost(r, o);
      }
      removeHost(r) {
        this.hostNodes.delete(r);
      }
      getAllStyles() {
        return this.styleRef.keys();
      }
      onStyleAdded(r) {
        for (let o of this.hostNodes) this.addStyleToHost(o, r);
      }
      onStyleRemoved(r) {
        let o = this.styleRef;
        o.get(r)?.elements?.forEach((i) => i.remove()), o.delete(r);
      }
      collectServerRenderedStyles() {
        let r = this.doc.head?.querySelectorAll(`style[${ms}="${this.appId}"]`);
        if (r?.length) {
          let o = new Map();
          return (
            r.forEach((i) => {
              i.textContent != null && o.set(i.textContent, i);
            }),
            o
          );
        }
        return null;
      }
      changeUsageCount(r, o) {
        let i = this.styleRef;
        if (i.has(r)) {
          let s = i.get(r);
          return (s.usage += o), s.usage;
        }
        return i.set(r, { usage: o, elements: [] }), o;
      }
      getStyleElement(r, o) {
        let i = this.styleNodesInDOM,
          s = i?.get(o);
        if (s?.parentNode === r) return i.delete(o), s.removeAttribute(ms), s;
        {
          let a = this.doc.createElement("style");
          return (
            this.nonce && a.setAttribute("nonce", this.nonce),
            (a.textContent = o),
            this.platformIsServer && a.setAttribute(ms, this.appId),
            r.appendChild(a),
            a
          );
        }
      }
      addStyleToHost(r, o) {
        let i = this.getStyleElement(r, o),
          s = this.styleRef,
          a = s.get(o)?.elements;
        a ? a.push(i) : s.set(o, { elements: [i], usage: 1 });
      }
      resetHostNodes() {
        let r = this.hostNodes;
        r.clear(), r.add(this.doc.head);
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(M(oe), M(Yi), M(Ki, 8), M(Ut));
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac }));
    let e = t;
    return e;
  })(),
  vs = {
    svg: "http://www.w3.org/2000/svg",
    xhtml: "http://www.w3.org/1999/xhtml",
    xlink: "http://www.w3.org/1999/xlink",
    xml: "http://www.w3.org/XML/1998/namespace",
    xmlns: "http://www.w3.org/2000/xmlns/",
    math: "http://www.w3.org/1998/Math/MathML",
  },
  Cs = /%COMP%/g,
  Wl = "%COMP%",
  Sm = `_nghost-${Wl}`,
  xm = `_ngcontent-${Wl}`,
  Tm = !0,
  _m = new I("", { providedIn: "root", factory: () => Tm });
function Nm(e) {
  return xm.replace(Cs, e);
}
function Am(e) {
  return Sm.replace(Cs, e);
}
function Zl(e, t) {
  return t.map((n) => n.replace(Cs, e));
}
var Ul = (() => {
    let t = class t {
      constructor(r, o, i, s, a, c, u, l = null) {
        (this.eventManager = r),
          (this.sharedStylesHost = o),
          (this.appId = i),
          (this.removeStylesOnCompDestroy = s),
          (this.doc = a),
          (this.platformId = c),
          (this.ngZone = u),
          (this.nonce = l),
          (this.rendererByCompId = new Map()),
          (this.platformIsServer = gs(c)),
          (this.defaultRenderer = new Sn(r, a, u, this.platformIsServer));
      }
      createRenderer(r, o) {
        if (!r || !o) return this.defaultRenderer;
        this.platformIsServer &&
          o.encapsulation === be.ShadowDom &&
          (o = j(g({}, o), { encapsulation: be.Emulated }));
        let i = this.getOrCreateRenderer(r, o);
        return (
          i instanceof no
            ? i.applyToHost(r)
            : i instanceof xn && i.applyStyles(),
          i
        );
      }
      getOrCreateRenderer(r, o) {
        let i = this.rendererByCompId,
          s = i.get(o.id);
        if (!s) {
          let a = this.doc,
            c = this.ngZone,
            u = this.eventManager,
            l = this.sharedStylesHost,
            d = this.removeStylesOnCompDestroy,
            h = this.platformIsServer;
          switch (o.encapsulation) {
            case be.Emulated:
              s = new no(u, l, o, this.appId, d, a, c, h);
              break;
            case be.ShadowDom:
              return new ws(u, l, r, o, a, c, this.nonce, h);
            default:
              s = new xn(u, l, o, d, a, c, h);
              break;
          }
          i.set(o.id, s);
        }
        return s;
      }
      ngOnDestroy() {
        this.rendererByCompId.clear();
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(
        M(Gl),
        M(ql),
        M(Yi),
        M(_m),
        M(oe),
        M(Ut),
        M($),
        M(Ki)
      );
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac }));
    let e = t;
    return e;
  })(),
  Sn = class {
    constructor(t, n, r, o) {
      (this.eventManager = t),
        (this.doc = n),
        (this.ngZone = r),
        (this.platformIsServer = o),
        (this.data = Object.create(null)),
        (this.throwOnSyntheticProps = !0),
        (this.destroyNode = null);
    }
    destroy() {}
    createElement(t, n) {
      return n
        ? this.doc.createElementNS(vs[n] || n, t)
        : this.doc.createElement(t);
    }
    createComment(t) {
      return this.doc.createComment(t);
    }
    createText(t) {
      return this.doc.createTextNode(t);
    }
    appendChild(t, n) {
      (Hl(t) ? t.content : t).appendChild(n);
    }
    insertBefore(t, n, r) {
      t && (Hl(t) ? t.content : t).insertBefore(n, r);
    }
    removeChild(t, n) {
      t && t.removeChild(n);
    }
    selectRootElement(t, n) {
      let r = typeof t == "string" ? this.doc.querySelector(t) : t;
      if (!r) throw new v(-5104, !1);
      return n || (r.textContent = ""), r;
    }
    parentNode(t) {
      return t.parentNode;
    }
    nextSibling(t) {
      return t.nextSibling;
    }
    setAttribute(t, n, r, o) {
      if (o) {
        n = o + ":" + n;
        let i = vs[o];
        i ? t.setAttributeNS(i, n, r) : t.setAttribute(n, r);
      } else t.setAttribute(n, r);
    }
    removeAttribute(t, n, r) {
      if (r) {
        let o = vs[r];
        o ? t.removeAttributeNS(o, n) : t.removeAttribute(`${r}:${n}`);
      } else t.removeAttribute(n);
    }
    addClass(t, n) {
      t.classList.add(n);
    }
    removeClass(t, n) {
      t.classList.remove(n);
    }
    setStyle(t, n, r, o) {
      o & (lt.DashCase | lt.Important)
        ? t.style.setProperty(n, r, o & lt.Important ? "important" : "")
        : (t.style[n] = r);
    }
    removeStyle(t, n, r) {
      r & lt.DashCase ? t.style.removeProperty(n) : (t.style[n] = "");
    }
    setProperty(t, n, r) {
      t != null && (t[n] = r);
    }
    setValue(t, n) {
      t.nodeValue = n;
    }
    listen(t, n, r) {
      if (
        typeof t == "string" &&
        ((t = zt().getGlobalEventTarget(this.doc, t)), !t)
      )
        throw new Error(`Unsupported event target ${t} for event ${n}`);
      return this.eventManager.addEventListener(
        t,
        n,
        this.decoratePreventDefault(r)
      );
    }
    decoratePreventDefault(t) {
      return (n) => {
        if (n === "__ngUnwrap__") return t;
        (this.platformIsServer ? this.ngZone.runGuarded(() => t(n)) : t(n)) ===
          !1 && n.preventDefault();
      };
    }
  };
function Hl(e) {
  return e.tagName === "TEMPLATE" && e.content !== void 0;
}
var ws = class extends Sn {
    constructor(t, n, r, o, i, s, a, c) {
      super(t, i, s, c),
        (this.sharedStylesHost = n),
        (this.hostEl = r),
        (this.shadowRoot = r.attachShadow({ mode: "open" })),
        this.sharedStylesHost.addHost(this.shadowRoot);
      let u = Zl(o.id, o.styles);
      for (let l of u) {
        let d = document.createElement("style");
        a && d.setAttribute("nonce", a),
          (d.textContent = l),
          this.shadowRoot.appendChild(d);
      }
    }
    nodeOrShadowRoot(t) {
      return t === this.hostEl ? this.shadowRoot : t;
    }
    appendChild(t, n) {
      return super.appendChild(this.nodeOrShadowRoot(t), n);
    }
    insertBefore(t, n, r) {
      return super.insertBefore(this.nodeOrShadowRoot(t), n, r);
    }
    removeChild(t, n) {
      return super.removeChild(this.nodeOrShadowRoot(t), n);
    }
    parentNode(t) {
      return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(t)));
    }
    destroy() {
      this.sharedStylesHost.removeHost(this.shadowRoot);
    }
  },
  xn = class extends Sn {
    constructor(t, n, r, o, i, s, a, c) {
      super(t, i, s, a),
        (this.sharedStylesHost = n),
        (this.removeStylesOnCompDestroy = o),
        (this.styles = c ? Zl(c, r.styles) : r.styles);
    }
    applyStyles() {
      this.sharedStylesHost.addStyles(this.styles);
    }
    destroy() {
      this.removeStylesOnCompDestroy &&
        this.sharedStylesHost.removeStyles(this.styles);
    }
  },
  no = class extends xn {
    constructor(t, n, r, o, i, s, a, c) {
      let u = o + "-" + r.id;
      super(t, n, r, i, s, a, c, u),
        (this.contentAttr = Nm(u)),
        (this.hostAttr = Am(u));
    }
    applyToHost(t) {
      this.applyStyles(), this.setAttribute(t, this.hostAttr, "");
    }
    createElement(t, n) {
      let r = super.createElement(t, n);
      return super.setAttribute(r, this.contentAttr, ""), r;
    }
  },
  Rm = (() => {
    let t = class t extends Mn {
      constructor(r) {
        super(r);
      }
      supports(r) {
        return !0;
      }
      addEventListener(r, o, i) {
        return (
          r.addEventListener(o, i, !1), () => this.removeEventListener(r, o, i)
        );
      }
      removeEventListener(r, o, i) {
        return r.removeEventListener(o, i);
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(M(oe));
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac }));
    let e = t;
    return e;
  })(),
  Om = (() => {
    let t = class t extends Mn {
      constructor(r) {
        super(r), (this.delegate = p(Tl, { optional: !0 }));
      }
      supports(r) {
        return this.delegate ? this.delegate.supports(r) : !1;
      }
      addEventListener(r, o, i) {
        return this.delegate.addEventListener(r, o, i);
      }
      removeEventListener(r, o, i) {
        return this.delegate.removeEventListener(r, o, i);
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(M(oe));
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac }));
    let e = t;
    return e;
  })(),
  zl = ["alt", "control", "meta", "shift"],
  Pm = {
    "\b": "Backspace",
    "	": "Tab",
    "\x7F": "Delete",
    "\x1B": "Escape",
    Del: "Delete",
    Esc: "Escape",
    Left: "ArrowLeft",
    Right: "ArrowRight",
    Up: "ArrowUp",
    Down: "ArrowDown",
    Menu: "ContextMenu",
    Scroll: "ScrollLock",
    Win: "OS",
  },
  km = {
    alt: (e) => e.altKey,
    control: (e) => e.ctrlKey,
    meta: (e) => e.metaKey,
    shift: (e) => e.shiftKey,
  },
  Fm = (() => {
    let t = class t extends Mn {
      constructor(r) {
        super(r);
      }
      supports(r) {
        return t.parseEventName(r) != null;
      }
      addEventListener(r, o, i) {
        let s = t.parseEventName(o),
          a = t.eventCallback(s.fullKey, i, this.manager.getZone());
        return this.manager
          .getZone()
          .runOutsideAngular(() => zt().onAndCancel(r, s.domEventName, a));
      }
      static parseEventName(r) {
        let o = r.toLowerCase().split("."),
          i = o.shift();
        if (o.length === 0 || !(i === "keydown" || i === "keyup")) return null;
        let s = t._normalizeKey(o.pop()),
          a = "",
          c = o.indexOf("code");
        if (
          (c > -1 && (o.splice(c, 1), (a = "code.")),
          zl.forEach((l) => {
            let d = o.indexOf(l);
            d > -1 && (o.splice(d, 1), (a += l + "."));
          }),
          (a += s),
          o.length != 0 || s.length === 0)
        )
          return null;
        let u = {};
        return (u.domEventName = i), (u.fullKey = a), u;
      }
      static matchEventFullKeyCode(r, o) {
        let i = Pm[r.key] || r.key,
          s = "";
        return (
          o.indexOf("code.") > -1 && ((i = r.code), (s = "code.")),
          i == null || !i
            ? !1
            : ((i = i.toLowerCase()),
              i === " " ? (i = "space") : i === "." && (i = "dot"),
              zl.forEach((a) => {
                if (a !== i) {
                  let c = km[a];
                  c(r) && (s += a + ".");
                }
              }),
              (s += i),
              s === o)
        );
      }
      static eventCallback(r, o, i) {
        return (s) => {
          t.matchEventFullKeyCode(s, r) && i.runGuarded(() => o(s));
        };
      }
      static _normalizeKey(r) {
        return r === "esc" ? "escape" : r;
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(M(oe));
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac }));
    let e = t;
    return e;
  })();
function Yl(e, t) {
  return xl(g({ rootComponent: e }, Lm(t)));
}
function Lm(e) {
  return {
    appProviders: [...Um, ...(e?.providers ?? [])],
    platformProviders: Bm,
  };
}
function jm() {
  Ds.makeCurrent();
}
function Vm() {
  return new Ae();
}
function $m() {
  return Fu(document), document;
}
var Bm = [
  { provide: Ut, useValue: Bl },
  { provide: Qi, useValue: jm, multi: !0 },
  { provide: oe, useFactory: $m, deps: [] },
];
var Um = [
  { provide: $r, useValue: "root" },
  { provide: Ae, useFactory: Vm, deps: [] },
  { provide: to, useClass: Rm, multi: !0, deps: [oe, $, Ut] },
  { provide: to, useClass: Fm, multi: !0, deps: [oe] },
  { provide: to, useClass: Om, multi: !0 },
  Ul,
  ql,
  Gl,
  { provide: $t, useExisting: Ul },
  { provide: Jr, useClass: Mm, deps: [] },
  [],
];
var Ql = (() => {
  let t = class t {
    constructor(r) {
      this._doc = r;
    }
    getTitle() {
      return this._doc.title;
    }
    setTitle(r) {
      this._doc.title = r || "";
    }
  };
  (t.ɵfac = function (o) {
    return new (o || t)(M(oe));
  }),
    (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
  let e = t;
  return e;
})();
var E = "primary",
  zn = Symbol("RouteTitle"),
  Ss = class {
    constructor(t) {
      this.params = t || {};
    }
    has(t) {
      return Object.prototype.hasOwnProperty.call(this.params, t);
    }
    get(t) {
      if (this.has(t)) {
        let n = this.params[t];
        return Array.isArray(n) ? n[0] : n;
      }
      return null;
    }
    getAll(t) {
      if (this.has(t)) {
        let n = this.params[t];
        return Array.isArray(n) ? n : [n];
      }
      return [];
    }
    get keys() {
      return Object.keys(this.params);
    }
  };
function Qt(e) {
  return new Ss(e);
}
function zm(e, t, n) {
  let r = n.path.split("/");
  if (
    r.length > e.length ||
    (n.pathMatch === "full" && (t.hasChildren() || r.length < e.length))
  )
    return null;
  let o = {};
  for (let i = 0; i < r.length; i++) {
    let s = r[i],
      a = e[i];
    if (s[0] === ":") o[s.substring(1)] = a;
    else if (s !== a.path) return null;
  }
  return { consumed: e.slice(0, r.length), posParams: o };
}
function Gm(e, t) {
  if (e.length !== t.length) return !1;
  for (let n = 0; n < e.length; ++n) if (!xe(e[n], t[n])) return !1;
  return !0;
}
function xe(e, t) {
  let n = e ? xs(e) : void 0,
    r = t ? xs(t) : void 0;
  if (!n || !r || n.length != r.length) return !1;
  let o;
  for (let i = 0; i < n.length; i++)
    if (((o = n[i]), !od(e[o], t[o]))) return !1;
  return !0;
}
function xs(e) {
  return [...Object.keys(e), ...Object.getOwnPropertySymbols(e)];
}
function od(e, t) {
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length) return !1;
    let n = [...e].sort(),
      r = [...t].sort();
    return n.every((o, i) => r[i] === o);
  } else return e === t;
}
function id(e) {
  return e.length > 0 ? e[e.length - 1] : null;
}
function Qe(e) {
  return Vo(e) ? e : Cn(e) ? z(Promise.resolve(e)) : w(e);
}
var qm = { exact: ad, subset: cd },
  sd = { exact: Wm, subset: Zm, ignored: () => !0 };
function Kl(e, t, n) {
  return (
    qm[n.paths](e.root, t.root, n.matrixParams) &&
    sd[n.queryParams](e.queryParams, t.queryParams) &&
    !(n.fragment === "exact" && e.fragment !== t.fragment)
  );
}
function Wm(e, t) {
  return xe(e, t);
}
function ad(e, t, n) {
  if (
    !ht(e.segments, t.segments) ||
    !io(e.segments, t.segments, n) ||
    e.numberOfChildren !== t.numberOfChildren
  )
    return !1;
  for (let r in t.children)
    if (!e.children[r] || !ad(e.children[r], t.children[r], n)) return !1;
  return !0;
}
function Zm(e, t) {
  return (
    Object.keys(t).length <= Object.keys(e).length &&
    Object.keys(t).every((n) => od(e[n], t[n]))
  );
}
function cd(e, t, n) {
  return ud(e, t, t.segments, n);
}
function ud(e, t, n, r) {
  if (e.segments.length > n.length) {
    let o = e.segments.slice(0, n.length);
    return !(!ht(o, n) || t.hasChildren() || !io(o, n, r));
  } else if (e.segments.length === n.length) {
    if (!ht(e.segments, n) || !io(e.segments, n, r)) return !1;
    for (let o in t.children)
      if (!e.children[o] || !cd(e.children[o], t.children[o], r)) return !1;
    return !0;
  } else {
    let o = n.slice(0, e.segments.length),
      i = n.slice(e.segments.length);
    return !ht(e.segments, o) || !io(e.segments, o, r) || !e.children[E]
      ? !1
      : ud(e.children[E], t, i, r);
  }
}
function io(e, t, n) {
  return t.every((r, o) => sd[n](e[o].parameters, r.parameters));
}
var je = class {
    constructor(t = new A([], {}), n = {}, r = null) {
      (this.root = t), (this.queryParams = n), (this.fragment = r);
    }
    get queryParamMap() {
      return (
        (this._queryParamMap ??= Qt(this.queryParams)), this._queryParamMap
      );
    }
    toString() {
      return Km.serialize(this);
    }
  },
  A = class {
    constructor(t, n) {
      (this.segments = t),
        (this.children = n),
        (this.parent = null),
        Object.values(n).forEach((r) => (r.parent = this));
    }
    hasChildren() {
      return this.numberOfChildren > 0;
    }
    get numberOfChildren() {
      return Object.keys(this.children).length;
    }
    toString() {
      return so(this);
    }
  },
  ft = class {
    constructor(t, n) {
      (this.path = t), (this.parameters = n);
    }
    get parameterMap() {
      return (this._parameterMap ??= Qt(this.parameters)), this._parameterMap;
    }
    toString() {
      return dd(this);
    }
  };
function Ym(e, t) {
  return ht(e, t) && e.every((n, r) => xe(n.parameters, t[r].parameters));
}
function ht(e, t) {
  return e.length !== t.length ? !1 : e.every((n, r) => n.path === t[r].path);
}
function Qm(e, t) {
  let n = [];
  return (
    Object.entries(e.children).forEach(([r, o]) => {
      r === E && (n = n.concat(t(o, r)));
    }),
    Object.entries(e.children).forEach(([r, o]) => {
      r !== E && (n = n.concat(t(o, r)));
    }),
    n
  );
}
var Js = (() => {
    let t = class t {};
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: () => new Pn(), providedIn: "root" }));
    let e = t;
    return e;
  })(),
  Pn = class {
    parse(t) {
      let n = new _s(t);
      return new je(
        n.parseRootSegment(),
        n.parseQueryParams(),
        n.parseFragment()
      );
    }
    serialize(t) {
      let n = `/${Tn(t.root, !0)}`,
        r = ev(t.queryParams),
        o = typeof t.fragment == "string" ? `#${Xm(t.fragment)}` : "";
      return `${n}${r}${o}`;
    }
  },
  Km = new Pn();
function so(e) {
  return e.segments.map((t) => dd(t)).join("/");
}
function Tn(e, t) {
  if (!e.hasChildren()) return so(e);
  if (t) {
    let n = e.children[E] ? Tn(e.children[E], !1) : "",
      r = [];
    return (
      Object.entries(e.children).forEach(([o, i]) => {
        o !== E && r.push(`${o}:${Tn(i, !1)}`);
      }),
      r.length > 0 ? `${n}(${r.join("//")})` : n
    );
  } else {
    let n = Qm(e, (r, o) =>
      o === E ? [Tn(e.children[E], !1)] : [`${o}:${Tn(r, !1)}`]
    );
    return Object.keys(e.children).length === 1 && e.children[E] != null
      ? `${so(e)}/${n[0]}`
      : `${so(e)}/(${n.join("//")})`;
  }
}
function ld(e) {
  return encodeURIComponent(e)
    .replace(/%40/g, "@")
    .replace(/%3A/gi, ":")
    .replace(/%24/g, "$")
    .replace(/%2C/gi, ",");
}
function ro(e) {
  return ld(e).replace(/%3B/gi, ";");
}
function Xm(e) {
  return encodeURI(e);
}
function Ts(e) {
  return ld(e)
    .replace(/\(/g, "%28")
    .replace(/\)/g, "%29")
    .replace(/%26/gi, "&");
}
function ao(e) {
  return decodeURIComponent(e);
}
function Xl(e) {
  return ao(e.replace(/\+/g, "%20"));
}
function dd(e) {
  return `${Ts(e.path)}${Jm(e.parameters)}`;
}
function Jm(e) {
  return Object.entries(e)
    .map(([t, n]) => `;${Ts(t)}=${Ts(n)}`)
    .join("");
}
function ev(e) {
  let t = Object.entries(e)
    .map(([n, r]) =>
      Array.isArray(r)
        ? r.map((o) => `${ro(n)}=${ro(o)}`).join("&")
        : `${ro(n)}=${ro(r)}`
    )
    .filter((n) => n);
  return t.length ? `?${t.join("&")}` : "";
}
var tv = /^[^\/()?;#]+/;
function Es(e) {
  let t = e.match(tv);
  return t ? t[0] : "";
}
var nv = /^[^\/()?;=#]+/;
function rv(e) {
  let t = e.match(nv);
  return t ? t[0] : "";
}
var ov = /^[^=?&#]+/;
function iv(e) {
  let t = e.match(ov);
  return t ? t[0] : "";
}
var sv = /^[^&#]+/;
function av(e) {
  let t = e.match(sv);
  return t ? t[0] : "";
}
var _s = class {
  constructor(t) {
    (this.url = t), (this.remaining = t);
  }
  parseRootSegment() {
    return (
      this.consumeOptional("/"),
      this.remaining === "" ||
      this.peekStartsWith("?") ||
      this.peekStartsWith("#")
        ? new A([], {})
        : new A([], this.parseChildren())
    );
  }
  parseQueryParams() {
    let t = {};
    if (this.consumeOptional("?"))
      do this.parseQueryParam(t);
      while (this.consumeOptional("&"));
    return t;
  }
  parseFragment() {
    return this.consumeOptional("#")
      ? decodeURIComponent(this.remaining)
      : null;
  }
  parseChildren() {
    if (this.remaining === "") return {};
    this.consumeOptional("/");
    let t = [];
    for (
      this.peekStartsWith("(") || t.push(this.parseSegment());
      this.peekStartsWith("/") &&
      !this.peekStartsWith("//") &&
      !this.peekStartsWith("/(");

    )
      this.capture("/"), t.push(this.parseSegment());
    let n = {};
    this.peekStartsWith("/(") &&
      (this.capture("/"), (n = this.parseParens(!0)));
    let r = {};
    return (
      this.peekStartsWith("(") && (r = this.parseParens(!1)),
      (t.length > 0 || Object.keys(n).length > 0) && (r[E] = new A(t, n)),
      r
    );
  }
  parseSegment() {
    let t = Es(this.remaining);
    if (t === "" && this.peekStartsWith(";")) throw new v(4009, !1);
    return this.capture(t), new ft(ao(t), this.parseMatrixParams());
  }
  parseMatrixParams() {
    let t = {};
    for (; this.consumeOptional(";"); ) this.parseParam(t);
    return t;
  }
  parseParam(t) {
    let n = rv(this.remaining);
    if (!n) return;
    this.capture(n);
    let r = "";
    if (this.consumeOptional("=")) {
      let o = Es(this.remaining);
      o && ((r = o), this.capture(r));
    }
    t[ao(n)] = ao(r);
  }
  parseQueryParam(t) {
    let n = iv(this.remaining);
    if (!n) return;
    this.capture(n);
    let r = "";
    if (this.consumeOptional("=")) {
      let s = av(this.remaining);
      s && ((r = s), this.capture(r));
    }
    let o = Xl(n),
      i = Xl(r);
    if (t.hasOwnProperty(o)) {
      let s = t[o];
      Array.isArray(s) || ((s = [s]), (t[o] = s)), s.push(i);
    } else t[o] = i;
  }
  parseParens(t) {
    let n = {};
    for (
      this.capture("(");
      !this.consumeOptional(")") && this.remaining.length > 0;

    ) {
      let r = Es(this.remaining),
        o = this.remaining[r.length];
      if (o !== "/" && o !== ")" && o !== ";") throw new v(4010, !1);
      let i;
      r.indexOf(":") > -1
        ? ((i = r.slice(0, r.indexOf(":"))), this.capture(i), this.capture(":"))
        : t && (i = E);
      let s = this.parseChildren();
      (n[i] = Object.keys(s).length === 1 ? s[E] : new A([], s)),
        this.consumeOptional("//");
    }
    return n;
  }
  peekStartsWith(t) {
    return this.remaining.startsWith(t);
  }
  consumeOptional(t) {
    return this.peekStartsWith(t)
      ? ((this.remaining = this.remaining.substring(t.length)), !0)
      : !1;
  }
  capture(t) {
    if (!this.consumeOptional(t)) throw new v(4011, !1);
  }
};
function fd(e) {
  return e.segments.length > 0 ? new A([], { [E]: e }) : e;
}
function hd(e) {
  let t = {};
  for (let [r, o] of Object.entries(e.children)) {
    let i = hd(o);
    if (r === E && i.segments.length === 0 && i.hasChildren())
      for (let [s, a] of Object.entries(i.children)) t[s] = a;
    else (i.segments.length > 0 || i.hasChildren()) && (t[r] = i);
  }
  let n = new A(e.segments, t);
  return cv(n);
}
function cv(e) {
  if (e.numberOfChildren === 1 && e.children[E]) {
    let t = e.children[E];
    return new A(e.segments.concat(t.segments), t.children);
  }
  return e;
}
function kn(e) {
  return e instanceof je;
}
function uv(e, t, n = null, r = null) {
  let o = pd(e);
  return gd(o, t, n, r);
}
function pd(e) {
  let t;
  function n(i) {
    let s = {};
    for (let c of i.children) {
      let u = n(c);
      s[c.outlet] = u;
    }
    let a = new A(i.url, s);
    return i === e && (t = a), a;
  }
  let r = n(e.root),
    o = fd(r);
  return t ?? o;
}
function gd(e, t, n, r) {
  let o = e;
  for (; o.parent; ) o = o.parent;
  if (t.length === 0) return Is(o, o, o, n, r);
  let i = lv(t);
  if (i.toRoot()) return Is(o, o, new A([], {}), n, r);
  let s = dv(i, o, e),
    a = s.processChildren
      ? An(s.segmentGroup, s.index, i.commands)
      : vd(s.segmentGroup, s.index, i.commands);
  return Is(o, s.segmentGroup, a, n, r);
}
function co(e) {
  return typeof e == "object" && e != null && !e.outlets && !e.segmentPath;
}
function Fn(e) {
  return typeof e == "object" && e != null && e.outlets;
}
function Is(e, t, n, r, o) {
  let i = {};
  r &&
    Object.entries(r).forEach(([c, u]) => {
      i[c] = Array.isArray(u) ? u.map((l) => `${l}`) : `${u}`;
    });
  let s;
  e === t ? (s = n) : (s = md(e, t, n));
  let a = fd(hd(s));
  return new je(a, i, o);
}
function md(e, t, n) {
  let r = {};
  return (
    Object.entries(e.children).forEach(([o, i]) => {
      i === t ? (r[o] = n) : (r[o] = md(i, t, n));
    }),
    new A(e.segments, r)
  );
}
var uo = class {
  constructor(t, n, r) {
    if (
      ((this.isAbsolute = t),
      (this.numberOfDoubleDots = n),
      (this.commands = r),
      t && r.length > 0 && co(r[0]))
    )
      throw new v(4003, !1);
    let o = r.find(Fn);
    if (o && o !== id(r)) throw new v(4004, !1);
  }
  toRoot() {
    return (
      this.isAbsolute && this.commands.length === 1 && this.commands[0] == "/"
    );
  }
};
function lv(e) {
  if (typeof e[0] == "string" && e.length === 1 && e[0] === "/")
    return new uo(!0, 0, e);
  let t = 0,
    n = !1,
    r = e.reduce((o, i, s) => {
      if (typeof i == "object" && i != null) {
        if (i.outlets) {
          let a = {};
          return (
            Object.entries(i.outlets).forEach(([c, u]) => {
              a[c] = typeof u == "string" ? u.split("/") : u;
            }),
            [...o, { outlets: a }]
          );
        }
        if (i.segmentPath) return [...o, i.segmentPath];
      }
      return typeof i != "string"
        ? [...o, i]
        : s === 0
        ? (i.split("/").forEach((a, c) => {
            (c == 0 && a === ".") ||
              (c == 0 && a === ""
                ? (n = !0)
                : a === ".."
                ? t++
                : a != "" && o.push(a));
          }),
          o)
        : [...o, i];
    }, []);
  return new uo(n, t, r);
}
var Wt = class {
  constructor(t, n, r) {
    (this.segmentGroup = t), (this.processChildren = n), (this.index = r);
  }
};
function dv(e, t, n) {
  if (e.isAbsolute) return new Wt(t, !0, 0);
  if (!n) return new Wt(t, !1, NaN);
  if (n.parent === null) return new Wt(n, !0, 0);
  let r = co(e.commands[0]) ? 0 : 1,
    o = n.segments.length - 1 + r;
  return fv(n, o, e.numberOfDoubleDots);
}
function fv(e, t, n) {
  let r = e,
    o = t,
    i = n;
  for (; i > o; ) {
    if (((i -= o), (r = r.parent), !r)) throw new v(4005, !1);
    o = r.segments.length;
  }
  return new Wt(r, !1, o - i);
}
function hv(e) {
  return Fn(e[0]) ? e[0].outlets : { [E]: e };
}
function vd(e, t, n) {
  if (((e ??= new A([], {})), e.segments.length === 0 && e.hasChildren()))
    return An(e, t, n);
  let r = pv(e, t, n),
    o = n.slice(r.commandIndex);
  if (r.match && r.pathIndex < e.segments.length) {
    let i = new A(e.segments.slice(0, r.pathIndex), {});
    return (
      (i.children[E] = new A(e.segments.slice(r.pathIndex), e.children)),
      An(i, 0, o)
    );
  } else
    return r.match && o.length === 0
      ? new A(e.segments, {})
      : r.match && !e.hasChildren()
      ? Ns(e, t, n)
      : r.match
      ? An(e, 0, o)
      : Ns(e, t, n);
}
function An(e, t, n) {
  if (n.length === 0) return new A(e.segments, {});
  {
    let r = hv(n),
      o = {};
    if (
      Object.keys(r).some((i) => i !== E) &&
      e.children[E] &&
      e.numberOfChildren === 1 &&
      e.children[E].segments.length === 0
    ) {
      let i = An(e.children[E], t, n);
      return new A(e.segments, i.children);
    }
    return (
      Object.entries(r).forEach(([i, s]) => {
        typeof s == "string" && (s = [s]),
          s !== null && (o[i] = vd(e.children[i], t, s));
      }),
      Object.entries(e.children).forEach(([i, s]) => {
        r[i] === void 0 && (o[i] = s);
      }),
      new A(e.segments, o)
    );
  }
}
function pv(e, t, n) {
  let r = 0,
    o = t,
    i = { match: !1, pathIndex: 0, commandIndex: 0 };
  for (; o < e.segments.length; ) {
    if (r >= n.length) return i;
    let s = e.segments[o],
      a = n[r];
    if (Fn(a)) break;
    let c = `${a}`,
      u = r < n.length - 1 ? n[r + 1] : null;
    if (o > 0 && c === void 0) break;
    if (c && u && typeof u == "object" && u.outlets === void 0) {
      if (!ed(c, u, s)) return i;
      r += 2;
    } else {
      if (!ed(c, {}, s)) return i;
      r++;
    }
    o++;
  }
  return { match: !0, pathIndex: o, commandIndex: r };
}
function Ns(e, t, n) {
  let r = e.segments.slice(0, t),
    o = 0;
  for (; o < n.length; ) {
    let i = n[o];
    if (Fn(i)) {
      let c = gv(i.outlets);
      return new A(r, c);
    }
    if (o === 0 && co(n[0])) {
      let c = e.segments[t];
      r.push(new ft(c.path, Jl(n[0]))), o++;
      continue;
    }
    let s = Fn(i) ? i.outlets[E] : `${i}`,
      a = o < n.length - 1 ? n[o + 1] : null;
    s && a && co(a)
      ? (r.push(new ft(s, Jl(a))), (o += 2))
      : (r.push(new ft(s, {})), o++);
  }
  return new A(r, {});
}
function gv(e) {
  let t = {};
  return (
    Object.entries(e).forEach(([n, r]) => {
      typeof r == "string" && (r = [r]),
        r !== null && (t[n] = Ns(new A([], {}), 0, r));
    }),
    t
  );
}
function Jl(e) {
  let t = {};
  return Object.entries(e).forEach(([n, r]) => (t[n] = `${r}`)), t;
}
function ed(e, t, n) {
  return e == n.path && xe(t, n.parameters);
}
var Rn = "imperative",
  Y = (function (e) {
    return (
      (e[(e.NavigationStart = 0)] = "NavigationStart"),
      (e[(e.NavigationEnd = 1)] = "NavigationEnd"),
      (e[(e.NavigationCancel = 2)] = "NavigationCancel"),
      (e[(e.NavigationError = 3)] = "NavigationError"),
      (e[(e.RoutesRecognized = 4)] = "RoutesRecognized"),
      (e[(e.ResolveStart = 5)] = "ResolveStart"),
      (e[(e.ResolveEnd = 6)] = "ResolveEnd"),
      (e[(e.GuardsCheckStart = 7)] = "GuardsCheckStart"),
      (e[(e.GuardsCheckEnd = 8)] = "GuardsCheckEnd"),
      (e[(e.RouteConfigLoadStart = 9)] = "RouteConfigLoadStart"),
      (e[(e.RouteConfigLoadEnd = 10)] = "RouteConfigLoadEnd"),
      (e[(e.ChildActivationStart = 11)] = "ChildActivationStart"),
      (e[(e.ChildActivationEnd = 12)] = "ChildActivationEnd"),
      (e[(e.ActivationStart = 13)] = "ActivationStart"),
      (e[(e.ActivationEnd = 14)] = "ActivationEnd"),
      (e[(e.Scroll = 15)] = "Scroll"),
      (e[(e.NavigationSkipped = 16)] = "NavigationSkipped"),
      e
    );
  })(Y || {}),
  he = class {
    constructor(t, n) {
      (this.id = t), (this.url = n);
    }
  },
  Ln = class extends he {
    constructor(t, n, r = "imperative", o = null) {
      super(t, n),
        (this.type = Y.NavigationStart),
        (this.navigationTrigger = r),
        (this.restoredState = o);
    }
    toString() {
      return `NavigationStart(id: ${this.id}, url: '${this.url}')`;
    }
  },
  pt = class extends he {
    constructor(t, n, r) {
      super(t, n), (this.urlAfterRedirects = r), (this.type = Y.NavigationEnd);
    }
    toString() {
      return `NavigationEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}')`;
    }
  },
  se = (function (e) {
    return (
      (e[(e.Redirect = 0)] = "Redirect"),
      (e[(e.SupersededByNewNavigation = 1)] = "SupersededByNewNavigation"),
      (e[(e.NoDataFromResolver = 2)] = "NoDataFromResolver"),
      (e[(e.GuardRejected = 3)] = "GuardRejected"),
      e
    );
  })(se || {}),
  As = (function (e) {
    return (
      (e[(e.IgnoredSameUrlNavigation = 0)] = "IgnoredSameUrlNavigation"),
      (e[(e.IgnoredByUrlHandlingStrategy = 1)] =
        "IgnoredByUrlHandlingStrategy"),
      e
    );
  })(As || {}),
  Le = class extends he {
    constructor(t, n, r, o) {
      super(t, n),
        (this.reason = r),
        (this.code = o),
        (this.type = Y.NavigationCancel);
    }
    toString() {
      return `NavigationCancel(id: ${this.id}, url: '${this.url}')`;
    }
  },
  gt = class extends he {
    constructor(t, n, r, o) {
      super(t, n),
        (this.reason = r),
        (this.code = o),
        (this.type = Y.NavigationSkipped);
    }
  },
  jn = class extends he {
    constructor(t, n, r, o) {
      super(t, n),
        (this.error = r),
        (this.target = o),
        (this.type = Y.NavigationError);
    }
    toString() {
      return `NavigationError(id: ${this.id}, url: '${this.url}', error: ${this.error})`;
    }
  },
  lo = class extends he {
    constructor(t, n, r, o) {
      super(t, n),
        (this.urlAfterRedirects = r),
        (this.state = o),
        (this.type = Y.RoutesRecognized);
    }
    toString() {
      return `RoutesRecognized(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
    }
  },
  Rs = class extends he {
    constructor(t, n, r, o) {
      super(t, n),
        (this.urlAfterRedirects = r),
        (this.state = o),
        (this.type = Y.GuardsCheckStart);
    }
    toString() {
      return `GuardsCheckStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
    }
  },
  Os = class extends he {
    constructor(t, n, r, o, i) {
      super(t, n),
        (this.urlAfterRedirects = r),
        (this.state = o),
        (this.shouldActivate = i),
        (this.type = Y.GuardsCheckEnd);
    }
    toString() {
      return `GuardsCheckEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state}, shouldActivate: ${this.shouldActivate})`;
    }
  },
  Ps = class extends he {
    constructor(t, n, r, o) {
      super(t, n),
        (this.urlAfterRedirects = r),
        (this.state = o),
        (this.type = Y.ResolveStart);
    }
    toString() {
      return `ResolveStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
    }
  },
  ks = class extends he {
    constructor(t, n, r, o) {
      super(t, n),
        (this.urlAfterRedirects = r),
        (this.state = o),
        (this.type = Y.ResolveEnd);
    }
    toString() {
      return `ResolveEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
    }
  },
  Fs = class {
    constructor(t) {
      (this.route = t), (this.type = Y.RouteConfigLoadStart);
    }
    toString() {
      return `RouteConfigLoadStart(path: ${this.route.path})`;
    }
  },
  Ls = class {
    constructor(t) {
      (this.route = t), (this.type = Y.RouteConfigLoadEnd);
    }
    toString() {
      return `RouteConfigLoadEnd(path: ${this.route.path})`;
    }
  },
  js = class {
    constructor(t) {
      (this.snapshot = t), (this.type = Y.ChildActivationStart);
    }
    toString() {
      return `ChildActivationStart(path: '${
        (this.snapshot.routeConfig && this.snapshot.routeConfig.path) || ""
      }')`;
    }
  },
  Vs = class {
    constructor(t) {
      (this.snapshot = t), (this.type = Y.ChildActivationEnd);
    }
    toString() {
      return `ChildActivationEnd(path: '${
        (this.snapshot.routeConfig && this.snapshot.routeConfig.path) || ""
      }')`;
    }
  },
  $s = class {
    constructor(t) {
      (this.snapshot = t), (this.type = Y.ActivationStart);
    }
    toString() {
      return `ActivationStart(path: '${
        (this.snapshot.routeConfig && this.snapshot.routeConfig.path) || ""
      }')`;
    }
  },
  Bs = class {
    constructor(t) {
      (this.snapshot = t), (this.type = Y.ActivationEnd);
    }
    toString() {
      return `ActivationEnd(path: '${
        (this.snapshot.routeConfig && this.snapshot.routeConfig.path) || ""
      }')`;
    }
  };
var Vn = class {},
  Kt = class {
    constructor(t, n) {
      (this.url = t), (this.navigationBehaviorOptions = n);
    }
  };
function mv(e, t) {
  return (
    e.providers &&
      !e._injector &&
      (e._injector = ls(e.providers, t, `Route: ${e.path}`)),
    e._injector ?? t
  );
}
function Ce(e) {
  return e.outlet || E;
}
function vv(e, t) {
  let n = e.filter((r) => Ce(r) === t);
  return n.push(...e.filter((r) => Ce(r) !== t)), n;
}
function Gn(e) {
  if (!e) return null;
  if (e.routeConfig?._injector) return e.routeConfig._injector;
  for (let t = e.parent; t; t = t.parent) {
    let n = t.routeConfig;
    if (n?._loadedInjector) return n._loadedInjector;
    if (n?._injector) return n._injector;
  }
  return null;
}
var Us = class {
    get injector() {
      return Gn(this.route?.snapshot) ?? this.rootInjector;
    }
    set injector(t) {}
    constructor(t) {
      (this.rootInjector = t),
        (this.outlet = null),
        (this.route = null),
        (this.children = new yo(this.rootInjector)),
        (this.attachRef = null);
    }
  },
  yo = (() => {
    let t = class t {
      constructor(r) {
        (this.rootInjector = r), (this.contexts = new Map());
      }
      onChildOutletCreated(r, o) {
        let i = this.getOrCreateContext(r);
        (i.outlet = o), this.contexts.set(r, i);
      }
      onChildOutletDestroyed(r) {
        let o = this.getContext(r);
        o && ((o.outlet = null), (o.attachRef = null));
      }
      onOutletDeactivated() {
        let r = this.contexts;
        return (this.contexts = new Map()), r;
      }
      onOutletReAttached(r) {
        this.contexts = r;
      }
      getOrCreateContext(r) {
        let o = this.getContext(r);
        return (
          o || ((o = new Us(this.rootInjector)), this.contexts.set(r, o)), o
        );
      }
      getContext(r) {
        return this.contexts.get(r) || null;
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(M(fe));
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })(),
  fo = class {
    constructor(t) {
      this._root = t;
    }
    get root() {
      return this._root.value;
    }
    parent(t) {
      let n = this.pathFromRoot(t);
      return n.length > 1 ? n[n.length - 2] : null;
    }
    children(t) {
      let n = Hs(t, this._root);
      return n ? n.children.map((r) => r.value) : [];
    }
    firstChild(t) {
      let n = Hs(t, this._root);
      return n && n.children.length > 0 ? n.children[0].value : null;
    }
    siblings(t) {
      let n = zs(t, this._root);
      return n.length < 2
        ? []
        : n[n.length - 2].children.map((o) => o.value).filter((o) => o !== t);
    }
    pathFromRoot(t) {
      return zs(t, this._root).map((n) => n.value);
    }
  };
function Hs(e, t) {
  if (e === t.value) return t;
  for (let n of t.children) {
    let r = Hs(e, n);
    if (r) return r;
  }
  return null;
}
function zs(e, t) {
  if (e === t.value) return [t];
  for (let n of t.children) {
    let r = zs(e, n);
    if (r.length) return r.unshift(t), r;
  }
  return [];
}
var ie = class {
  constructor(t, n) {
    (this.value = t), (this.children = n);
  }
  toString() {
    return `TreeNode(${this.value})`;
  }
};
function qt(e) {
  let t = {};
  return e && e.children.forEach((n) => (t[n.value.outlet] = n)), t;
}
var ho = class extends fo {
  constructor(t, n) {
    super(t), (this.snapshot = n), ea(this, t);
  }
  toString() {
    return this.snapshot.toString();
  }
};
function yd(e) {
  let t = yv(e),
    n = new W([new ft("", {})]),
    r = new W({}),
    o = new W({}),
    i = new W({}),
    s = new W(""),
    a = new Xt(n, r, i, s, o, E, e, t.root);
  return (a.snapshot = t.root), new ho(new ie(a, []), t);
}
function yv(e) {
  let t = {},
    n = {},
    r = {},
    o = "",
    i = new Zt([], t, r, o, n, E, e, null, {});
  return new go("", new ie(i, []));
}
var Xt = class {
  constructor(t, n, r, o, i, s, a, c) {
    (this.urlSubject = t),
      (this.paramsSubject = n),
      (this.queryParamsSubject = r),
      (this.fragmentSubject = o),
      (this.dataSubject = i),
      (this.outlet = s),
      (this.component = a),
      (this._futureSnapshot = c),
      (this.title = this.dataSubject?.pipe(x((u) => u[zn])) ?? w(void 0)),
      (this.url = t),
      (this.params = n),
      (this.queryParams = r),
      (this.fragment = o),
      (this.data = i);
  }
  get routeConfig() {
    return this._futureSnapshot.routeConfig;
  }
  get root() {
    return this._routerState.root;
  }
  get parent() {
    return this._routerState.parent(this);
  }
  get firstChild() {
    return this._routerState.firstChild(this);
  }
  get children() {
    return this._routerState.children(this);
  }
  get pathFromRoot() {
    return this._routerState.pathFromRoot(this);
  }
  get paramMap() {
    return (
      (this._paramMap ??= this.params.pipe(x((t) => Qt(t)))), this._paramMap
    );
  }
  get queryParamMap() {
    return (
      (this._queryParamMap ??= this.queryParams.pipe(x((t) => Qt(t)))),
      this._queryParamMap
    );
  }
  toString() {
    return this.snapshot
      ? this.snapshot.toString()
      : `Future(${this._futureSnapshot})`;
  }
};
function po(e, t, n = "emptyOnly") {
  let r,
    { routeConfig: o } = e;
  return (
    t !== null &&
    (n === "always" ||
      o?.path === "" ||
      (!t.component && !t.routeConfig?.loadComponent))
      ? (r = {
          params: g(g({}, t.params), e.params),
          data: g(g({}, t.data), e.data),
          resolve: g(g(g(g({}, e.data), t.data), o?.data), e._resolvedData),
        })
      : (r = {
          params: g({}, e.params),
          data: g({}, e.data),
          resolve: g(g({}, e.data), e._resolvedData ?? {}),
        }),
    o && wd(o) && (r.resolve[zn] = o.title),
    r
  );
}
var Zt = class {
    get title() {
      return this.data?.[zn];
    }
    constructor(t, n, r, o, i, s, a, c, u) {
      (this.url = t),
        (this.params = n),
        (this.queryParams = r),
        (this.fragment = o),
        (this.data = i),
        (this.outlet = s),
        (this.component = a),
        (this.routeConfig = c),
        (this._resolve = u);
    }
    get root() {
      return this._routerState.root;
    }
    get parent() {
      return this._routerState.parent(this);
    }
    get firstChild() {
      return this._routerState.firstChild(this);
    }
    get children() {
      return this._routerState.children(this);
    }
    get pathFromRoot() {
      return this._routerState.pathFromRoot(this);
    }
    get paramMap() {
      return (this._paramMap ??= Qt(this.params)), this._paramMap;
    }
    get queryParamMap() {
      return (
        (this._queryParamMap ??= Qt(this.queryParams)), this._queryParamMap
      );
    }
    toString() {
      let t = this.url.map((r) => r.toString()).join("/"),
        n = this.routeConfig ? this.routeConfig.path : "";
      return `Route(url:'${t}', path:'${n}')`;
    }
  },
  go = class extends fo {
    constructor(t, n) {
      super(n), (this.url = t), ea(this, n);
    }
    toString() {
      return Dd(this._root);
    }
  };
function ea(e, t) {
  (t.value._routerState = e), t.children.forEach((n) => ea(e, n));
}
function Dd(e) {
  let t = e.children.length > 0 ? ` { ${e.children.map(Dd).join(", ")} } ` : "";
  return `${e.value}${t}`;
}
function bs(e) {
  if (e.snapshot) {
    let t = e.snapshot,
      n = e._futureSnapshot;
    (e.snapshot = n),
      xe(t.queryParams, n.queryParams) ||
        e.queryParamsSubject.next(n.queryParams),
      t.fragment !== n.fragment && e.fragmentSubject.next(n.fragment),
      xe(t.params, n.params) || e.paramsSubject.next(n.params),
      Gm(t.url, n.url) || e.urlSubject.next(n.url),
      xe(t.data, n.data) || e.dataSubject.next(n.data);
  } else
    (e.snapshot = e._futureSnapshot),
      e.dataSubject.next(e._futureSnapshot.data);
}
function Gs(e, t) {
  let n = xe(e.params, t.params) && Ym(e.url, t.url),
    r = !e.parent != !t.parent;
  return n && !r && (!e.parent || Gs(e.parent, t.parent));
}
function wd(e) {
  return typeof e.title == "string" || e.title === null;
}
var ta = (() => {
    let t = class t {
      constructor() {
        (this.activated = null),
          (this._activatedRoute = null),
          (this.name = E),
          (this.activateEvents = new K()),
          (this.deactivateEvents = new K()),
          (this.attachEvents = new K()),
          (this.detachEvents = new K()),
          (this.parentContexts = p(yo)),
          (this.location = p(Zr)),
          (this.changeDetector = p(En)),
          (this.inputBinder = p(na, { optional: !0 })),
          (this.supportsBindingToComponentInputs = !0);
      }
      get activatedComponentRef() {
        return this.activated;
      }
      ngOnChanges(r) {
        if (r.name) {
          let { firstChange: o, previousValue: i } = r.name;
          if (o) return;
          this.isTrackedInParentContexts(i) &&
            (this.deactivate(), this.parentContexts.onChildOutletDestroyed(i)),
            this.initializeOutletWithName();
        }
      }
      ngOnDestroy() {
        this.isTrackedInParentContexts(this.name) &&
          this.parentContexts.onChildOutletDestroyed(this.name),
          this.inputBinder?.unsubscribeFromRouteData(this);
      }
      isTrackedInParentContexts(r) {
        return this.parentContexts.getContext(r)?.outlet === this;
      }
      ngOnInit() {
        this.initializeOutletWithName();
      }
      initializeOutletWithName() {
        if (
          (this.parentContexts.onChildOutletCreated(this.name, this),
          this.activated)
        )
          return;
        let r = this.parentContexts.getContext(this.name);
        r?.route &&
          (r.attachRef
            ? this.attach(r.attachRef, r.route)
            : this.activateWith(r.route, r.injector));
      }
      get isActivated() {
        return !!this.activated;
      }
      get component() {
        if (!this.activated) throw new v(4012, !1);
        return this.activated.instance;
      }
      get activatedRoute() {
        if (!this.activated) throw new v(4012, !1);
        return this._activatedRoute;
      }
      get activatedRouteData() {
        return this._activatedRoute ? this._activatedRoute.snapshot.data : {};
      }
      detach() {
        if (!this.activated) throw new v(4012, !1);
        this.location.detach();
        let r = this.activated;
        return (
          (this.activated = null),
          (this._activatedRoute = null),
          this.detachEvents.emit(r.instance),
          r
        );
      }
      attach(r, o) {
        (this.activated = r),
          (this._activatedRoute = o),
          this.location.insert(r.hostView),
          this.inputBinder?.bindActivatedRouteToOutletComponent(this),
          this.attachEvents.emit(r.instance);
      }
      deactivate() {
        if (this.activated) {
          let r = this.component;
          this.activated.destroy(),
            (this.activated = null),
            (this._activatedRoute = null),
            this.deactivateEvents.emit(r);
        }
      }
      activateWith(r, o) {
        if (this.isActivated) throw new v(4013, !1);
        this._activatedRoute = r;
        let i = this.location,
          a = r.snapshot.component,
          c = this.parentContexts.getOrCreateContext(this.name).children,
          u = new qs(r, c, i.injector);
        (this.activated = i.createComponent(a, {
          index: i.length,
          injector: u,
          environmentInjector: o,
        })),
          this.changeDetector.markForCheck(),
          this.inputBinder?.bindActivatedRouteToOutletComponent(this),
          this.activateEvents.emit(this.activated.instance);
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵdir = ji({
        type: t,
        selectors: [["router-outlet"]],
        inputs: { name: "name" },
        outputs: {
          activateEvents: "activate",
          deactivateEvents: "deactivate",
          attachEvents: "attach",
          detachEvents: "detach",
        },
        exportAs: ["outlet"],
        standalone: !0,
        features: [Hr],
      }));
    let e = t;
    return e;
  })(),
  qs = class e {
    __ngOutletInjector(t) {
      return new e(this.route, this.childContexts, t);
    }
    constructor(t, n, r) {
      (this.route = t), (this.childContexts = n), (this.parent = r);
    }
    get(t, n) {
      return t === Xt
        ? this.route
        : t === yo
        ? this.childContexts
        : this.parent.get(t, n);
    }
  },
  na = new I("");
function Dv(e, t, n) {
  let r = $n(e, t._root, n ? n._root : void 0);
  return new ho(r, t);
}
function $n(e, t, n) {
  if (n && e.shouldReuseRoute(t.value, n.value.snapshot)) {
    let r = n.value;
    r._futureSnapshot = t.value;
    let o = wv(e, t, n);
    return new ie(r, o);
  } else {
    if (e.shouldAttach(t.value)) {
      let i = e.retrieve(t.value);
      if (i !== null) {
        let s = i.route;
        return (
          (s.value._futureSnapshot = t.value),
          (s.children = t.children.map((a) => $n(e, a))),
          s
        );
      }
    }
    let r = Cv(t.value),
      o = t.children.map((i) => $n(e, i));
    return new ie(r, o);
  }
}
function wv(e, t, n) {
  return t.children.map((r) => {
    for (let o of n.children)
      if (e.shouldReuseRoute(r.value, o.value.snapshot)) return $n(e, r, o);
    return $n(e, r);
  });
}
function Cv(e) {
  return new Xt(
    new W(e.url),
    new W(e.params),
    new W(e.queryParams),
    new W(e.fragment),
    new W(e.data),
    e.outlet,
    e.component,
    e
  );
}
var Bn = class {
    constructor(t, n) {
      (this.redirectTo = t), (this.navigationBehaviorOptions = n);
    }
  },
  Cd = "ngNavigationCancelingError";
function mo(e, t) {
  let { redirectTo: n, navigationBehaviorOptions: r } = kn(t)
      ? { redirectTo: t, navigationBehaviorOptions: void 0 }
      : t,
    o = Ed(!1, se.Redirect);
  return (o.url = n), (o.navigationBehaviorOptions = r), o;
}
function Ed(e, t) {
  let n = new Error(`NavigationCancelingError: ${e || ""}`);
  return (n[Cd] = !0), (n.cancellationCode = t), n;
}
function Ev(e) {
  return Id(e) && kn(e.url);
}
function Id(e) {
  return !!e && e[Cd];
}
var Iv = (e, t, n, r) =>
    x(
      (o) => (
        new Ws(t, o.targetRouterState, o.currentRouterState, n, r).activate(e),
        o
      )
    ),
  Ws = class {
    constructor(t, n, r, o, i) {
      (this.routeReuseStrategy = t),
        (this.futureState = n),
        (this.currState = r),
        (this.forwardEvent = o),
        (this.inputBindingEnabled = i);
    }
    activate(t) {
      let n = this.futureState._root,
        r = this.currState ? this.currState._root : null;
      this.deactivateChildRoutes(n, r, t),
        bs(this.futureState.root),
        this.activateChildRoutes(n, r, t);
    }
    deactivateChildRoutes(t, n, r) {
      let o = qt(n);
      t.children.forEach((i) => {
        let s = i.value.outlet;
        this.deactivateRoutes(i, o[s], r), delete o[s];
      }),
        Object.values(o).forEach((i) => {
          this.deactivateRouteAndItsChildren(i, r);
        });
    }
    deactivateRoutes(t, n, r) {
      let o = t.value,
        i = n ? n.value : null;
      if (o === i)
        if (o.component) {
          let s = r.getContext(o.outlet);
          s && this.deactivateChildRoutes(t, n, s.children);
        } else this.deactivateChildRoutes(t, n, r);
      else i && this.deactivateRouteAndItsChildren(n, r);
    }
    deactivateRouteAndItsChildren(t, n) {
      t.value.component &&
      this.routeReuseStrategy.shouldDetach(t.value.snapshot)
        ? this.detachAndStoreRouteSubtree(t, n)
        : this.deactivateRouteAndOutlet(t, n);
    }
    detachAndStoreRouteSubtree(t, n) {
      let r = n.getContext(t.value.outlet),
        o = r && t.value.component ? r.children : n,
        i = qt(t);
      for (let s of Object.values(i)) this.deactivateRouteAndItsChildren(s, o);
      if (r && r.outlet) {
        let s = r.outlet.detach(),
          a = r.children.onOutletDeactivated();
        this.routeReuseStrategy.store(t.value.snapshot, {
          componentRef: s,
          route: t,
          contexts: a,
        });
      }
    }
    deactivateRouteAndOutlet(t, n) {
      let r = n.getContext(t.value.outlet),
        o = r && t.value.component ? r.children : n,
        i = qt(t);
      for (let s of Object.values(i)) this.deactivateRouteAndItsChildren(s, o);
      r &&
        (r.outlet && (r.outlet.deactivate(), r.children.onOutletDeactivated()),
        (r.attachRef = null),
        (r.route = null));
    }
    activateChildRoutes(t, n, r) {
      let o = qt(n);
      t.children.forEach((i) => {
        this.activateRoutes(i, o[i.value.outlet], r),
          this.forwardEvent(new Bs(i.value.snapshot));
      }),
        t.children.length && this.forwardEvent(new Vs(t.value.snapshot));
    }
    activateRoutes(t, n, r) {
      let o = t.value,
        i = n ? n.value : null;
      if ((bs(o), o === i))
        if (o.component) {
          let s = r.getOrCreateContext(o.outlet);
          this.activateChildRoutes(t, n, s.children);
        } else this.activateChildRoutes(t, n, r);
      else if (o.component) {
        let s = r.getOrCreateContext(o.outlet);
        if (this.routeReuseStrategy.shouldAttach(o.snapshot)) {
          let a = this.routeReuseStrategy.retrieve(o.snapshot);
          this.routeReuseStrategy.store(o.snapshot, null),
            s.children.onOutletReAttached(a.contexts),
            (s.attachRef = a.componentRef),
            (s.route = a.route.value),
            s.outlet && s.outlet.attach(a.componentRef, a.route.value),
            bs(a.route.value),
            this.activateChildRoutes(t, null, s.children);
        } else
          (s.attachRef = null),
            (s.route = o),
            s.outlet && s.outlet.activateWith(o, s.injector),
            this.activateChildRoutes(t, null, s.children);
      } else this.activateChildRoutes(t, null, r);
    }
  },
  vo = class {
    constructor(t) {
      (this.path = t), (this.route = this.path[this.path.length - 1]);
    }
  },
  Yt = class {
    constructor(t, n) {
      (this.component = t), (this.route = n);
    }
  };
function bv(e, t, n) {
  let r = e._root,
    o = t ? t._root : null;
  return _n(r, o, n, [r.value]);
}
function Mv(e) {
  let t = e.routeConfig ? e.routeConfig.canActivateChild : null;
  return !t || t.length === 0 ? null : { node: e, guards: t };
}
function en(e, t) {
  let n = Symbol(),
    r = t.get(e, n);
  return r === n ? (typeof e == "function" && !Sc(e) ? e : t.get(e)) : r;
}
function _n(
  e,
  t,
  n,
  r,
  o = { canDeactivateChecks: [], canActivateChecks: [] }
) {
  let i = qt(t);
  return (
    e.children.forEach((s) => {
      Sv(s, i[s.value.outlet], n, r.concat([s.value]), o),
        delete i[s.value.outlet];
    }),
    Object.entries(i).forEach(([s, a]) => On(a, n.getContext(s), o)),
    o
  );
}
function Sv(
  e,
  t,
  n,
  r,
  o = { canDeactivateChecks: [], canActivateChecks: [] }
) {
  let i = e.value,
    s = t ? t.value : null,
    a = n ? n.getContext(e.value.outlet) : null;
  if (s && i.routeConfig === s.routeConfig) {
    let c = xv(s, i, i.routeConfig.runGuardsAndResolvers);
    c
      ? o.canActivateChecks.push(new vo(r))
      : ((i.data = s.data), (i._resolvedData = s._resolvedData)),
      i.component ? _n(e, t, a ? a.children : null, r, o) : _n(e, t, n, r, o),
      c &&
        a &&
        a.outlet &&
        a.outlet.isActivated &&
        o.canDeactivateChecks.push(new Yt(a.outlet.component, s));
  } else
    s && On(t, a, o),
      o.canActivateChecks.push(new vo(r)),
      i.component
        ? _n(e, null, a ? a.children : null, r, o)
        : _n(e, null, n, r, o);
  return o;
}
function xv(e, t, n) {
  if (typeof n == "function") return n(e, t);
  switch (n) {
    case "pathParamsChange":
      return !ht(e.url, t.url);
    case "pathParamsOrQueryParamsChange":
      return !ht(e.url, t.url) || !xe(e.queryParams, t.queryParams);
    case "always":
      return !0;
    case "paramsOrQueryParamsChange":
      return !Gs(e, t) || !xe(e.queryParams, t.queryParams);
    case "paramsChange":
    default:
      return !Gs(e, t);
  }
}
function On(e, t, n) {
  let r = qt(e),
    o = e.value;
  Object.entries(r).forEach(([i, s]) => {
    o.component
      ? t
        ? On(s, t.children.getContext(i), n)
        : On(s, null, n)
      : On(s, t, n);
  }),
    o.component
      ? t && t.outlet && t.outlet.isActivated
        ? n.canDeactivateChecks.push(new Yt(t.outlet.component, o))
        : n.canDeactivateChecks.push(new Yt(null, o))
      : n.canDeactivateChecks.push(new Yt(null, o));
}
function qn(e) {
  return typeof e == "function";
}
function Tv(e) {
  return typeof e == "boolean";
}
function _v(e) {
  return e && qn(e.canLoad);
}
function Nv(e) {
  return e && qn(e.canActivate);
}
function Av(e) {
  return e && qn(e.canActivateChild);
}
function Rv(e) {
  return e && qn(e.canDeactivate);
}
function Ov(e) {
  return e && qn(e.canMatch);
}
function bd(e) {
  return e instanceof Te || e?.name === "EmptyError";
}
var oo = Symbol("INITIAL_VALUE");
function Jt() {
  return me((e) =>
    dr(e.map((t) => t.pipe(_e(1), zo(oo)))).pipe(
      x((t) => {
        for (let n of t)
          if (n !== !0) {
            if (n === oo) return oo;
            if (n === !1 || Pv(n)) return n;
          }
        return !0;
      }),
      ge((t) => t !== oo),
      _e(1)
    )
  );
}
function Pv(e) {
  return kn(e) || e instanceof Bn;
}
function kv(e, t) {
  return G((n) => {
    let {
      targetSnapshot: r,
      currentSnapshot: o,
      guards: { canActivateChecks: i, canDeactivateChecks: s },
    } = n;
    return s.length === 0 && i.length === 0
      ? w(j(g({}, n), { guardsResult: !0 }))
      : Fv(s, r, o, e).pipe(
          G((a) => (a && Tv(a) ? Lv(r, i, e, t) : w(a))),
          x((a) => j(g({}, n), { guardsResult: a }))
        );
  });
}
function Fv(e, t, n, r) {
  return z(e).pipe(
    G((o) => Uv(o.component, o.route, n, t, r)),
    Ee((o) => o !== !0, !0)
  );
}
function Lv(e, t, n, r) {
  return z(t).pipe(
    St((o) =>
      Mt(
        Vv(o.route.parent, r),
        jv(o.route, r),
        Bv(e, o.path, n),
        $v(e, o.route, n)
      )
    ),
    Ee((o) => o !== !0, !0)
  );
}
function jv(e, t) {
  return e !== null && t && t(new $s(e)), w(!0);
}
function Vv(e, t) {
  return e !== null && t && t(new js(e)), w(!0);
}
function $v(e, t, n) {
  let r = t.routeConfig ? t.routeConfig.canActivate : null;
  if (!r || r.length === 0) return w(!0);
  let o = r.map((i) =>
    fr(() => {
      let s = Gn(t) ?? n,
        a = en(i, s),
        c = Nv(a) ? a.canActivate(t, e) : Re(s, () => a(t, e));
      return Qe(c).pipe(Ee());
    })
  );
  return w(o).pipe(Jt());
}
function Bv(e, t, n) {
  let r = t[t.length - 1],
    i = t
      .slice(0, t.length - 1)
      .reverse()
      .map((s) => Mv(s))
      .filter((s) => s !== null)
      .map((s) =>
        fr(() => {
          let a = s.guards.map((c) => {
            let u = Gn(s.node) ?? n,
              l = en(c, u),
              d = Av(l) ? l.canActivateChild(r, e) : Re(u, () => l(r, e));
            return Qe(d).pipe(Ee());
          });
          return w(a).pipe(Jt());
        })
      );
  return w(i).pipe(Jt());
}
function Uv(e, t, n, r, o) {
  let i = t && t.routeConfig ? t.routeConfig.canDeactivate : null;
  if (!i || i.length === 0) return w(!0);
  let s = i.map((a) => {
    let c = Gn(t) ?? o,
      u = en(a, c),
      l = Rv(u) ? u.canDeactivate(e, t, n, r) : Re(c, () => u(e, t, n, r));
    return Qe(l).pipe(Ee());
  });
  return w(s).pipe(Jt());
}
function Hv(e, t, n, r) {
  let o = t.canLoad;
  if (o === void 0 || o.length === 0) return w(!0);
  let i = o.map((s) => {
    let a = en(s, e),
      c = _v(a) ? a.canLoad(t, n) : Re(e, () => a(t, n));
    return Qe(c);
  });
  return w(i).pipe(Jt(), Md(r));
}
function Md(e) {
  return ko(
    Z((t) => {
      if (typeof t != "boolean") throw mo(e, t);
    }),
    x((t) => t === !0)
  );
}
function zv(e, t, n, r) {
  let o = t.canMatch;
  if (!o || o.length === 0) return w(!0);
  let i = o.map((s) => {
    let a = en(s, e),
      c = Ov(a) ? a.canMatch(t, n) : Re(e, () => a(t, n));
    return Qe(c);
  });
  return w(i).pipe(Jt(), Md(r));
}
var Un = class {
    constructor(t) {
      this.segmentGroup = t || null;
    }
  },
  Hn = class extends Error {
    constructor(t) {
      super(), (this.urlTree = t);
    }
  };
function Gt(e) {
  return bt(new Un(e));
}
function Gv(e) {
  return bt(new v(4e3, !1));
}
function qv(e) {
  return bt(Ed(!1, se.GuardRejected));
}
var Zs = class {
    constructor(t, n) {
      (this.urlSerializer = t), (this.urlTree = n);
    }
    lineralizeSegments(t, n) {
      let r = [],
        o = n.root;
      for (;;) {
        if (((r = r.concat(o.segments)), o.numberOfChildren === 0)) return w(r);
        if (o.numberOfChildren > 1 || !o.children[E])
          return Gv(`${t.redirectTo}`);
        o = o.children[E];
      }
    }
    applyRedirectCommands(t, n, r, o, i) {
      if (typeof n != "string") {
        let a = n,
          {
            queryParams: c,
            fragment: u,
            routeConfig: l,
            url: d,
            outlet: h,
            params: f,
            data: m,
            title: S,
          } = o,
          L = Re(i, () =>
            a({
              params: f,
              data: m,
              queryParams: c,
              fragment: u,
              routeConfig: l,
              url: d,
              outlet: h,
              title: S,
            })
          );
        if (L instanceof je) throw new Hn(L);
        n = L;
      }
      let s = this.applyRedirectCreateUrlTree(
        n,
        this.urlSerializer.parse(n),
        t,
        r
      );
      if (n[0] === "/") throw new Hn(s);
      return s;
    }
    applyRedirectCreateUrlTree(t, n, r, o) {
      let i = this.createSegmentGroup(t, n.root, r, o);
      return new je(
        i,
        this.createQueryParams(n.queryParams, this.urlTree.queryParams),
        n.fragment
      );
    }
    createQueryParams(t, n) {
      let r = {};
      return (
        Object.entries(t).forEach(([o, i]) => {
          if (typeof i == "string" && i[0] === ":") {
            let a = i.substring(1);
            r[o] = n[a];
          } else r[o] = i;
        }),
        r
      );
    }
    createSegmentGroup(t, n, r, o) {
      let i = this.createSegments(t, n.segments, r, o),
        s = {};
      return (
        Object.entries(n.children).forEach(([a, c]) => {
          s[a] = this.createSegmentGroup(t, c, r, o);
        }),
        new A(i, s)
      );
    }
    createSegments(t, n, r, o) {
      return n.map((i) =>
        i.path[0] === ":" ? this.findPosParam(t, i, o) : this.findOrReturn(i, r)
      );
    }
    findPosParam(t, n, r) {
      let o = r[n.path.substring(1)];
      if (!o) throw new v(4001, !1);
      return o;
    }
    findOrReturn(t, n) {
      let r = 0;
      for (let o of n) {
        if (o.path === t.path) return n.splice(r), o;
        r++;
      }
      return t;
    }
  },
  Ys = {
    matched: !1,
    consumedSegments: [],
    remainingSegments: [],
    parameters: {},
    positionalParamSegments: {},
  };
function Wv(e, t, n, r, o) {
  let i = ra(e, t, n);
  return i.matched
    ? ((r = mv(t, r)),
      zv(r, t, n, o).pipe(x((s) => (s === !0 ? i : g({}, Ys)))))
    : w(i);
}
function ra(e, t, n) {
  if (t.path === "**") return Zv(n);
  if (t.path === "")
    return t.pathMatch === "full" && (e.hasChildren() || n.length > 0)
      ? g({}, Ys)
      : {
          matched: !0,
          consumedSegments: [],
          remainingSegments: n,
          parameters: {},
          positionalParamSegments: {},
        };
  let o = (t.matcher || zm)(n, e, t);
  if (!o) return g({}, Ys);
  let i = {};
  Object.entries(o.posParams ?? {}).forEach(([a, c]) => {
    i[a] = c.path;
  });
  let s =
    o.consumed.length > 0
      ? g(g({}, i), o.consumed[o.consumed.length - 1].parameters)
      : i;
  return {
    matched: !0,
    consumedSegments: o.consumed,
    remainingSegments: n.slice(o.consumed.length),
    parameters: s,
    positionalParamSegments: o.posParams ?? {},
  };
}
function Zv(e) {
  return {
    matched: !0,
    parameters: e.length > 0 ? id(e).parameters : {},
    consumedSegments: e,
    remainingSegments: [],
    positionalParamSegments: {},
  };
}
function td(e, t, n, r) {
  return n.length > 0 && Kv(e, n, r)
    ? {
        segmentGroup: new A(t, Qv(r, new A(n, e.children))),
        slicedSegments: [],
      }
    : n.length === 0 && Xv(e, n, r)
    ? {
        segmentGroup: new A(e.segments, Yv(e, n, r, e.children)),
        slicedSegments: n,
      }
    : { segmentGroup: new A(e.segments, e.children), slicedSegments: n };
}
function Yv(e, t, n, r) {
  let o = {};
  for (let i of n)
    if (Do(e, t, i) && !r[Ce(i)]) {
      let s = new A([], {});
      o[Ce(i)] = s;
    }
  return g(g({}, r), o);
}
function Qv(e, t) {
  let n = {};
  n[E] = t;
  for (let r of e)
    if (r.path === "" && Ce(r) !== E) {
      let o = new A([], {});
      n[Ce(r)] = o;
    }
  return n;
}
function Kv(e, t, n) {
  return n.some((r) => Do(e, t, r) && Ce(r) !== E);
}
function Xv(e, t, n) {
  return n.some((r) => Do(e, t, r));
}
function Do(e, t, n) {
  return (e.hasChildren() || t.length > 0) && n.pathMatch === "full"
    ? !1
    : n.path === "";
}
function Jv(e, t, n, r) {
  return Ce(e) !== r && (r === E || !Do(t, n, e)) ? !1 : ra(t, e, n).matched;
}
function ey(e, t, n) {
  return t.length === 0 && !e.children[n];
}
var Qs = class {};
function ty(e, t, n, r, o, i, s = "emptyOnly") {
  return new Ks(e, t, n, r, o, s, i).recognize();
}
var ny = 31,
  Ks = class {
    constructor(t, n, r, o, i, s, a) {
      (this.injector = t),
        (this.configLoader = n),
        (this.rootComponentType = r),
        (this.config = o),
        (this.urlTree = i),
        (this.paramsInheritanceStrategy = s),
        (this.urlSerializer = a),
        (this.applyRedirects = new Zs(this.urlSerializer, this.urlTree)),
        (this.absoluteRedirectCount = 0),
        (this.allowRedirects = !0);
    }
    noMatchError(t) {
      return new v(4002, `'${t.segmentGroup}'`);
    }
    recognize() {
      let t = td(this.urlTree.root, [], [], this.config).segmentGroup;
      return this.match(t).pipe(
        x(({ children: n, rootSnapshot: r }) => {
          let o = new ie(r, n),
            i = new go("", o),
            s = uv(r, [], this.urlTree.queryParams, this.urlTree.fragment);
          return (
            (s.queryParams = this.urlTree.queryParams),
            (i.url = this.urlSerializer.serialize(s)),
            { state: i, tree: s }
          );
        })
      );
    }
    match(t) {
      let n = new Zt(
        [],
        Object.freeze({}),
        Object.freeze(g({}, this.urlTree.queryParams)),
        this.urlTree.fragment,
        Object.freeze({}),
        E,
        this.rootComponentType,
        null,
        {}
      );
      return this.processSegmentGroup(this.injector, this.config, t, E, n).pipe(
        x((r) => ({ children: r, rootSnapshot: n })),
        Be((r) => {
          if (r instanceof Hn)
            return (this.urlTree = r.urlTree), this.match(r.urlTree.root);
          throw r instanceof Un ? this.noMatchError(r) : r;
        })
      );
    }
    processSegmentGroup(t, n, r, o, i) {
      return r.segments.length === 0 && r.hasChildren()
        ? this.processChildren(t, n, r, i)
        : this.processSegment(t, n, r, r.segments, o, !0, i).pipe(
            x((s) => (s instanceof ie ? [s] : []))
          );
    }
    processChildren(t, n, r, o) {
      let i = [];
      for (let s of Object.keys(r.children))
        s === "primary" ? i.unshift(s) : i.push(s);
      return z(i).pipe(
        St((s) => {
          let a = r.children[s],
            c = vv(n, s);
          return this.processSegmentGroup(t, c, a, s, o);
        }),
        Ho((s, a) => (s.push(...a), s)),
        Ue(null),
        Uo(),
        G((s) => {
          if (s === null) return Gt(r);
          let a = Sd(s);
          return ry(a), w(a);
        })
      );
    }
    processSegment(t, n, r, o, i, s, a) {
      return z(n).pipe(
        St((c) =>
          this.processSegmentAgainstRoute(
            c._injector ?? t,
            n,
            c,
            r,
            o,
            i,
            s,
            a
          ).pipe(
            Be((u) => {
              if (u instanceof Un) return w(null);
              throw u;
            })
          )
        ),
        Ee((c) => !!c),
        Be((c) => {
          if (bd(c)) return ey(r, o, i) ? w(new Qs()) : Gt(r);
          throw c;
        })
      );
    }
    processSegmentAgainstRoute(t, n, r, o, i, s, a, c) {
      return Jv(r, o, i, s)
        ? r.redirectTo === void 0
          ? this.matchSegmentAgainstRoute(t, o, r, i, s, c)
          : this.allowRedirects && a
          ? this.expandSegmentAgainstRouteUsingRedirect(t, o, n, r, i, s, c)
          : Gt(o)
        : Gt(o);
    }
    expandSegmentAgainstRouteUsingRedirect(t, n, r, o, i, s, a) {
      let {
        matched: c,
        parameters: u,
        consumedSegments: l,
        positionalParamSegments: d,
        remainingSegments: h,
      } = ra(n, o, i);
      if (!c) return Gt(n);
      typeof o.redirectTo == "string" &&
        o.redirectTo[0] === "/" &&
        (this.absoluteRedirectCount++,
        this.absoluteRedirectCount > ny && (this.allowRedirects = !1));
      let f = new Zt(
          i,
          u,
          Object.freeze(g({}, this.urlTree.queryParams)),
          this.urlTree.fragment,
          nd(o),
          Ce(o),
          o.component ?? o._loadedComponent ?? null,
          o,
          rd(o)
        ),
        m = po(f, a, this.paramsInheritanceStrategy);
      (f.params = Object.freeze(m.params)), (f.data = Object.freeze(m.data));
      let S = this.applyRedirects.applyRedirectCommands(
        l,
        o.redirectTo,
        d,
        f,
        t
      );
      return this.applyRedirects
        .lineralizeSegments(o, S)
        .pipe(G((L) => this.processSegment(t, r, n, L.concat(h), s, !1, a)));
    }
    matchSegmentAgainstRoute(t, n, r, o, i, s) {
      let a = Wv(n, r, o, t, this.urlSerializer);
      return (
        r.path === "**" && (n.children = {}),
        a.pipe(
          me((c) =>
            c.matched
              ? ((t = r._injector ?? t),
                this.getChildConfig(t, r, o).pipe(
                  me(({ routes: u }) => {
                    let l = r._loadedInjector ?? t,
                      {
                        parameters: d,
                        consumedSegments: h,
                        remainingSegments: f,
                      } = c,
                      m = new Zt(
                        h,
                        d,
                        Object.freeze(g({}, this.urlTree.queryParams)),
                        this.urlTree.fragment,
                        nd(r),
                        Ce(r),
                        r.component ?? r._loadedComponent ?? null,
                        r,
                        rd(r)
                      ),
                      S = po(m, s, this.paramsInheritanceStrategy);
                    (m.params = Object.freeze(S.params)),
                      (m.data = Object.freeze(S.data));
                    let { segmentGroup: L, slicedSegments: H } = td(n, h, f, u);
                    if (H.length === 0 && L.hasChildren())
                      return this.processChildren(l, u, L, m).pipe(
                        x((ae) => new ie(m, ae))
                      );
                    if (u.length === 0 && H.length === 0)
                      return w(new ie(m, []));
                    let Ke = Ce(r) === i;
                    return this.processSegment(
                      l,
                      u,
                      L,
                      H,
                      Ke ? E : i,
                      !0,
                      m
                    ).pipe(x((ae) => new ie(m, ae instanceof ie ? [ae] : [])));
                  })
                ))
              : Gt(n)
          )
        )
      );
    }
    getChildConfig(t, n, r) {
      return n.children
        ? w({ routes: n.children, injector: t })
        : n.loadChildren
        ? n._loadedRoutes !== void 0
          ? w({ routes: n._loadedRoutes, injector: n._loadedInjector })
          : Hv(t, n, r, this.urlSerializer).pipe(
              G((o) =>
                o
                  ? this.configLoader.loadChildren(t, n).pipe(
                      Z((i) => {
                        (n._loadedRoutes = i.routes),
                          (n._loadedInjector = i.injector);
                      })
                    )
                  : qv(n)
              )
            )
        : w({ routes: [], injector: t });
    }
  };
function ry(e) {
  e.sort((t, n) =>
    t.value.outlet === E
      ? -1
      : n.value.outlet === E
      ? 1
      : t.value.outlet.localeCompare(n.value.outlet)
  );
}
function oy(e) {
  let t = e.value.routeConfig;
  return t && t.path === "";
}
function Sd(e) {
  let t = [],
    n = new Set();
  for (let r of e) {
    if (!oy(r)) {
      t.push(r);
      continue;
    }
    let o = t.find((i) => r.value.routeConfig === i.value.routeConfig);
    o !== void 0 ? (o.children.push(...r.children), n.add(o)) : t.push(r);
  }
  for (let r of n) {
    let o = Sd(r.children);
    t.push(new ie(r.value, o));
  }
  return t.filter((r) => !n.has(r));
}
function nd(e) {
  return e.data || {};
}
function rd(e) {
  return e.resolve || {};
}
function iy(e, t, n, r, o, i) {
  return G((s) =>
    ty(e, t, n, r, s.extractedUrl, o, i).pipe(
      x(({ state: a, tree: c }) =>
        j(g({}, s), { targetSnapshot: a, urlAfterRedirects: c })
      )
    )
  );
}
function sy(e, t) {
  return G((n) => {
    let {
      targetSnapshot: r,
      guards: { canActivateChecks: o },
    } = n;
    if (!o.length) return w(n);
    let i = new Set(o.map((c) => c.route)),
      s = new Set();
    for (let c of i) if (!s.has(c)) for (let u of xd(c)) s.add(u);
    let a = 0;
    return z(s).pipe(
      St((c) =>
        i.has(c)
          ? ay(c, r, e, t)
          : ((c.data = po(c, c.parent, e).resolve), w(void 0))
      ),
      Z(() => a++),
      xt(1),
      G((c) => (a === s.size ? w(n) : ne))
    );
  });
}
function xd(e) {
  let t = e.children.map((n) => xd(n)).flat();
  return [e, ...t];
}
function ay(e, t, n, r) {
  let o = e.routeConfig,
    i = e._resolve;
  return (
    o?.title !== void 0 && !wd(o) && (i[zn] = o.title),
    cy(i, e, t, r).pipe(
      x(
        (s) => (
          (e._resolvedData = s), (e.data = po(e, e.parent, n).resolve), null
        )
      )
    )
  );
}
function cy(e, t, n, r) {
  let o = xs(e);
  if (o.length === 0) return w({});
  let i = {};
  return z(o).pipe(
    G((s) =>
      uy(e[s], t, n, r).pipe(
        Ee(),
        Z((a) => {
          if (a instanceof Bn) throw mo(new Pn(), a);
          i[s] = a;
        })
      )
    ),
    xt(1),
    Bo(i),
    Be((s) => (bd(s) ? ne : bt(s)))
  );
}
function uy(e, t, n, r) {
  let o = Gn(t) ?? r,
    i = en(e, o),
    s = i.resolve ? i.resolve(t, n) : Re(o, () => i(t, n));
  return Qe(s);
}
function Ms(e) {
  return me((t) => {
    let n = e(t);
    return n ? z(n).pipe(x(() => t)) : w(t);
  });
}
var Td = (() => {
    let t = class t {
      buildTitle(r) {
        let o,
          i = r.root;
        for (; i !== void 0; )
          (o = this.getResolvedTitleForRoute(i) ?? o),
            (i = i.children.find((s) => s.outlet === E));
        return o;
      }
      getResolvedTitleForRoute(r) {
        return r.data[zn];
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: () => p(ly), providedIn: "root" }));
    let e = t;
    return e;
  })(),
  ly = (() => {
    let t = class t extends Td {
      constructor(r) {
        super(), (this.title = r);
      }
      updateTitle(r) {
        let o = this.buildTitle(r);
        o !== void 0 && this.title.setTitle(o);
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)(M(Ql));
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })(),
  oa = new I("", { providedIn: "root", factory: () => ({}) }),
  dy = (() => {
    let t = class t {};
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵcmp = jr({
        type: t,
        selectors: [["ng-component"]],
        standalone: !0,
        features: [Yr],
        decls: 1,
        vars: 0,
        template: function (o, i) {
          o & 1 && U(0, "router-outlet");
        },
        dependencies: [ta],
        encapsulation: 2,
      }));
    let e = t;
    return e;
  })();
function ia(e) {
  let t = e.children && e.children.map(ia),
    n = t ? j(g({}, e), { children: t }) : g({}, e);
  return (
    !n.component &&
      !n.loadComponent &&
      (t || n.loadChildren) &&
      n.outlet &&
      n.outlet !== E &&
      (n.component = dy),
    n
  );
}
var sa = new I(""),
  fy = (() => {
    let t = class t {
      constructor() {
        (this.componentLoaders = new WeakMap()),
          (this.childrenLoaders = new WeakMap()),
          (this.compiler = p(fs));
      }
      loadComponent(r) {
        if (this.componentLoaders.get(r)) return this.componentLoaders.get(r);
        if (r._loadedComponent) return w(r._loadedComponent);
        this.onLoadStartListener && this.onLoadStartListener(r);
        let o = Qe(r.loadComponent()).pipe(
            x(_d),
            Z((s) => {
              this.onLoadEndListener && this.onLoadEndListener(r),
                (r._loadedComponent = s);
            }),
            rn(() => {
              this.componentLoaders.delete(r);
            })
          ),
          i = new It(o, () => new Q()).pipe(Et());
        return this.componentLoaders.set(r, i), i;
      }
      loadChildren(r, o) {
        if (this.childrenLoaders.get(o)) return this.childrenLoaders.get(o);
        if (o._loadedRoutes)
          return w({ routes: o._loadedRoutes, injector: o._loadedInjector });
        this.onLoadStartListener && this.onLoadStartListener(o);
        let s = hy(o, this.compiler, r, this.onLoadEndListener).pipe(
            rn(() => {
              this.childrenLoaders.delete(o);
            })
          ),
          a = new It(s, () => new Q()).pipe(Et());
        return this.childrenLoaders.set(o, a), a;
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })();
function hy(e, t, n, r) {
  return Qe(e.loadChildren()).pipe(
    x(_d),
    G((o) =>
      o instanceof vn || Array.isArray(o) ? w(o) : z(t.compileModuleAsync(o))
    ),
    x((o) => {
      r && r(e);
      let i,
        s,
        a = !1;
      return (
        Array.isArray(o)
          ? ((s = o), (a = !0))
          : ((i = o.create(n).injector),
            (s = i.get(sa, [], { optional: !0, self: !0 }).flat())),
        { routes: s.map(ia), injector: i }
      );
    })
  );
}
function py(e) {
  return e && typeof e == "object" && "default" in e;
}
function _d(e) {
  return py(e) ? e.default : e;
}
var aa = (() => {
    let t = class t {};
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: () => p(gy), providedIn: "root" }));
    let e = t;
    return e;
  })(),
  gy = (() => {
    let t = class t {
      shouldProcessUrl(r) {
        return !0;
      }
      extract(r) {
        return r;
      }
      merge(r, o) {
        return r;
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })(),
  my = new I("");
var vy = new I(""),
  yy = (() => {
    let t = class t {
      get hasRequestedNavigation() {
        return this.navigationId !== 0;
      }
      constructor() {
        (this.currentNavigation = null),
          (this.currentTransition = null),
          (this.lastSuccessfulNavigation = null),
          (this.events = new Q()),
          (this.transitionAbortSubject = new Q()),
          (this.configLoader = p(fy)),
          (this.environmentInjector = p(fe)),
          (this.urlSerializer = p(Js)),
          (this.rootContexts = p(yo)),
          (this.location = p(In)),
          (this.inputBindingEnabled = p(na, { optional: !0 }) !== null),
          (this.titleStrategy = p(Td)),
          (this.options = p(oa, { optional: !0 }) || {}),
          (this.paramsInheritanceStrategy =
            this.options.paramsInheritanceStrategy || "emptyOnly"),
          (this.urlHandlingStrategy = p(aa)),
          (this.createViewTransition = p(my, { optional: !0 })),
          (this.navigationErrorHandler = p(vy, { optional: !0 })),
          (this.navigationId = 0),
          (this.afterPreactivation = () => w(void 0)),
          (this.rootComponentType = null);
        let r = (i) => this.events.next(new Fs(i)),
          o = (i) => this.events.next(new Ls(i));
        (this.configLoader.onLoadEndListener = o),
          (this.configLoader.onLoadStartListener = r);
      }
      complete() {
        this.transitions?.complete();
      }
      handleNavigationRequest(r) {
        let o = ++this.navigationId;
        this.transitions?.next(
          j(g(g({}, this.transitions.value), r), { id: o })
        );
      }
      setupNavigations(r, o, i) {
        return (
          (this.transitions = new W({
            id: 0,
            currentUrlTree: o,
            currentRawUrl: o,
            extractedUrl: this.urlHandlingStrategy.extract(o),
            urlAfterRedirects: this.urlHandlingStrategy.extract(o),
            rawUrl: o,
            extras: {},
            resolve: () => {},
            reject: () => {},
            promise: Promise.resolve(!0),
            source: Rn,
            restoredState: null,
            currentSnapshot: i.snapshot,
            targetSnapshot: null,
            currentRouterState: i,
            targetRouterState: null,
            guards: { canActivateChecks: [], canDeactivateChecks: [] },
            guardsResult: null,
          })),
          this.transitions.pipe(
            ge((s) => s.id !== 0),
            x((s) =>
              j(g({}, s), {
                extractedUrl: this.urlHandlingStrategy.extract(s.rawUrl),
              })
            ),
            me((s) => {
              let a = !1,
                c = !1;
              return w(s).pipe(
                me((u) => {
                  if (this.navigationId > s.id)
                    return (
                      this.cancelNavigationTransition(
                        s,
                        "",
                        se.SupersededByNewNavigation
                      ),
                      ne
                    );
                  (this.currentTransition = s),
                    (this.currentNavigation = {
                      id: u.id,
                      initialUrl: u.rawUrl,
                      extractedUrl: u.extractedUrl,
                      targetBrowserUrl:
                        typeof u.extras.browserUrl == "string"
                          ? this.urlSerializer.parse(u.extras.browserUrl)
                          : u.extras.browserUrl,
                      trigger: u.source,
                      extras: u.extras,
                      previousNavigation: this.lastSuccessfulNavigation
                        ? j(g({}, this.lastSuccessfulNavigation), {
                            previousNavigation: null,
                          })
                        : null,
                    });
                  let l =
                      !r.navigated ||
                      this.isUpdatingInternalState() ||
                      this.isUpdatedBrowserUrl(),
                    d = u.extras.onSameUrlNavigation ?? r.onSameUrlNavigation;
                  if (!l && d !== "reload") {
                    let h = "";
                    return (
                      this.events.next(
                        new gt(
                          u.id,
                          this.urlSerializer.serialize(u.rawUrl),
                          h,
                          As.IgnoredSameUrlNavigation
                        )
                      ),
                      u.resolve(!1),
                      ne
                    );
                  }
                  if (this.urlHandlingStrategy.shouldProcessUrl(u.rawUrl))
                    return w(u).pipe(
                      me((h) => {
                        let f = this.transitions?.getValue();
                        return (
                          this.events.next(
                            new Ln(
                              h.id,
                              this.urlSerializer.serialize(h.extractedUrl),
                              h.source,
                              h.restoredState
                            )
                          ),
                          f !== this.transitions?.getValue()
                            ? ne
                            : Promise.resolve(h)
                        );
                      }),
                      iy(
                        this.environmentInjector,
                        this.configLoader,
                        this.rootComponentType,
                        r.config,
                        this.urlSerializer,
                        this.paramsInheritanceStrategy
                      ),
                      Z((h) => {
                        (s.targetSnapshot = h.targetSnapshot),
                          (s.urlAfterRedirects = h.urlAfterRedirects),
                          (this.currentNavigation = j(
                            g({}, this.currentNavigation),
                            { finalUrl: h.urlAfterRedirects }
                          ));
                        let f = new lo(
                          h.id,
                          this.urlSerializer.serialize(h.extractedUrl),
                          this.urlSerializer.serialize(h.urlAfterRedirects),
                          h.targetSnapshot
                        );
                        this.events.next(f);
                      })
                    );
                  if (
                    l &&
                    this.urlHandlingStrategy.shouldProcessUrl(u.currentRawUrl)
                  ) {
                    let {
                        id: h,
                        extractedUrl: f,
                        source: m,
                        restoredState: S,
                        extras: L,
                      } = u,
                      H = new Ln(h, this.urlSerializer.serialize(f), m, S);
                    this.events.next(H);
                    let Ke = yd(this.rootComponentType).snapshot;
                    return (
                      (this.currentTransition = s =
                        j(g({}, u), {
                          targetSnapshot: Ke,
                          urlAfterRedirects: f,
                          extras: j(g({}, L), {
                            skipLocationChange: !1,
                            replaceUrl: !1,
                          }),
                        })),
                      (this.currentNavigation.finalUrl = f),
                      w(s)
                    );
                  } else {
                    let h = "";
                    return (
                      this.events.next(
                        new gt(
                          u.id,
                          this.urlSerializer.serialize(u.extractedUrl),
                          h,
                          As.IgnoredByUrlHandlingStrategy
                        )
                      ),
                      u.resolve(!1),
                      ne
                    );
                  }
                }),
                Z((u) => {
                  let l = new Rs(
                    u.id,
                    this.urlSerializer.serialize(u.extractedUrl),
                    this.urlSerializer.serialize(u.urlAfterRedirects),
                    u.targetSnapshot
                  );
                  this.events.next(l);
                }),
                x(
                  (u) => (
                    (this.currentTransition = s =
                      j(g({}, u), {
                        guards: bv(
                          u.targetSnapshot,
                          u.currentSnapshot,
                          this.rootContexts
                        ),
                      })),
                    s
                  )
                ),
                kv(this.environmentInjector, (u) => this.events.next(u)),
                Z((u) => {
                  if (
                    ((s.guardsResult = u.guardsResult),
                    u.guardsResult && typeof u.guardsResult != "boolean")
                  )
                    throw mo(this.urlSerializer, u.guardsResult);
                  let l = new Os(
                    u.id,
                    this.urlSerializer.serialize(u.extractedUrl),
                    this.urlSerializer.serialize(u.urlAfterRedirects),
                    u.targetSnapshot,
                    !!u.guardsResult
                  );
                  this.events.next(l);
                }),
                ge((u) =>
                  u.guardsResult
                    ? !0
                    : (this.cancelNavigationTransition(u, "", se.GuardRejected),
                      !1)
                ),
                Ms((u) => {
                  if (u.guards.canActivateChecks.length)
                    return w(u).pipe(
                      Z((l) => {
                        let d = new Ps(
                          l.id,
                          this.urlSerializer.serialize(l.extractedUrl),
                          this.urlSerializer.serialize(l.urlAfterRedirects),
                          l.targetSnapshot
                        );
                        this.events.next(d);
                      }),
                      me((l) => {
                        let d = !1;
                        return w(l).pipe(
                          sy(
                            this.paramsInheritanceStrategy,
                            this.environmentInjector
                          ),
                          Z({
                            next: () => (d = !0),
                            complete: () => {
                              d ||
                                this.cancelNavigationTransition(
                                  l,
                                  "",
                                  se.NoDataFromResolver
                                );
                            },
                          })
                        );
                      }),
                      Z((l) => {
                        let d = new ks(
                          l.id,
                          this.urlSerializer.serialize(l.extractedUrl),
                          this.urlSerializer.serialize(l.urlAfterRedirects),
                          l.targetSnapshot
                        );
                        this.events.next(d);
                      })
                    );
                }),
                Ms((u) => {
                  let l = (d) => {
                    let h = [];
                    d.routeConfig?.loadComponent &&
                      !d.routeConfig._loadedComponent &&
                      h.push(
                        this.configLoader.loadComponent(d.routeConfig).pipe(
                          Z((f) => {
                            d.component = f;
                          }),
                          x(() => {})
                        )
                      );
                    for (let f of d.children) h.push(...l(f));
                    return h;
                  };
                  return dr(l(u.targetSnapshot.root)).pipe(Ue(null), _e(1));
                }),
                Ms(() => this.afterPreactivation()),
                me(() => {
                  let { currentSnapshot: u, targetSnapshot: l } = s,
                    d = this.createViewTransition?.(
                      this.environmentInjector,
                      u.root,
                      l.root
                    );
                  return d ? z(d).pipe(x(() => s)) : w(s);
                }),
                x((u) => {
                  let l = Dv(
                    r.routeReuseStrategy,
                    u.targetSnapshot,
                    u.currentRouterState
                  );
                  return (
                    (this.currentTransition = s =
                      j(g({}, u), { targetRouterState: l })),
                    (this.currentNavigation.targetRouterState = l),
                    s
                  );
                }),
                Z(() => {
                  this.events.next(new Vn());
                }),
                Iv(
                  this.rootContexts,
                  r.routeReuseStrategy,
                  (u) => this.events.next(u),
                  this.inputBindingEnabled
                ),
                _e(1),
                Z({
                  next: (u) => {
                    (a = !0),
                      (this.lastSuccessfulNavigation = this.currentNavigation),
                      this.events.next(
                        new pt(
                          u.id,
                          this.urlSerializer.serialize(u.extractedUrl),
                          this.urlSerializer.serialize(u.urlAfterRedirects)
                        )
                      ),
                      this.titleStrategy?.updateTitle(
                        u.targetRouterState.snapshot
                      ),
                      u.resolve(!0);
                  },
                  complete: () => {
                    a = !0;
                  },
                }),
                Go(
                  this.transitionAbortSubject.pipe(
                    Z((u) => {
                      throw u;
                    })
                  )
                ),
                rn(() => {
                  !a &&
                    !c &&
                    this.cancelNavigationTransition(
                      s,
                      "",
                      se.SupersededByNewNavigation
                    ),
                    this.currentTransition?.id === s.id &&
                      ((this.currentNavigation = null),
                      (this.currentTransition = null));
                }),
                Be((u) => {
                  if (((c = !0), Id(u)))
                    this.events.next(
                      new Le(
                        s.id,
                        this.urlSerializer.serialize(s.extractedUrl),
                        u.message,
                        u.cancellationCode
                      )
                    ),
                      Ev(u)
                        ? this.events.next(
                            new Kt(u.url, u.navigationBehaviorOptions)
                          )
                        : s.resolve(!1);
                  else {
                    let l = new jn(
                      s.id,
                      this.urlSerializer.serialize(s.extractedUrl),
                      u,
                      s.targetSnapshot ?? void 0
                    );
                    try {
                      let d = Re(this.environmentInjector, () =>
                        this.navigationErrorHandler?.(l)
                      );
                      if (d instanceof Bn) {
                        let { message: h, cancellationCode: f } = mo(
                          this.urlSerializer,
                          d
                        );
                        this.events.next(
                          new Le(
                            s.id,
                            this.urlSerializer.serialize(s.extractedUrl),
                            h,
                            f
                          )
                        ),
                          this.events.next(
                            new Kt(d.redirectTo, d.navigationBehaviorOptions)
                          );
                      } else {
                        this.events.next(l);
                        let h = r.errorHandler(u);
                        s.resolve(!!h);
                      }
                    } catch (d) {
                      this.options.resolveNavigationPromiseOnError
                        ? s.resolve(!1)
                        : s.reject(d);
                    }
                  }
                  return ne;
                })
              );
            })
          )
        );
      }
      cancelNavigationTransition(r, o, i) {
        let s = new Le(
          r.id,
          this.urlSerializer.serialize(r.extractedUrl),
          o,
          i
        );
        this.events.next(s), r.resolve(!1);
      }
      isUpdatingInternalState() {
        return (
          this.currentTransition?.extractedUrl.toString() !==
          this.currentTransition?.currentUrlTree.toString()
        );
      }
      isUpdatedBrowserUrl() {
        let r = this.urlHandlingStrategy.extract(
            this.urlSerializer.parse(this.location.path(!0))
          ),
          o =
            this.currentNavigation?.targetBrowserUrl ??
            this.currentNavigation?.extractedUrl;
        return (
          r.toString() !== o?.toString() &&
          !this.currentNavigation?.extras.skipLocationChange
        );
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })();
function Dy(e) {
  return e !== Rn;
}
var wy = (() => {
    let t = class t {};
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: () => p(Cy), providedIn: "root" }));
    let e = t;
    return e;
  })(),
  Xs = class {
    shouldDetach(t) {
      return !1;
    }
    store(t, n) {}
    shouldAttach(t) {
      return !1;
    }
    retrieve(t) {
      return null;
    }
    shouldReuseRoute(t, n) {
      return t.routeConfig === n.routeConfig;
    }
  },
  Cy = (() => {
    let t = class t extends Xs {};
    (t.ɵfac = (() => {
      let r;
      return function (i) {
        return (r || (r = Wi(t)))(i || t);
      };
    })()),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })(),
  Nd = (() => {
    let t = class t {};
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: () => p(Ey), providedIn: "root" }));
    let e = t;
    return e;
  })(),
  Ey = (() => {
    let t = class t extends Nd {
      constructor() {
        super(...arguments),
          (this.location = p(In)),
          (this.urlSerializer = p(Js)),
          (this.options = p(oa, { optional: !0 }) || {}),
          (this.canceledNavigationResolution =
            this.options.canceledNavigationResolution || "replace"),
          (this.urlHandlingStrategy = p(aa)),
          (this.urlUpdateStrategy =
            this.options.urlUpdateStrategy || "deferred"),
          (this.currentUrlTree = new je()),
          (this.rawUrlTree = this.currentUrlTree),
          (this.currentPageId = 0),
          (this.lastSuccessfulId = -1),
          (this.routerState = yd(null)),
          (this.stateMemento = this.createStateMemento());
      }
      getCurrentUrlTree() {
        return this.currentUrlTree;
      }
      getRawUrlTree() {
        return this.rawUrlTree;
      }
      restoredState() {
        return this.location.getState();
      }
      get browserPageId() {
        return this.canceledNavigationResolution !== "computed"
          ? this.currentPageId
          : this.restoredState()?.ɵrouterPageId ?? this.currentPageId;
      }
      getRouterState() {
        return this.routerState;
      }
      createStateMemento() {
        return {
          rawUrlTree: this.rawUrlTree,
          currentUrlTree: this.currentUrlTree,
          routerState: this.routerState,
        };
      }
      registerNonRouterCurrentEntryChangeListener(r) {
        return this.location.subscribe((o) => {
          o.type === "popstate" && r(o.url, o.state);
        });
      }
      handleRouterEvent(r, o) {
        if (r instanceof Ln) this.stateMemento = this.createStateMemento();
        else if (r instanceof gt) this.rawUrlTree = o.initialUrl;
        else if (r instanceof lo) {
          if (
            this.urlUpdateStrategy === "eager" &&
            !o.extras.skipLocationChange
          ) {
            let i = this.urlHandlingStrategy.merge(o.finalUrl, o.initialUrl);
            this.setBrowserUrl(o.targetBrowserUrl ?? i, o);
          }
        } else
          r instanceof Vn
            ? ((this.currentUrlTree = o.finalUrl),
              (this.rawUrlTree = this.urlHandlingStrategy.merge(
                o.finalUrl,
                o.initialUrl
              )),
              (this.routerState = o.targetRouterState),
              this.urlUpdateStrategy === "deferred" &&
                !o.extras.skipLocationChange &&
                this.setBrowserUrl(o.targetBrowserUrl ?? this.rawUrlTree, o))
            : r instanceof Le &&
              (r.code === se.GuardRejected || r.code === se.NoDataFromResolver)
            ? this.restoreHistory(o)
            : r instanceof jn
            ? this.restoreHistory(o, !0)
            : r instanceof pt &&
              ((this.lastSuccessfulId = r.id),
              (this.currentPageId = this.browserPageId));
      }
      setBrowserUrl(r, o) {
        let i = r instanceof je ? this.urlSerializer.serialize(r) : r;
        if (this.location.isCurrentPathEqualTo(i) || o.extras.replaceUrl) {
          let s = this.browserPageId,
            a = g(g({}, o.extras.state), this.generateNgRouterState(o.id, s));
          this.location.replaceState(i, "", a);
        } else {
          let s = g(
            g({}, o.extras.state),
            this.generateNgRouterState(o.id, this.browserPageId + 1)
          );
          this.location.go(i, "", s);
        }
      }
      restoreHistory(r, o = !1) {
        if (this.canceledNavigationResolution === "computed") {
          let i = this.browserPageId,
            s = this.currentPageId - i;
          s !== 0
            ? this.location.historyGo(s)
            : this.currentUrlTree === r.finalUrl &&
              s === 0 &&
              (this.resetState(r), this.resetUrlToCurrentUrlTree());
        } else
          this.canceledNavigationResolution === "replace" &&
            (o && this.resetState(r), this.resetUrlToCurrentUrlTree());
      }
      resetState(r) {
        (this.routerState = this.stateMemento.routerState),
          (this.currentUrlTree = this.stateMemento.currentUrlTree),
          (this.rawUrlTree = this.urlHandlingStrategy.merge(
            this.currentUrlTree,
            r.finalUrl ?? this.rawUrlTree
          ));
      }
      resetUrlToCurrentUrlTree() {
        this.location.replaceState(
          this.urlSerializer.serialize(this.rawUrlTree),
          "",
          this.generateNgRouterState(this.lastSuccessfulId, this.currentPageId)
        );
      }
      generateNgRouterState(r, o) {
        return this.canceledNavigationResolution === "computed"
          ? { navigationId: r, ɵrouterPageId: o }
          : { navigationId: r };
      }
    };
    (t.ɵfac = (() => {
      let r;
      return function (i) {
        return (r || (r = Wi(t)))(i || t);
      };
    })()),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })(),
  Nn = (function (e) {
    return (
      (e[(e.COMPLETE = 0)] = "COMPLETE"),
      (e[(e.FAILED = 1)] = "FAILED"),
      (e[(e.REDIRECTING = 2)] = "REDIRECTING"),
      e
    );
  })(Nn || {});
function Iy(e, t) {
  e.events
    .pipe(
      ge(
        (n) =>
          n instanceof pt ||
          n instanceof Le ||
          n instanceof jn ||
          n instanceof gt
      ),
      x((n) =>
        n instanceof pt || n instanceof gt
          ? Nn.COMPLETE
          : (
              n instanceof Le
                ? n.code === se.Redirect ||
                  n.code === se.SupersededByNewNavigation
                : !1
            )
          ? Nn.REDIRECTING
          : Nn.FAILED
      ),
      ge((n) => n !== Nn.REDIRECTING),
      _e(1)
    )
    .subscribe(() => {
      t();
    });
}
function by(e) {
  throw e;
}
var My = {
    paths: "exact",
    fragment: "ignored",
    matrixParams: "ignored",
    queryParams: "exact",
  },
  Sy = {
    paths: "subset",
    fragment: "ignored",
    matrixParams: "ignored",
    queryParams: "subset",
  },
  Ad = (() => {
    let t = class t {
      get currentUrlTree() {
        return this.stateManager.getCurrentUrlTree();
      }
      get rawUrlTree() {
        return this.stateManager.getRawUrlTree();
      }
      get events() {
        return this._events;
      }
      get routerState() {
        return this.stateManager.getRouterState();
      }
      constructor() {
        (this.disposed = !1),
          (this.console = p(Qr)),
          (this.stateManager = p(Nd)),
          (this.options = p(oa, { optional: !0 }) || {}),
          (this.pendingTasks = p(Bt)),
          (this.urlUpdateStrategy =
            this.options.urlUpdateStrategy || "deferred"),
          (this.navigationTransitions = p(yy)),
          (this.urlSerializer = p(Js)),
          (this.location = p(In)),
          (this.urlHandlingStrategy = p(aa)),
          (this._events = new Q()),
          (this.errorHandler = this.options.errorHandler || by),
          (this.navigated = !1),
          (this.routeReuseStrategy = p(wy)),
          (this.onSameUrlNavigation =
            this.options.onSameUrlNavigation || "ignore"),
          (this.config = p(sa, { optional: !0 })?.flat() ?? []),
          (this.componentInputBindingEnabled = !!p(na, { optional: !0 })),
          (this.eventsSubscription = new V()),
          this.resetConfig(this.config),
          this.navigationTransitions
            .setupNavigations(this, this.currentUrlTree, this.routerState)
            .subscribe({
              error: (r) => {
                this.console.warn(r);
              },
            }),
          this.subscribeToNavigationEvents();
      }
      subscribeToNavigationEvents() {
        let r = this.navigationTransitions.events.subscribe((o) => {
          try {
            let i = this.navigationTransitions.currentTransition,
              s = this.navigationTransitions.currentNavigation;
            if (i !== null && s !== null) {
              if (
                (this.stateManager.handleRouterEvent(o, s),
                o instanceof Le &&
                  o.code !== se.Redirect &&
                  o.code !== se.SupersededByNewNavigation)
              )
                this.navigated = !0;
              else if (o instanceof pt) this.navigated = !0;
              else if (o instanceof Kt) {
                let a = o.navigationBehaviorOptions,
                  c = this.urlHandlingStrategy.merge(o.url, i.currentRawUrl),
                  u = g(
                    {
                      browserUrl: i.extras.browserUrl,
                      info: i.extras.info,
                      skipLocationChange: i.extras.skipLocationChange,
                      replaceUrl:
                        i.extras.replaceUrl ||
                        this.urlUpdateStrategy === "eager" ||
                        Dy(i.source),
                    },
                    a
                  );
                this.scheduleNavigation(c, Rn, null, u, {
                  resolve: i.resolve,
                  reject: i.reject,
                  promise: i.promise,
                });
              }
            }
            Ty(o) && this._events.next(o);
          } catch (i) {
            this.navigationTransitions.transitionAbortSubject.next(i);
          }
        });
        this.eventsSubscription.add(r);
      }
      resetRootComponentType(r) {
        (this.routerState.root.component = r),
          (this.navigationTransitions.rootComponentType = r);
      }
      initialNavigation() {
        this.setUpLocationChangeListener(),
          this.navigationTransitions.hasRequestedNavigation ||
            this.navigateToSyncWithBrowser(
              this.location.path(!0),
              Rn,
              this.stateManager.restoredState()
            );
      }
      setUpLocationChangeListener() {
        this.nonRouterCurrentEntryChangeSubscription ??=
          this.stateManager.registerNonRouterCurrentEntryChangeListener(
            (r, o) => {
              setTimeout(() => {
                this.navigateToSyncWithBrowser(r, "popstate", o);
              }, 0);
            }
          );
      }
      navigateToSyncWithBrowser(r, o, i) {
        let s = { replaceUrl: !0 },
          a = i?.navigationId ? i : null;
        if (i) {
          let u = g({}, i);
          delete u.navigationId,
            delete u.ɵrouterPageId,
            Object.keys(u).length !== 0 && (s.state = u);
        }
        let c = this.parseUrl(r);
        this.scheduleNavigation(c, o, a, s);
      }
      get url() {
        return this.serializeUrl(this.currentUrlTree);
      }
      getCurrentNavigation() {
        return this.navigationTransitions.currentNavigation;
      }
      get lastSuccessfulNavigation() {
        return this.navigationTransitions.lastSuccessfulNavigation;
      }
      resetConfig(r) {
        (this.config = r.map(ia)), (this.navigated = !1);
      }
      ngOnDestroy() {
        this.dispose();
      }
      dispose() {
        this.navigationTransitions.complete(),
          this.nonRouterCurrentEntryChangeSubscription &&
            (this.nonRouterCurrentEntryChangeSubscription.unsubscribe(),
            (this.nonRouterCurrentEntryChangeSubscription = void 0)),
          (this.disposed = !0),
          this.eventsSubscription.unsubscribe();
      }
      createUrlTree(r, o = {}) {
        let {
            relativeTo: i,
            queryParams: s,
            fragment: a,
            queryParamsHandling: c,
            preserveFragment: u,
          } = o,
          l = u ? this.currentUrlTree.fragment : a,
          d = null;
        switch (c) {
          case "merge":
            d = g(g({}, this.currentUrlTree.queryParams), s);
            break;
          case "preserve":
            d = this.currentUrlTree.queryParams;
            break;
          default:
            d = s || null;
        }
        d !== null && (d = this.removeEmptyProps(d));
        let h;
        try {
          let f = i ? i.snapshot : this.routerState.snapshot.root;
          h = pd(f);
        } catch {
          (typeof r[0] != "string" || r[0][0] !== "/") && (r = []),
            (h = this.currentUrlTree.root);
        }
        return gd(h, r, d, l ?? null);
      }
      navigateByUrl(r, o = { skipLocationChange: !1 }) {
        let i = kn(r) ? r : this.parseUrl(r),
          s = this.urlHandlingStrategy.merge(i, this.rawUrlTree);
        return this.scheduleNavigation(s, Rn, null, o);
      }
      navigate(r, o = { skipLocationChange: !1 }) {
        return xy(r), this.navigateByUrl(this.createUrlTree(r, o), o);
      }
      serializeUrl(r) {
        return this.urlSerializer.serialize(r);
      }
      parseUrl(r) {
        try {
          return this.urlSerializer.parse(r);
        } catch {
          return this.urlSerializer.parse("/");
        }
      }
      isActive(r, o) {
        let i;
        if (
          (o === !0 ? (i = g({}, My)) : o === !1 ? (i = g({}, Sy)) : (i = o),
          kn(r))
        )
          return Kl(this.currentUrlTree, r, i);
        let s = this.parseUrl(r);
        return Kl(this.currentUrlTree, s, i);
      }
      removeEmptyProps(r) {
        return Object.entries(r).reduce(
          (o, [i, s]) => (s != null && (o[i] = s), o),
          {}
        );
      }
      scheduleNavigation(r, o, i, s, a) {
        if (this.disposed) return Promise.resolve(!1);
        let c, u, l;
        a
          ? ((c = a.resolve), (u = a.reject), (l = a.promise))
          : (l = new Promise((h, f) => {
              (c = h), (u = f);
            }));
        let d = this.pendingTasks.add();
        return (
          Iy(this, () => {
            queueMicrotask(() => this.pendingTasks.remove(d));
          }),
          this.navigationTransitions.handleNavigationRequest({
            source: o,
            restoredState: i,
            currentUrlTree: this.currentUrlTree,
            currentRawUrl: this.currentUrlTree,
            rawUrl: r,
            extras: s,
            resolve: c,
            reject: u,
            promise: l,
            currentSnapshot: this.routerState.snapshot,
            currentRouterState: this.routerState,
          }),
          l.catch((h) => Promise.reject(h))
        );
      }
    };
    (t.ɵfac = function (o) {
      return new (o || t)();
    }),
      (t.ɵprov = D({ token: t, factory: t.ɵfac, providedIn: "root" }));
    let e = t;
    return e;
  })();
function xy(e) {
  for (let t = 0; t < e.length; t++) if (e[t] == null) throw new v(4008, !1);
}
function Ty(e) {
  return !(e instanceof Vn) && !(e instanceof Kt);
}
var _y = new I("");
function Rd(e, ...t) {
  return Vr([
    { provide: sa, multi: !0, useValue: e },
    [],
    { provide: Xt, useFactory: Ny, deps: [Ad] },
    { provide: ds, multi: !0, useFactory: Ay },
    t.map((n) => n.ɵproviders),
  ]);
}
function Ny(e) {
  return e.routerState.root;
}
function Ay() {
  let e = p(ut);
  return (t) => {
    let n = e.get(Ht);
    if (t !== n.components[0]) return;
    let r = e.get(Ad),
      o = e.get(Ry);
    e.get(Oy) === 1 && r.initialNavigation(),
      e.get(Py, null, b.Optional)?.setUpPreloading(),
      e.get(_y, null, b.Optional)?.init(),
      r.resetRootComponentType(n.componentTypes[0]),
      o.closed || (o.next(), o.complete(), o.unsubscribe());
  };
}
var Ry = new I("", { factory: () => new Q() }),
  Oy = new I("", { providedIn: "root", factory: () => 1 });
var Py = new I("");
var Od = [];
var Pd = { providers: [bl({ eventCoalescing: !0 }), Rd(Od)] };
var kd = (() => {
  class e {
    title = "vistas-clr";
    static ɵfac = function (r) {
      return new (r || e)();
    };
    static ɵcmp = jr({
      type: e,
      selectors: [["app-root"]],
      standalone: !0,
      features: [Yr],
      decls: 75,
      vars: 0,
      consts: [
        ["lang", "en"],
        ["charset", "UTF-8"],
        [
          "rel",
          "stylesheet",
          "href",
          ju`https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap`,
        ],
        ["id", "usuario"],
        [
          1,
          "text-center",
          2,
          "background-color",
          "#DA291C",
          "padding-top",
          "1rem !important",
          "padding-bottom",
          "1rem !important",
        ],
        [
          "src",
          "../assets/logocl.svg",
          "width",
          "80",
          "height",
          "24",
          "alt",
          "",
        ],
        [1, "contenido"],
        [1, "mt-5"],
        [1, "titulo-1"],
        [2, "font-weight", "600", "color", "#EF3829"],
        [1, "titulo-2"],
        [2, "text-align", "center"],
        [1, "pdf"],
        ["src", "../assets/PFPHM.png"],
        [1, "services"],
        [1, "mt-3"],
        [2, "text-align-last", "center"],
        ["type", "radio", "name", "serv", "checked", ""],
        ["src", "../assets/celular.png", "onchange", "comprobar()"],
        [1, "td-j"],
        ["type", "radio", "name", "serv"],
        ["src", "../assets/hogar.png", "onchange", "comprobar()"],
        ["src", "../assets/equipos.png", "onchange", "comprobar()"],
        [1, "label-1"],
        [
          "autocomplete",
          "of",
          "id",
          "celular",
          "type",
          "tel",
          "name",
          "factura",
          "minlength",
          "10",
          "maxlength",
          "10",
          "required",
          "",
          "pattern",
          "\\d{10}",
          "oninput",
          "this.value = this.value.replace(/\\D/, '')",
          1,
          "entrada-1",
        ],
        [1, "caja-boton-1"],
        ["id", "validarNumero", "onclick", "validarNumero()", 1, "boton-1"],
        ["id", "contenedor"],
        ["id", "errorpasarela", 2, "display", "none"],
        [1, "text-center", "py-4", 2, "background-color", "#DA291C"],
        ["id", "spinner", 2, "height", "400px", "margin-top", "100px"],
        [1, "text-center", "mt-5"],
        [
          "src",
          "../assets/iconos-logo-claro.png",
          2,
          "width",
          "130px",
          "margin-left",
          "auto",
        ],
        [1, "loader"],
        [1, "dot"],
        [1, "text-center"],
        [1, "texto-1"],
        ["id", "footerr"],
        [1, "footer2"],
        ["src", "../assets/logocl.svg", 1, "logo2"],
      ],
      template: function (r, o) {
        r & 1 &&
          (F(0, "html", 0)(1, "head"),
          U(2, "meta", 1),
          F(3, "title"),
          ee(4, "Portal de pagos y recargas claro colombia - Personas"),
          B(),
          U(5, "link", 2),
          B(),
          F(6, "body")(7, "section", 3)(8, "div", 4),
          U(9, "img", 5),
          B(),
          F(10, "div", 6)(11, "div", 7)(12, "h1", 8),
          ee(13, "Portal de "),
          F(14, "span", 9),
          ee(15, "PAGOS Y RECARGAS"),
          B()()(),
          F(16, "div")(17, "h2", 10),
          ee(
            18,
            " Realiza el pago de la factura de tus servicios Claro, compra paquetes y haz recargas de manera f\xE1cil y desde donde quieras. "
          ),
          B(),
          F(19, "div", 11)(20, "div", 12),
          U(21, "img", 13),
          F(22, "label", 14),
          ee(23, "Pago de Facturas"),
          B()()()(),
          F(24, "div", 15)(25, "div", 16)(26, "label", 14),
          ee(27, "Selecciona el tipo de servicio"),
          B()()(),
          F(28, "table")(29, "tbody", 11)(30, "tr")(31, "td"),
          U(32, "input", 17)(33, "img", 18),
          F(34, "label", 19),
          ee(35, "Postpago"),
          B()(),
          F(36, "td"),
          U(37, "input", 20)(38, "img", 21),
          F(39, "label", 19),
          ee(40, "Hogar y Multiplay"),
          B()(),
          F(41, "td"),
          U(42, "input", 20)(43, "img", 22),
          F(44, "label", 19),
          ee(45, "Equipo"),
          B()()()()(),
          F(46, "div", 15)(47, "label", 23),
          ee(48, "N\xFAmero de celular"),
          B(),
          U(49, "input", 24),
          B(),
          U(50, "br"),
          F(51, "div", 25)(52, "button", 26),
          ee(53, "Continuar"),
          B()()()(),
          U(54, "div", 27),
          F(55, "section", 28)(56, "div", 29),
          U(57, "img", 5),
          B(),
          F(58, "div", 30)(59, "div", 31),
          U(60, "img", 32),
          F(61, "div", 33),
          U(62, "div", 34)(63, "div", 34)(64, "div", 34),
          B()(),
          U(65, "br"),
          F(66, "div", 35)(67, "p", 36),
          ee(
            68,
            "Te pedimos una disculpa, en este momento solo se aceptan las siguiente pasarelas de pagos: Nequi, Bancolombia o Tarjeta de Debito o Credito"
          ),
          B()()()(),
          F(69, "footer", 37)(70, "div", 38),
          U(71, "img", 39),
          F(72, "p"),
          ee(73, "Todos los derechos reservados - A\xF1o 2025 Claro"),
          B()()()()(),
          U(74, "router-outlet"));
      },
      dependencies: [ta],
      styles: [
        "titulo-1[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;font-family:AMX regular!important;border:0;vertical-align:baseline;font:inherit;line-height:.75em;padding:0;margin:0 15px 20px;color:#5c5c5c;text-align:center;font-weight:100;font-size:1.4rem}.titulo-2[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;font-family:AMX regular!important;margin:0;border:0;vertical-align:baseline;font:inherit;font-size:1rem!important;line-height:15pt!important;font-weight:400!important;color:#606a6d!important;text-align:justify;padding:10px}.contenido[_ngcontent-%COMP%]{width:100%;padding-inline:20px}.tipo-servicio-1[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;border-collapse:collapse;border-spacing:0;text-align:left;box-sizing:border-box;margin:0;border:0;vertical-align:baseline;font:inherit;line-height:1.75em;font-weight:600!important;font-family:AMX regular!important;color:#606a6d!important;font-size:1rem!important;padding:0 0 0 5px;display:inline-block}.texto-1[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;display:inline-block;padding:0;border:0;vertical-align:baseline;font:inherit;line-height:inherit;font-weight:600!important;font-family:AMX regular!important;color:#606a6d!important;font-size:1.1rem!important;margin:5px;text-align:left}.label-1[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;display:inline-block;padding:0;border:0;vertical-align:baseline;font:inherit;line-height:inherit;font-weight:600!important;font-family:AMX regular!important;color:#606a6d!important;font-size:1rem!important;margin:5px;text-align:left}.semdp[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;display:inline-block;padding:0;border:0;vertical-align:baseline;font:inherit;line-height:inherit;font-weight:600!important;font-family:AMX regular!important;color:#606a6d!important;font-size:1rem!important;margin-left:1.1rem}.services[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;display:inline-block;padding:0;border:0;vertical-align:baseline;font:inherit;line-height:inherit;font-weight:600!important;font-family:AMX regular!important;color:#606a6d!important;font-size:1.1rem!important;margin:5px}.pdf[_ngcontent-%COMP%]{margin-left:15px;margin-right:15px;border:1px solid #afafaf!important;border-radius:10px;box-shadow:0 0 #00000029;-webkit-tap-highlight-color:rgba(0,0,0,0)}.td-j[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;display:inline-block;padding:0;border:0;vertical-align:baseline;font:inherit;line-height:inherit;font-weight:600!important;font-family:AMX regular!important;color:#606a6d!important;font-size:.9rem!important;margin:5px}.boton-1[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;font:inherit;box-shadow:inset 0 -1px #00000017;vertical-align:middle;background-image:none;white-space:nowrap;-webkit-user-select:none;user-select:none;margin:0 0 20px 1%;border-radius:5px!important;height:45px!important;text-transform:initial!important;appearance:none;transition:color .2s ease-in-out,border-color .2s ease-in-out,background-color .2s ease-in-out;border:solid 1px;border-color:#fff;cursor:pointer;display:inline-block;line-height:1.12em;text-align:center;text-decoration:none;max-width:42em;font-family:AMX regular;font-weight:400;padding:8px;background-color:#e52a1b;font-size:18px;width:100%;color:#fff}.caja-boton-1[_ngcontent-%COMP%]{padding-inline:80px}footer[_ngcontent-%COMP%]{font-weight:400;font-size:14px;font-family:Roboto}@media only screen and (min-width: 768px){.contenido[_ngcontent-%COMP%]{width:50%;margin:0 auto}.caja-boton-1[_ngcontent-%COMP%]{padding-inline:150px}.titulo-1[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;font-family:AMX regular!important;border:0;vertical-align:baseline;font:inherit;line-height:1.75em;padding:0;margin:0 15px;color:#5c5c5c;text-align:center;font-weight:100;font-size:2rem}}.tabla-1[_ngcontent-%COMP%]{width:90%;margin:30px auto;padding:0}@media only screen and (min-width: 768px){.tabla-1[_ngcontent-%COMP%]{width:35%;margin:30px auto;padding:0}}.tabla-1[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#625f5f;font-weight:400;font-family:AMX regular;font-size:14px;margin-top:5px;margin-bottom:0}.tabla-1[_ngcontent-%COMP%]   .w[_ngcontent-%COMP%], .tabla-1[_ngcontent-%COMP%]   .row[_ngcontent-%COMP%]{background-color:#f5f4f4}.parrafo-1[_ngcontent-%COMP%]{-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-font-smoothing:antialiased;box-sizing:border-box;font-family:AMX regular!important;border:0;vertical-align:baseline;font:inherit;font-weight:inherit;line-height:1.75em;color:#5e5e5e;text-align:justify;font-size:.9rem;width:90%;margin:30px auto;padding:0}.medio-pago[_ngcontent-%COMP%]{margin-bottom:1.5rem}.medio-pago[_ngcontent-%COMP%]   .row[_ngcontent-%COMP%]{height:50px;width:90%;margin:10px auto;padding:0}#tarjeta[_ngcontent-%COMP%], #nequi[_ngcontent-%COMP%], #ps[_ngcontent-%COMP%], #trico[_ngcontent-%COMP%]{text-decoration:none;color:inherit}",
      ],
    });
  }
  return e;
})();
Yl(kd, Pd).catch((e) => console.error(e));
