<?php
require 'firebase.php';

$database->getReference("1/")->remove();
echo json_encode(["status" => "success"]);
?>
