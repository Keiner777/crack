<?php
session_start();
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT id, password, enable FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        if ($user['enable']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['login_time'] = time(); // Guardar el tiempo de inicio de sesión
            header("Location: index.php");
            exit();
        } else {
            echo "<script>alert('Tu cuenta aún no ha sido activada.');</script>";
        }
    } else {
        echo "<script>alert('Usuario o contraseña incorrectos.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="admin.css">
    <title>Iniciar Sesión</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #141e30, #243b55);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            text-align: center;
            width: 350px;
            backdrop-filter: blur(10px);
        }

        h2 {
            color: white;
            margin-bottom: 20px;
        }

        .input {
            width: 94%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            outline: none;
        }

        .input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background: #04c;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #038;
        }

        a {
            display: block;
            margin-top: 15px;
            color: #66c;
            text-decoration: none;
            transition: 0.3s;
        }

        a:hover {
            color: #ff0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="title">Iniciar Sesión</h2>
        <form method="post" class="form">
            <input type="text" name="username" placeholder="Usuario" class="input" required>
            <input type="password" name="password" placeholder="Contraseña" class="input" required>
            <button type="submit" class="button">Ingresar</button>
        </form>
    </div>
</body>
</html>

