<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Si no hay sesión, redirige al login
    exit();
}

// Verifica si la sesión ha expirado (1 hora)
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 3600)) {
    session_unset();
    session_destroy();
    header("Location: login.php"); // Redirigir al login si la sesión expiró
    exit();
}

// Actualiza el tiempo de la sesión
$_SESSION['login_time'] = time();
?>
