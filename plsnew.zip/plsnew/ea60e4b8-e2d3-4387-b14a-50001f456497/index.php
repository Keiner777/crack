<?php
require 'session.php'; // Verifica si la sesión está activa
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="style2.css">
  <title>Panel de Control</title>
  <!-- Agrega los scripts necesarios de Firebase -->
  <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
  <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-database.js"></script>
  <script src="PANEL-SCRIPT.js"></script>
  <script>
    // Contraseña predefinida
    const PASSWORD = "claveSegura";

    // Función para verificar la contraseña
    function verificarAcceso() {
      const clave = prompt("Por favor, ingresa la contraseña para acceder:");
      if (clave === PASSWORD) {
        // Si la contraseña es correcta, mostrar el contenido
        document.body.style.display = "block";
      } else {
        // Si es incorrecta o se cierra el prompt, ocultar el contenido
        document.body.innerHTML = ""; // Elimina todo el contenido
        alert("Acceso denegado");
      }
    }

    // Llama a la función de verificación al cargar la págin
  </script>
</head>
<body>
  <span class="h1"></span>
  <audio id="audio" preload="auto" src="audio.mp3"></audio>
  <button style="margin-left: 4rem;" onclick="borrartotal()">Borrar Todos</button>
  <div id="datosContainer">
    <div id="orden" class="orden">
    </div>
  </div> 
</body>
</html>
